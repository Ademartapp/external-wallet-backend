import { Router, Request, Response } from 'express';
import { authMiddleware } from '../middleware/auth';
import {
  getQuidaxUser,
  createQuidaxSubAccount,
  getQuidaxWallets,
  getQuidaxWallet,
  getQuidaxDepositAddress,
  createQuidaxWithdrawal,
  getQuidaxWithdrawals,
  getQuidaxWithdrawal,
  getQuidaxDeposits,
  getQuidaxDeposit,
  createQuidaxInstantOrder,
  confirmQuidaxInstantOrder,
  getQuidaxInstantOrders,
  getQuidaxMarkets,
  getQuidaxTicker,
  getQuidaxOrderBook,
  getQuidaxBanks,
  validateBankAccount,
  createQuidaxBeneficiary,
  getQuidaxBeneficiaries,
  getQuidaxQuote
} from '../services/quidax';

const router = Router();

// Apply auth to all routes
router.use(authMiddleware);

// ==================== USER & ACCOUNT ====================

router.get('/user', async (_req: Request, res: Response) => {
  try {
    const result = await getQuidaxUser();
    if (result.success) {
      res.json({ success: true, data: result.data });
    } else {
      res.status(400).json({ success: false, error: result.error });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/user/create', async (req: Request, res: Response) => {
  try {
    const { email, firstName, lastName } = req.body;
    
    if (!email || !firstName || !lastName) {
      res.status(400).json({ 
        success: false, 
        error: 'Missing required fields: email, firstName, lastName' 
      });
      return;
    }

    const result = await createQuidaxSubAccount(email, firstName, lastName);
    if (result.success) {
      res.json({ success: true, data: result.data });
    } else {
      res.status(400).json({ success: false, error: result.error });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== WALLETS ====================

router.get('/wallets', async (req: Request, res: Response) => {
  try {
    const userId = req.query.userId as string || 'me';
    const result = await getQuidaxWallets(userId);
    if (result.success) {
      res.json({ success: true, data: result.data });
    } else {
      res.status(400).json({ success: false, error: result.error });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/wallets/:currency', async (req: Request, res: Response) => {
  try {
    const { currency } = req.params;
    const userId = req.query.userId as string || 'me';
    const result = await getQuidaxWallet(userId, currency);
    if (result.success) {
      res.json({ success: true, data: result.data });
    } else {
      res.status(400).json({ success: false, error: result.error });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/wallets/:currency/address', async (req: Request, res: Response) => {
  try {
    const { currency } = req.params;
    const userId = req.query.userId as string || 'me';
    const result = await getQuidaxDepositAddress(userId, currency);
    if (result.success) {
      res.json({ success: true, data: result.data });
    } else {
      res.status(400).json({ success: false, error: result.error });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== WITHDRAWALS ====================

router.post('/withdraw', async (req: Request, res: Response) => {
  try {
    const { userId = 'me', currency, amount, address, network, narration } = req.body;
    
    if (!currency || !amount || !address) {
      res.status(400).json({ 
        success: false, 
        error: 'Missing required fields: currency, amount, address' 
      });
      return;
    }

    const result = await createQuidaxWithdrawal(userId, currency, amount, address, network, narration);
    if (result.success) {
      res.json({ success: true, data: result.data });
    } else {
      res.status(400).json({ success: false, error: result.error });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/withdrawals', async (req: Request, res: Response) => {
  try {
    const userId = req.query.userId as string || 'me';
    const currency = req.query.currency as string | undefined;
    const result = await getQuidaxWithdrawals(userId, currency);
    if (result.success) {
      res.json({ success: true, data: result.data });
    } else {
      res.status(400).json({ success: false, error: result.error });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/withdrawals/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userId = req.query.userId as string || 'me';
    const result = await getQuidaxWithdrawal(userId, id);
    if (result.success) {
      res.json({ success: true, data: result.data });
    } else {
      res.status(400).json({ success: false, error: result.error });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== DEPOSITS ====================

router.get('/deposits', async (req: Request, res: Response) => {
  try {
    const userId = req.query.userId as string || 'me';
    const currency = req.query.currency as string | undefined;
    const result = await getQuidaxDeposits(userId, currency);
    if (result.success) {
      res.json({ success: true, data: result.data });
    } else {
      res.status(400).json({ success: false, error: result.error });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/deposits/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userId = req.query.userId as string || 'me';
    const result = await getQuidaxDeposit(userId, id);
    if (result.success) {
      res.json({ success: true, data: result.data });
    } else {
      res.status(400).json({ success: false, error: result.error });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== TRADES / INSTANT ORDERS ====================

router.post('/trade', async (req: Request, res: Response) => {
  try {
    const { userId = 'me', bid, ask, type, volume, unit = 'bid' } = req.body;
    
    if (!bid || !ask || !type || !volume) {
      res.status(400).json({ 
        success: false, 
        error: 'Missing required fields: bid, ask, type, volume' 
      });
      return;
    }

    const result = await createQuidaxInstantOrder(userId, bid, ask, type, volume, unit);
    if (result.success) {
      res.json({ success: true, data: result.data });
    } else {
      res.status(400).json({ success: false, error: result.error });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/trade/:id/confirm', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userId = req.body.userId || 'me';
    
    const result = await confirmQuidaxInstantOrder(userId, id);
    if (result.success) {
      res.json({ success: true, data: result.data });
    } else {
      res.status(400).json({ success: false, error: result.error });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/trades', async (req: Request, res: Response) => {
  try {
    const userId = req.query.userId as string || 'me';
    const pair = req.query.pair as string | undefined;
    const state = req.query.state as string | undefined;
    const result = await getQuidaxInstantOrders(userId, pair, state);
    if (result.success) {
      res.json({ success: true, data: result.data });
    } else {
      res.status(400).json({ success: false, error: result.error });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== MARKETS & PRICES ====================

router.get('/markets', async (_req: Request, res: Response) => {
  try {
    const result = await getQuidaxMarkets();
    if (result.success) {
      res.json({ success: true, data: result.data });
    } else {
      res.status(400).json({ success: false, error: result.error });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/ticker/:pair', async (req: Request, res: Response) => {
  try {
    const { pair } = req.params;
    const result = await getQuidaxTicker(pair);
    if (result.success) {
      res.json({ success: true, data: result.data });
    } else {
      res.status(400).json({ success: false, error: result.error });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/orderbook/:pair', async (req: Request, res: Response) => {
  try {
    const { pair } = req.params;
    const result = await getQuidaxOrderBook(pair);
    if (result.success) {
      res.json({ success: true, data: result.data });
    } else {
      res.status(400).json({ success: false, error: result.error });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== QUOTE ====================

router.post('/quote', async (req: Request, res: Response) => {
  try {
    const { bid, ask, type, volume, unit = 'bid' } = req.body;
    
    if (!bid || !ask || !type || !volume) {
      res.status(400).json({ 
        success: false, 
        error: 'Missing required fields: bid, ask, type, volume' 
      });
      return;
    }

    const result = await getQuidaxQuote(bid, ask, type, volume, unit);
    if (result.success) {
      res.json({ success: true, data: result.data });
    } else {
      res.status(400).json({ success: false, error: result.error });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== BANKS & BENEFICIARIES ====================

router.get('/banks', async (_req: Request, res: Response) => {
  try {
    const result = await getQuidaxBanks();
    if (result.success) {
      res.json({ success: true, data: result.data });
    } else {
      res.status(400).json({ success: false, error: result.error });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/validate-bank', async (req: Request, res: Response) => {
  try {
    const { accountNumber, bankCode } = req.body;
    
    if (!accountNumber || !bankCode) {
      res.status(400).json({ 
        success: false, 
        error: 'Missing required fields: accountNumber, bankCode' 
      });
      return;
    }

    const result = await validateBankAccount(accountNumber, bankCode);
    if (result.success) {
      res.json({ success: true, data: result.data });
    } else {
      res.status(400).json({ success: false, error: result.error });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/beneficiaries', async (req: Request, res: Response) => {
  try {
    const userId = req.query.userId as string || 'me';
    const currency = req.query.currency as string | undefined;
    const result = await getQuidaxBeneficiaries(userId, currency);
    if (result.success) {
      res.json({ success: true, data: result.data });
    } else {
      res.status(400).json({ success: false, error: result.error });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/beneficiaries', async (req: Request, res: Response) => {
  try {
    const { userId = 'me', currency, address, network, label } = req.body;
    
    if (!currency || !address) {
      res.status(400).json({ 
        success: false, 
        error: 'Missing required fields: currency, address' 
      });
      return;
    }

    const result = await createQuidaxBeneficiary(userId, currency, address, network, label);
    if (result.success) {
      res.json({ success: true, data: result.data });
    } else {
      res.status(400).json({ success: false, error: result.error });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

export default router;
