import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Moon, Sun, Globe, Bell, Shield, Wallet, ChevronRight, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAuth } from '@/contexts/AuthContext';
import { BottomNav } from '@/components/BottomNav';
import { useToast } from '@/hooks/use-toast';
import { useNotificationPreferences } from '@/hooks/useNotificationPreferences';
import { PushNotificationToggle } from '@/components/PushNotificationToggle';

const Settings = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading, signOut } = useAuth();
  const { toast } = useToast();
  const { preferences, isLoading: prefsLoading, updatePreferences, isUpdating } = useNotificationPreferences();

  const [theme, setTheme] = useState<'dark' | 'light' | 'system'>('dark');
  const [currency, setCurrency] = useState('USD');
  const [language, setLanguage] = useState('en');

  // Redirect to auth if not logged in
  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/auth');
    }
  }, [user, authLoading, navigate]);

  // Load theme from localStorage
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme') as 'dark' | 'light' | 'system' || 'dark';
    setTheme(savedTheme);
  }, []);

  const handleThemeChange = (newTheme: 'dark' | 'light' | 'system') => {
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme);
    
    if (newTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else if (newTheme === 'light') {
      document.documentElement.classList.remove('dark');
    } else {
      // System preference
      if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    }
    
    toast({
      title: 'Theme Updated',
      description: `Theme set to ${newTheme}`,
    });
  };

  const handleCurrencyChange = (newCurrency: string) => {
    setCurrency(newCurrency);
    localStorage.setItem('currency', newCurrency);
    toast({
      title: 'Currency Updated',
      description: `Display currency set to ${newCurrency}`,
    });
  };

  const handleNotificationToggle = (key: keyof typeof preferences, value: boolean) => {
    if (preferences) {
      updatePreferences({ [key]: value });
    }
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/auth');
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-md mx-auto px-4 pb-24">
        <header className="flex items-center gap-4 py-4">
          <button
            onClick={() => navigate('/')}
            className="p-2 rounded-full bg-secondary/50 hover:bg-secondary transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-semibold">Settings</h1>
        </header>

        <div className="space-y-6 animate-fade-in">
          {/* Appearance */}
          <div className="glass-card p-4 space-y-4">
            <h3 className="font-medium flex items-center gap-2">
              {theme === 'dark' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
              Appearance
            </h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Theme</Label>
                <Select value={theme} onValueChange={(v) => handleThemeChange(v as 'dark' | 'light' | 'system')}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dark">Dark</SelectItem>
                    <SelectItem value="light">Light</SelectItem>
                    <SelectItem value="system">System</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Currency & Language */}
          <div className="glass-card p-4 space-y-4">
            <h3 className="font-medium flex items-center gap-2">
              <Globe className="w-4 h-4" />
              Regional
            </h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Display Currency</Label>
                <Select value={currency} onValueChange={handleCurrencyChange}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="USD">USD ($)</SelectItem>
                    <SelectItem value="EUR">EUR (€)</SelectItem>
                    <SelectItem value="GBP">GBP (£)</SelectItem>
                    <SelectItem value="NGN">NGN (₦)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <Label>Language</Label>
                <Select value={language} onValueChange={setLanguage}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="es">Español</SelectItem>
                    <SelectItem value="fr">Français</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Notifications */}
          <div className="glass-card p-4 space-y-4">
            <h3 className="font-medium flex items-center gap-2">
              <Bell className="w-4 h-4" />
              Notifications
            </h3>
            
            {prefsLoading ? (
              <div className="flex justify-center py-4">
                <Loader2 className="w-5 h-5 animate-spin" />
              </div>
            ) : preferences ? (
              <div className="space-y-4">
                <PushNotificationToggle />

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Deposit Emails</Label>
                    <p className="text-xs text-muted-foreground">Email for incoming deposits</p>
                  </div>
                  <Switch
                    checked={preferences.email_deposits}
                    onCheckedChange={(v) => handleNotificationToggle('email_deposits', v)}
                    disabled={isUpdating}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Withdrawal Emails</Label>
                    <p className="text-xs text-muted-foreground">Email for outgoing withdrawals</p>
                  </div>
                  <Switch
                    checked={preferences.email_withdrawals}
                    onCheckedChange={(v) => handleNotificationToggle('email_withdrawals', v)}
                    disabled={isUpdating}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Transaction Emails</Label>
                    <p className="text-xs text-muted-foreground">Email for all transactions</p>
                  </div>
                  <Switch
                    checked={preferences.email_transactions}
                    onCheckedChange={(v) => handleNotificationToggle('email_transactions', v)}
                    disabled={isUpdating}
                  />
                </div>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">Sign in to manage notifications</p>
            )}
          </div>

          {/* Security & Privacy */}
          <div className="glass-card p-4 space-y-4">
            <h3 className="font-medium flex items-center gap-2">
              <Shield className="w-4 h-4" />
              Security & Privacy
            </h3>
            
            <button
              onClick={() => navigate('/profile')}
              className="w-full flex items-center justify-between p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors"
            >
              <span>Two-Factor Authentication</span>
              <ChevronRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => navigate('/wallets')}
              className="w-full flex items-center justify-between p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors"
            >
              <span>Wallet Backup</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Wallet Settings */}
          <div className="glass-card p-4 space-y-4">
            <h3 className="font-medium flex items-center gap-2">
              <Wallet className="w-4 h-4" />
              Wallet
            </h3>
            
            <button
              onClick={() => navigate('/wallets')}
              className="w-full flex items-center justify-between p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors"
            >
              <span>Manage Wallets</span>
              <ChevronRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => navigate('/transactions')}
              className="w-full flex items-center justify-between p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors"
            >
              <span>Transaction History</span>
              <ChevronRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => navigate('/diagnostics')}
              className="w-full flex items-center justify-between p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors"
            >
              <span>Diagnostics & Troubleshooting</span>
              <ChevronRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => navigate('/health')}
              className="w-full flex items-center justify-between p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors"
            >
              <span>Health Panel</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Sign Out */}
          <Button
            variant="destructive"
            onClick={handleSignOut}
            className="w-full"
          >
            Sign Out
          </Button>

          {/* App Info */}
          <div className="text-center text-xs text-muted-foreground space-y-1">
            <p>CryptoWallet v1.0.0</p>
            <p>© 2024 All rights reserved</p>
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  );
};

export default Settings;
