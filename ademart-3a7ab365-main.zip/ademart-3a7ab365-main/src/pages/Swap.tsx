import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowLeft, ArrowDownUp, ChevronDown, Loader2, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { useUnifiedBalances, UnifiedBalance } from '@/hooks/useUnifiedBalances';
import { useRealtimeWallets } from '@/hooks/useRealtimeWallets';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useCryptoMarkets } from '@/hooks/useCryptoData';

const Swap = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { toast } = useToast();
  const { user } = useAuth();
  const { balances, loading: balancesLoading } = useUnifiedBalances();
  const { refetch: refetchWallets } = useRealtimeWallets();
  const { data: marketPrices, isLoading: pricesLoading } = useCryptoMarkets('usd', 50);
  
  const [fromAsset, setFromAsset] = useState<UnifiedBalance | null>(null);
  const [toAsset, setToAsset] = useState<UnifiedBalance | null>(null);
  const [fromAmount, setFromAmount] = useState('');
  const [showFromList, setShowFromList] = useState(false);
  const [showToList, setShowToList] = useState(false);
  const [isSwapping, setIsSwapping] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);

  // Set default assets when balances load (supports preselect via URL: /swap?from=USDT&to=TRX)
  useEffect(() => {
    if (balances.length === 0) return;

    const fromParam = searchParams.get('from')?.toUpperCase();
    const toParam = searchParams.get('to')?.toUpperCase();

    const desiredFrom = fromParam ? balances.find(b => b.symbol === fromParam) ?? null : null;
    const desiredTo = toParam ? balances.find(b => b.symbol === toParam) ?? null : null;

    const effectiveFrom = desiredFrom ?? fromAsset ?? balances[0];
    const effectiveTo = desiredTo && desiredTo.symbol !== effectiveFrom.symbol
      ? desiredTo
      : (balances.find(b => b.symbol !== effectiveFrom.symbol) ?? balances[1] ?? balances[0]);

    if (!fromAsset) setFromAsset(effectiveFrom);
    if (!toAsset) setToAsset(effectiveTo);
  }, [balances, fromAsset, toAsset, searchParams]);

  // Symbol to CoinGecko ID mapping
  const symbolToCoinId: Record<string, string> = {
    BTC: 'bitcoin', ETH: 'ethereum', LTC: 'litecoin', TRX: 'tron',
    BNB: 'binancecoin', MATIC: 'polygon-ecosystem-token', DOGE: 'dogecoin',
    USDT: 'tether', USDC: 'usd-coin',
  };

  // Get price for an asset
  const getAssetPrice = (symbol: string): number => {
    if (!marketPrices) return 0;
    const coinId = symbolToCoinId[symbol.toUpperCase()];
    const priceData = marketPrices.find(p => p.id === coinId);
    return priceData?.current_price || 0;
  };

  const fromPrice = fromAsset ? getAssetPrice(fromAsset.symbol) : 0;
  const toPrice = toAsset ? getAssetPrice(toAsset.symbol) : 0;

  const toAmount = fromAmount && fromPrice > 0 && toPrice > 0
    ? ((parseFloat(fromAmount) * fromPrice) / toPrice).toFixed(6)
    : '';

  const handleSwapAssets = () => {
    const temp = fromAsset;
    setFromAsset(toAsset);
    setToAsset(temp);
    setFromAmount('');
  };

  const handleSyncBalances = async () => {
    setIsSyncing(true);
    try {
      await supabase.functions.invoke('onchain-monitor', {
        body: { action: 'sync_balances' },
      });
      refetchWallets();
      toast({
        title: 'Balances Synced',
        description: 'Your wallet balances have been updated',
      });
    } catch (error) {
      console.error('Sync error:', error);
    } finally {
      setIsSyncing(false);
    }
  };

  const handleSwap = async () => {
    if (!user) {
      toast({
        title: 'Authentication Required',
        description: 'Please log in to swap',
        variant: 'destructive',
      });
      navigate('/auth');
      return;
    }

    if (!fromAsset || !toAsset) {
      toast({
        title: 'Select Assets',
        description: 'Please select both assets to swap',
        variant: 'destructive',
      });
      return;
    }

    if (!fromAmount || parseFloat(fromAmount) <= 0) {
      toast({
        title: 'Invalid Amount',
        description: 'Please enter a valid amount to swap',
        variant: 'destructive',
      });
      return;
    }

    const sendAmount = parseFloat(fromAmount);
    // Use internal balance for swaps
    const availableForSwap = fromAsset.internal;
    if (sendAmount > availableForSwap) {
      toast({
        title: 'Insufficient Balance',
        description: `You have ${availableForSwap.toFixed(6)} ${fromAsset.symbol} available for swap`,
        variant: 'destructive',
      });
      return;
    }

    setIsSwapping(true);
    try {
      // Call quidax edge function for swap
      const { data, error } = await supabase.functions.invoke('quidax', {
        body: {
          action: 'swap',
          fromSymbol: fromAsset.symbol,
          toSymbol: toAsset.symbol,
          amount: fromAmount,
        },
      });

      if (error) throw error;
      if (!data?.success) throw new Error(data?.error || 'Swap failed');

      toast({
        title: 'Swap Successful',
        description: `Swapped ${fromAmount} ${fromAsset.symbol} to ${toAmount} ${toAsset.symbol}`,
      });

      setFromAmount('');
      refetchWallets();
    } catch (error: any) {
      toast({
        title: 'Swap Failed',
        description: error.message || 'Failed to complete swap',
        variant: 'destructive',
      });
    } finally {
      setIsSwapping(false);
    }
  };

  const AssetSelector = ({
    asset,
    showList,
    setShowList,
    onSelect,
    exclude,
  }: {
    asset: UnifiedBalance | null;
    showList: boolean;
    setShowList: (v: boolean) => void;
    onSelect: (a: UnifiedBalance) => void;
    exclude: string | undefined;
  }) => (
    <div className="relative">
      <button
        onClick={() => setShowList(!showList)}
        className="flex items-center gap-2 px-3 py-2 rounded-xl bg-secondary hover:bg-secondary/80 transition-colors"
      >
        <span className="font-medium">{asset?.symbol || 'Select'}</span>
        <ChevronDown className="w-4 h-4" />
      </button>
      {showList && (
        <div className="absolute top-full mt-2 left-0 right-0 min-w-[160px] bg-card border border-border rounded-xl shadow-xl z-10 overflow-hidden max-h-64 overflow-y-auto">
          {balances
            .filter((a) => a.symbol !== exclude)
            .map((a) => (
              <button
                key={`${a.symbol}-${a.chain}`}
                onClick={() => {
                  onSelect(a);
                  setShowList(false);
                }}
                className="w-full px-4 py-3 text-left hover:bg-secondary/50 transition-colors flex justify-between items-center"
              >
                <div>
                  <span className="font-medium">{a.symbol}</span>
                  <span className="text-xs text-muted-foreground ml-1">({a.chain})</span>
                </div>
                <span className="text-sm text-muted-foreground">{a.total.toFixed(4)}</span>
              </button>
            ))}
        </div>
      )}
    </div>
  );

  if (balancesLoading || pricesLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-md mx-auto px-4 pb-8">
        <header className="flex items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/')}
              className="p-2 rounded-full bg-secondary/50 hover:bg-secondary transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-semibold">Swap</h1>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={handleSyncBalances}
            disabled={isSyncing}
            className="gap-2"
          >
            <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
            Sync
          </Button>
        </header>

        <div className="space-y-4 animate-fade-in">
          <div className="glass-card p-4 space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">From</span>
              <span className="text-sm text-muted-foreground">
                Internal: {fromAsset?.internal.toFixed(6) || '0'} {fromAsset?.symbol}
              </span>
            </div>
            <div className="flex items-center gap-3">
              <AssetSelector
                asset={fromAsset}
                showList={showFromList}
                setShowList={setShowFromList}
                onSelect={setFromAsset}
                exclude={toAsset?.symbol}
              />
              <Input
                type="number"
                placeholder="0.00"
                value={fromAmount}
                onChange={(e) => setFromAmount(e.target.value)}
                className="flex-1 text-right text-xl font-semibold bg-transparent border-0 focus-visible:ring-0"
              />
            </div>
            <button
              onClick={() => fromAsset && setFromAmount(fromAsset.internal.toString())}
              className="text-xs text-primary hover:underline"
            >
              Use MAX
            </button>
          </div>

          <div className="flex justify-center">
            <button
              onClick={handleSwapAssets}
              className="p-3 rounded-full bg-secondary hover:bg-secondary/80 transition-all hover:scale-110"
            >
              <ArrowDownUp className="w-5 h-5" />
            </button>
          </div>

          <div className="glass-card p-4 space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">To</span>
              <span className="text-sm text-muted-foreground">
                Internal: {toAsset?.internal.toFixed(6) || '0'} {toAsset?.symbol}
              </span>
            </div>
            <div className="flex items-center gap-3">
              <AssetSelector
                asset={toAsset}
                showList={showToList}
                setShowList={setShowToList}
                onSelect={setToAsset}
                exclude={fromAsset?.symbol}
              />
              <Input
                type="number"
                placeholder="0.00"
                value={toAmount}
                readOnly
                className="flex-1 text-right text-xl font-semibold bg-transparent border-0 focus-visible:ring-0"
              />
            </div>
          </div>

          <div className="glass-card p-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Rate</span>
              <span>
                {fromAsset && toAsset && fromPrice > 0 && toPrice > 0
                  ? `1 ${fromAsset.symbol} = ${(fromPrice / toPrice).toFixed(6)} ${toAsset.symbol}`
                  : '-'}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Fee</span>
              <span>0.1%</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Slippage</span>
              <span>0.5%</span>
            </div>
          </div>

          <Button 
            onClick={handleSwap} 
            className="w-full bg-primary hover:bg-primary/90"
            disabled={isSwapping || !fromAsset || !toAsset || !fromAmount || (fromAsset && parseFloat(fromAmount || '0') > fromAsset.internal)}
          >
            {isSwapping ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Swapping...
              </>
            ) : (
              'Swap'
            )}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Swap;