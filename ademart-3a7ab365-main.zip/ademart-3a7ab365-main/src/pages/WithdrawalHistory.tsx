import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ArrowUpRight, Clock, CheckCircle, XCircle, RefreshCw, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { format } from 'date-fns';
import { BottomNav } from '@/components/BottomNav';
import { TransactionDetailsModal } from '@/components/TransactionDetailsModal';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface Withdrawal {
  id: string;
  amount: number;
  from_currency: string;
  status: string;
  tx_hash: string | null;
  created_at: string;
  fee: number | null;
  type: string;
  recipient_address: string | null;
}

const statusIcons = {
  pending: <Clock className="w-4 h-4 text-yellow-500" />,
  completed: <CheckCircle className="w-4 h-4 text-green-500" />,
  failed: <XCircle className="w-4 h-4 text-red-500" />,
};

const statusColors = {
  pending: 'bg-yellow-500/20 text-yellow-500',
  completed: 'bg-green-500/20 text-green-500',
  failed: 'bg-red-500/20 text-red-500',
};

const WithdrawalHistory = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>('all');
  const [selectedWithdrawal, setSelectedWithdrawal] = useState<Withdrawal | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);

  // Redirect to auth if not logged in
  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/auth');
    }
  }, [user, authLoading, navigate]);

  // Fetch withdrawals
  const fetchWithdrawals = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      let query = supabase
        .from('transactions')
        .select('*')
        .eq('user_id', user.id)
        .eq('type', 'send')
        .order('created_at', { ascending: false });

      if (filter !== 'all') {
        query = query.eq('status', filter);
      }

      const { data, error } = await query;
      
      if (error) throw error;
      setWithdrawals(data || []);
    } catch (error) {
      console.error('Error fetching withdrawals:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchWithdrawals();
    }
  }, [user, filter]);

  // Real-time subscription for withdrawals
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel('withdrawal-history-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'transactions',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          const transaction = payload.new as Withdrawal;
          if (transaction.type === 'send' || (payload.old as any)?.type === 'send') {
            fetchWithdrawals();
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const getTotalWithdrawals = () => {
    return withdrawals
      .filter(w => w.status === 'completed')
      .reduce((sum, w) => sum + w.amount, 0);
  };

  if (authLoading || !user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-md mx-auto px-4 pb-24">
        <header className="flex items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/')}
              className="p-2 rounded-full bg-secondary/50 hover:bg-secondary transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-semibold">Withdrawal History</h1>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={fetchWithdrawals}
            disabled={loading}
          >
            <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
          </Button>
        </header>

        {/* Stats Card */}
        <div className="glass-card p-4 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Withdrawals</p>
              <p className="text-2xl font-bold">{withdrawals.length}</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Completed Value</p>
              <p className="text-lg font-semibold text-orange-500">
                ${getTotalWithdrawals().toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
            </div>
          </div>
        </div>

        {/* Filter */}
        <div className="flex items-center gap-2 mb-4">
          <Filter className="w-4 h-4 text-muted-foreground" />
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Filter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Real-time indicator */}
        <div className="flex items-center gap-2 mb-4 text-xs text-muted-foreground">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
          <span>Real-time updates enabled</span>
        </div>

        {/* Withdrawal List */}
        <div className="space-y-3">
          {loading ? (
            <div className="text-center py-8 text-muted-foreground">
              Loading withdrawals...
            </div>
          ) : withdrawals.length === 0 ? (
            <div className="text-center py-12">
              <ArrowUpRight className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No withdrawals yet</p>
              <Button
                onClick={() => navigate('/send')}
                className="mt-4"
              >
                Send Crypto
              </Button>
            </div>
          ) : (
            withdrawals.map((withdrawal) => (
              <button
                key={withdrawal.id}
                onClick={() => {
                  setSelectedWithdrawal(withdrawal);
                  setDetailsOpen(true);
                }}
                className="w-full text-left glass-card p-4 hover:bg-secondary/30 transition-colors cursor-pointer"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-orange-500/20 flex items-center justify-center">
                      <ArrowUpRight className="w-5 h-5 text-orange-500" />
                    </div>
                    <div>
                      <p className="font-medium">
                        -{withdrawal.amount} {withdrawal.from_currency}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(withdrawal.created_at), 'MMM dd, yyyy HH:mm')}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs ${statusColors[withdrawal.status as keyof typeof statusColors] || 'bg-secondary'}`}>
                      {statusIcons[withdrawal.status as keyof typeof statusIcons]}
                      {withdrawal.status}
                    </span>
                    {withdrawal.fee && (
                      <p className="text-xs text-muted-foreground mt-1">
                        Fee: {withdrawal.fee} {withdrawal.from_currency}
                      </p>
                    )}
                  </div>
                </div>
                {withdrawal.recipient_address && (
                  <div className="mt-2 pt-2 border-t border-border">
                    <p className="text-xs text-muted-foreground truncate">
                      To: {withdrawal.recipient_address}
                    </p>
                  </div>
                )}
                {withdrawal.tx_hash && (
                  <div className="mt-1">
                    <p className="text-xs text-muted-foreground truncate">
                      TX: {withdrawal.tx_hash}
                    </p>
                  </div>
                )}
              </button>
            ))
          )}
        </div>
      </div>

      <TransactionDetailsModal
        transaction={selectedWithdrawal}
        open={detailsOpen}
        onOpenChange={setDetailsOpen}
      />

      <BottomNav />
    </div>
  );
};

export default WithdrawalHistory;