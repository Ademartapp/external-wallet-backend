import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Loader2, Clock, CheckCircle, XCircle, AlertCircle, ShoppingCart, Receipt } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useQuidax } from '@/hooks/useQuidax';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { format, formatDistanceToNow } from 'date-fns';
import { TransactionReceipt } from '@/components/TransactionReceipt';

interface BuyOrder {
  id: string;
  ngn_amount: number;
  crypto_amount: number;
  crypto_currency: string;
  status: string;
  created_at: string;
  payment_method: string;
}

const BuyOrders = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user } = useAuth();
  const { getBuyOrders, cancelBuyOrder } = useQuidax();
  
  const [orders, setOrders] = useState<BuyOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [cancellingId, setCancellingId] = useState<string | null>(null);
  const [selectedReceipt, setSelectedReceipt] = useState<BuyOrder | null>(null);

  const loadOrders = async () => {
    try {
      setLoading(true);
      const data = await getBuyOrders();
      setOrders(data);
    } catch (err) {
      console.error('Failed to load orders:', err);
      toast({
        title: 'Error',
        description: 'Failed to load buy orders',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      loadOrders();
    }
  }, [user]);

  // Subscribe to realtime updates
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel('buy-orders-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'transactions',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          console.log('Buy order update:', payload);
          if (payload.new && (payload.new as any).type === 'buy') {
            loadOrders();
            
            if (payload.eventType === 'UPDATE') {
              const newStatus = (payload.new as any).status;
              if (newStatus === 'completed') {
                toast({
                  title: 'Order Completed!',
                  description: 'Your crypto has been credited to your wallet.',
                });
              }
            }
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, toast]);

  const handleCancel = async (orderId: string) => {
    try {
      setCancellingId(orderId);
      await cancelBuyOrder(orderId);
      toast({
        title: 'Order Cancelled',
        description: 'Your buy order has been cancelled.',
      });
      loadOrders();
    } catch (err) {
      toast({
        title: 'Error',
        description: err instanceof Error ? err.message : 'Failed to cancel order',
        variant: 'destructive',
      });
    } finally {
      setCancellingId(null);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'pending':
        return <Clock className="w-5 h-5 text-amber-500" />;
      case 'cancelled':
      case 'failed':
        return <XCircle className="w-5 h-5 text-red-500" />;
      default:
        return <AlertCircle className="w-5 h-5 text-muted-foreground" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-500/10 text-green-500';
      case 'pending':
        return 'bg-amber-500/10 text-amber-500';
      case 'cancelled':
      case 'failed':
        return 'bg-red-500/10 text-red-500';
      default:
        return 'bg-secondary text-muted-foreground';
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Please log in to view buy orders</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-md mx-auto px-4 pb-8">
        <header className="flex items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/buy')}
              className="p-2 rounded-full bg-secondary/50 hover:bg-secondary transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-semibold">Buy Orders</h1>
          </div>
        </header>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : orders.length === 0 ? (
          <div className="text-center py-20">
            <ShoppingCart className="w-16 h-16 mx-auto text-muted-foreground/50 mb-4" />
            <p className="text-muted-foreground">No buy orders yet</p>
            <Button className="mt-4" onClick={() => navigate('/buy')}>
              Buy Crypto
            </Button>
          </div>
        ) : (
          <div className="space-y-4 animate-fade-in">
            {orders.map((order) => (
              <div
                key={order.id}
                className="glass-card p-4 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(order.status)}
                    <div>
                      <p className="font-semibold">
                        Buy {order.crypto_amount.toFixed(8)} {order.crypto_currency}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        ₦{order.ngn_amount.toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                    {order.status}
                  </span>
                </div>

                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>
                    {format(new Date(order.created_at), 'MMM dd, yyyy HH:mm')}
                  </span>
                  <span>
                    {formatDistanceToNow(new Date(order.created_at), { addSuffix: true })}
                  </span>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-border/30">
                  <span className="text-xs text-muted-foreground capitalize">
                    {order.payment_method.replace('_', ' ')}
                  </span>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedReceipt(order)}
                    >
                      <Receipt className="w-4 h-4 mr-1" />
                      Receipt
                    </Button>
                    {order.status === 'pending' && (
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleCancel(order.id)}
                        disabled={cancellingId === order.id}
                      >
                        {cancellingId === order.id ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          'Cancel'
                        )}
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {selectedReceipt && (
        <TransactionReceipt
          open={!!selectedReceipt}
          onOpenChange={() => setSelectedReceipt(null)}
          transaction={{
            id: selectedReceipt.id,
            type: 'buy',
            amount: selectedReceipt.crypto_amount,
            currency: selectedReceipt.crypto_currency,
            ngnAmount: selectedReceipt.ngn_amount,
            status: selectedReceipt.status,
            createdAt: selectedReceipt.created_at,
            paymentMethod: selectedReceipt.payment_method,
          }}
        />
      )}
    </div>
  );
};

export default BuyOrders;
