import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Loader2, Clock, CheckCircle, XCircle, Building2, Smartphone, RefreshCw, Timer, X, Receipt } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { useQuidax } from '@/hooks/useQuidax';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { format, differenceInMinutes } from 'date-fns';
import { TransactionReceipt } from '@/components/TransactionReceipt';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface SellOrder {
  id: string;
  crypto_amount: number;
  crypto_currency: string;
  ngn_currency: string;
  status: string;
  created_at: string;
  tx_hash: string;
  payout_type: string;
  bank_code: string;
  account_number: string;
  account_name: string;
}

// ETA configuration in minutes
const ETA_CONFIG = {
  bank: { min: 5, max: 30 },
  mobile_money: { min: 1, max: 10 },
};

const statusConfig: Record<string, { icon: React.ReactNode; color: string; label: string }> = {
  pending: {
    icon: <Clock className="w-4 h-4" />,
    color: 'text-yellow-500 bg-yellow-500/10',
    label: 'Processing',
  },
  completed: {
    icon: <CheckCircle className="w-4 h-4" />,
    color: 'text-green-500 bg-green-500/10',
    label: 'Completed',
  },
  failed: {
    icon: <XCircle className="w-4 h-4" />,
    color: 'text-red-500 bg-red-500/10',
    label: 'Failed',
  },
  cancelled: {
    icon: <X className="w-4 h-4" />,
    color: 'text-gray-500 bg-gray-500/10',
    label: 'Cancelled',
  },
};

function getETA(order: SellOrder): { etaText: string; progress: number; isOverdue: boolean } | null {
  if (order.status !== 'pending') return null;

  const isMobile = order.payout_type === 'mobile_money';
  const eta = isMobile ? ETA_CONFIG.mobile_money : ETA_CONFIG.bank;
  const createdAt = new Date(order.created_at);
  const now = new Date();
  const minutesElapsed = differenceInMinutes(now, createdAt);
  
  const expectedMinutes = (eta.min + eta.max) / 2;
  const progress = Math.min((minutesElapsed / expectedMinutes) * 100, 100);
  const isOverdue = minutesElapsed > eta.max;
  
  if (isOverdue) {
    return {
      etaText: 'Taking longer than expected',
      progress: 100,
      isOverdue: true,
    };
  }
  
  const remainingMin = Math.max(eta.min - minutesElapsed, 0);
  const remainingMax = Math.max(eta.max - minutesElapsed, 1);
  
  if (remainingMin === 0) {
    return {
      etaText: `Arriving in ~${remainingMax} min`,
      progress,
      isOverdue: false,
    };
  }
  
  return {
    etaText: `ETA: ${remainingMin}-${remainingMax} min`,
    progress,
    isOverdue: false,
  };
}

const SellOrders = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user } = useAuth();
  const { getSellOrders, cancelSellOrder, loading } = useQuidax();
  
  const [orders, setOrders] = useState<SellOrder[]>([]);
  const [loadingOrders, setLoadingOrders] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [, setTick] = useState(0);
  const [cancellingOrder, setCancellingOrder] = useState<string | null>(null);
  const [orderToCancel, setOrderToCancel] = useState<SellOrder | null>(null);
  const [selectedReceipt, setSelectedReceipt] = useState<SellOrder | null>(null);

  const fetchOrders = async () => {
    try {
      const data = await getSellOrders();
      setOrders(data);
    } catch (err) {
      console.error('Failed to fetch orders:', err);
      toast({
        title: 'Error',
        description: 'Could not load sell orders',
        variant: 'destructive',
      });
    } finally {
      setLoadingOrders(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchOrders();
    }
  }, [user]);

  // Update ETA every minute
  useEffect(() => {
    const interval = setInterval(() => {
      setTick((t) => t + 1);
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  // Real-time updates for order status changes
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel('sell-orders-updates')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'transactions',
          filter: `user_id=eq.${user.id}`,
        },
        async (payload) => {
          const updated = payload.new as any;
          if (updated.type === 'sell') {
            const oldOrder = orders.find((o) => o.id === updated.id);
            
            setOrders((prev) =>
              prev.map((order) =>
                order.id === updated.id
                  ? { ...order, status: updated.status }
                  : order
              )
            );
            
            // Show notification for status changes
            if (oldOrder?.status === 'pending' && updated.status === 'completed') {
              toast({
                title: '🎉 Payout Complete!',
                description: 'Your NGN has been sent to your account.',
              });
              
              // Trigger browser notification if permitted
              if ('Notification' in window && Notification.permission === 'granted') {
                new Notification('Payout Complete!', {
                  body: 'Your NGN has been sent to your account.',
                  icon: '/favicon.ico',
                });
              }
            } else if (updated.status === 'failed') {
              toast({
                title: 'Payout Failed',
                description: 'There was an issue with your payout. Please contact support.',
                variant: 'destructive',
              });
            }
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, toast, orders]);

  // Request notification permission
  useEffect(() => {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }
  }, []);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchOrders();
  };

  const handleCancelOrder = async () => {
    if (!orderToCancel) return;
    
    setCancellingOrder(orderToCancel.id);
    try {
      const result = await cancelSellOrder(orderToCancel.id);
      toast({
        title: 'Order Cancelled',
        description: result.message,
      });
      // Update local state
      setOrders((prev) =>
        prev.map((order) =>
          order.id === orderToCancel.id
            ? { ...order, status: 'cancelled' }
            : order
        )
      );
    } catch (err) {
      console.error('Failed to cancel order:', err);
      toast({
        title: 'Cancel Failed',
        description: err instanceof Error ? err.message : 'Could not cancel order',
        variant: 'destructive',
      });
    } finally {
      setCancellingOrder(null);
      setOrderToCancel(null);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Please log in to view orders</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-md mx-auto px-4 pb-8">
        <header className="flex items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/sell')}
              className="p-2 rounded-full bg-secondary/50 hover:bg-secondary transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-semibold">Sell Orders</h1>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleRefresh}
            disabled={refreshing}
          >
            <RefreshCw className={`w-5 h-5 ${refreshing ? 'animate-spin' : ''}`} />
          </Button>
        </header>

        {loadingOrders ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : orders.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-muted-foreground mb-4">No sell orders yet</p>
            <Button onClick={() => navigate('/sell')}>
              Sell Crypto Now
            </Button>
          </div>
        ) : (
          <div className="space-y-4 animate-fade-in">
            {orders.map((order) => {
              const status = statusConfig[order.status] || statusConfig.pending;
              const isMobile = order.payout_type === 'mobile_money';
              const etaInfo = getETA(order);
              const canCancel = order.status === 'pending';
              
              return (
                <div
                  key={order.id}
                  className="glass-card p-4 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-full ${status.color}`}>
                        {status.icon}
                      </div>
                      <div>
                        <p className="font-semibold">
                          {order.crypto_amount} {order.crypto_currency}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {format(new Date(order.created_at), 'MMM d, yyyy HH:mm')}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${status.color}`}>
                        {status.label}
                      </span>
                      {canCancel && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-muted-foreground hover:text-destructive"
                          onClick={() => setOrderToCancel(order)}
                          disabled={cancellingOrder === order.id}
                        >
                          {cancellingOrder === order.id ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <X className="w-4 h-4" />
                          )}
                        </Button>
                      )}
                    </div>
                  </div>

                  {/* ETA Progress for pending orders */}
                  {etaInfo && (
                    <div className="space-y-2 py-2">
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          <Timer className={`w-4 h-4 ${etaInfo.isOverdue ? 'text-orange-500' : 'text-primary'}`} />
                          <span className={etaInfo.isOverdue ? 'text-orange-500' : 'text-foreground'}>
                            {etaInfo.etaText}
                          </span>
                        </div>
                        <span className="text-muted-foreground text-xs">
                          {isMobile ? '1-10 min typical' : '5-30 min typical'}
                        </span>
                      </div>
                      <Progress 
                        value={etaInfo.progress} 
                        className={`h-2 ${etaInfo.isOverdue ? '[&>div]:bg-orange-500' : ''}`}
                      />
                    </div>
                  )}

                  <div className="pt-3 border-t border-border/30 space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Payout Method</span>
                      <div className="flex items-center gap-2">
                        {isMobile ? (
                          <Smartphone className="w-4 h-4 text-muted-foreground" />
                        ) : (
                          <Building2 className="w-4 h-4 text-muted-foreground" />
                        )}
                        <span>{isMobile ? 'Mobile Money' : 'Bank Transfer'}</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">
                        {isMobile ? 'Phone Number' : 'Account'}
                      </span>
                      <span className="font-mono">
                        {order.account_number ? `***${order.account_number.slice(-4)}` : '-'}
                      </span>
                    </div>

                    {order.account_name && (
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Recipient</span>
                        <span className="truncate max-w-[180px]">{order.account_name}</span>
                      </div>
                    )}

                    {order.tx_hash && (
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Reference</span>
                        <span className="font-mono text-xs">{order.tx_hash.slice(0, 12)}...</span>
                      </div>
                    )}
                    
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full mt-2"
                      onClick={() => setSelectedReceipt(order)}
                    >
                      <Receipt className="w-4 h-4 mr-2" />
                      View Receipt
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Cancel Confirmation Dialog */}
      <AlertDialog open={!!orderToCancel} onOpenChange={() => setOrderToCancel(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Cancel Sell Order?</AlertDialogTitle>
            <AlertDialogDescription>
              This will cancel your sell order for {orderToCancel?.crypto_amount} {orderToCancel?.crypto_currency}. 
              Your crypto will be returned to your wallet.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Keep Order</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleCancelOrder}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Cancel Order
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Transaction Receipt Modal */}
      {selectedReceipt && (
        <TransactionReceipt
          open={!!selectedReceipt}
          onOpenChange={() => setSelectedReceipt(null)}
          transaction={{
            id: selectedReceipt.id,
            type: 'sell',
            amount: selectedReceipt.crypto_amount,
            currency: selectedReceipt.crypto_currency,
            status: selectedReceipt.status,
            createdAt: selectedReceipt.created_at,
            payoutDetails: selectedReceipt.account_name,
            txHash: selectedReceipt.tx_hash,
          }}
        />
      )}
    </div>
  );
};

export default SellOrders;
