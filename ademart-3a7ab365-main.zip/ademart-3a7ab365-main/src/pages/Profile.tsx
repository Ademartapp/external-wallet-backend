import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, User, AtSign, Check, X, Loader2, Bell, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { useProfile } from '@/hooks/useProfile';
import { useAuth } from '@/contexts/AuthContext';
import { BottomNav } from '@/components/BottomNav';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useToast } from '@/hooks/use-toast';
import { useWebPushNotifications } from '@/hooks/useWebPushNotifications';
import { useAdmin } from '@/hooks/useAdmin';
import { TwoFactorSetup } from '@/components/TwoFactorSetup';
import { NotificationSettings } from '@/components/NotificationSettings';

const Profile = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const { toast } = useToast();
  const { profile, isLoading, updateProfile, isUpdating, checkCryptoTagAvailable } = useProfile();
  const { requestPermission } = useWebPushNotifications();
  const { isAdmin } = useAdmin();

  // Redirect to auth if not logged in
  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/auth');
    }
  }, [user, authLoading, navigate]);
  
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [cryptoTag, setCryptoTag] = useState('');
  const [tagAvailable, setTagAvailable] = useState<boolean | null>(null);
  const [checkingTag, setCheckingTag] = useState(false);

  // Initialize form when profile loads
  useEffect(() => {
    if (profile) {
      setFullName(profile.full_name || '');
      setUsername(profile.username || '');
      setCryptoTag(profile.crypto_tag || '');
    }
  }, [profile]);

  const handleTagChange = async (value: string) => {
    const tag = value.toLowerCase().replace(/[^a-z0-9_]/g, '');
    setCryptoTag(tag);
    
    if (tag.length >= 3) {
      setCheckingTag(true);
      const available = await checkCryptoTagAvailable(tag);
      setTagAvailable(tag === profile?.crypto_tag || available);
      setCheckingTag(false);
    } else {
      setTagAvailable(null);
    }
  };

  const handleSave = () => {
    if (cryptoTag && cryptoTag.length < 3) {
      toast({
        title: 'Invalid Tag',
        description: 'Crypto tag must be at least 3 characters',
        variant: 'destructive',
      });
      return;
    }

    if (tagAvailable === false) {
      toast({
        title: 'Tag Unavailable',
        description: 'This crypto tag is already taken',
        variant: 'destructive',
      });
      return;
    }

    updateProfile({
      full_name: fullName || null,
      username: username || null,
      crypto_tag: cryptoTag || null,
    });
  };

  const getInitials = () => {
    if (profile?.full_name) {
      return profile.full_name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
    }
    return user?.email?.charAt(0).toUpperCase() || 'U';
  };

  // Show loading only while auth is initializing
  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin" />
      </div>
    );
  }

  // Show loading while profile is loading (user is authenticated)
  if (user && isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-md mx-auto px-4 pb-24">
        <header className="flex items-center gap-4 py-4">
          <button
            onClick={() => navigate('/')}
            className="p-2 rounded-full bg-secondary/50 hover:bg-secondary transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-semibold">Profile</h1>
        </header>

        <div className="space-y-6 animate-fade-in">
          {/* Avatar Section */}
          <div className="flex flex-col items-center gap-4 py-6">
            <Avatar className="w-24 h-24">
              <AvatarImage src={profile?.avatar_url || ''} />
              <AvatarFallback className="bg-gradient-to-br from-primary to-cyan-400 text-2xl font-bold">
                {getInitials()}
              </AvatarFallback>
            </Avatar>
            <div className="text-center">
              <p className="font-semibold text-lg">{profile?.full_name || 'Anonymous User'}</p>
              <p className="text-sm text-muted-foreground">{user?.email}</p>
              {profile?.crypto_tag && (
                <p className="text-primary text-sm font-medium">@{profile.crypto_tag}</p>
              )}
            </div>
          </div>

          {/* Form */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="fullName">Full Name</Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="fullName"
                  placeholder="Your full name"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="pl-10 bg-secondary/50 border-border/50"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                placeholder="Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="bg-secondary/50 border-border/50"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="cryptoTag">Crypto Tag</Label>
              <div className="relative">
                <AtSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="cryptoTag"
                  placeholder="your_crypto_tag"
                  value={cryptoTag}
                  onChange={(e) => handleTagChange(e.target.value)}
                  className="pl-10 pr-10 bg-secondary/50 border-border/50"
                  maxLength={20}
                />
                {checkingTag && (
                  <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-muted-foreground" />
                )}
                {!checkingTag && tagAvailable === true && (
                  <Check className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-green-500" />
                )}
                {!checkingTag && tagAvailable === false && (
                  <X className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-destructive" />
                )}
              </div>
              <p className="text-xs text-muted-foreground">
                Unique tag for receiving crypto. Only lowercase letters, numbers, and underscores.
              </p>
            </div>

            <Button
              onClick={handleSave}
              disabled={isUpdating || tagAvailable === false}
              className="w-full bg-primary hover:bg-primary/90"
            >
              {isUpdating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                'Save Changes'
              )}
            </Button>
          </div>

          {/* Push Notifications */}
          <NotificationSettings />

          {/* Two-Factor Authentication */}
          <TwoFactorSetup />

          {/* Admin Link */}
          {isAdmin && (
            <Button
              variant="outline"
              onClick={() => navigate('/admin')}
              className="w-full"
            >
              <Shield className="w-4 h-4 mr-2" />
              Admin Panel
            </Button>
          )}

          {/* Account Info */}
          <div className="glass-card p-4 space-y-3">
            <h3 className="font-medium">Account Info</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Email</span>
                <span>{user?.email}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Member Since</span>
                <span>{new Date(user?.created_at || '').toLocaleDateString()}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  );
};

export default Profile;
