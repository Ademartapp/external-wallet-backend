import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ChevronDown, Banknote, Loader2, CheckCircle, Smartphone, Building2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useQuidax } from '@/hooks/useQuidax';
import { useRealtimeWallets } from '@/hooks/useRealtimeWallets';
import { useAuth } from '@/contexts/AuthContext';

interface CryptoAsset {
  symbol: string;
  name: string;
  balance: number;
  rateNGN: number;
}

type PayoutType = 'bank' | 'mobile_money';

const Sell = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user } = useAuth();
  const { wallets } = useRealtimeWallets();
  const { loading, getRates, getBanks, getMobileMoneyProviders, verifyAccount, verifyMobileMoney, sellCrypto } = useQuidax();
  
  const [cryptoAssets, setCryptoAssets] = useState<CryptoAsset[]>([]);
  const [selectedAsset, setSelectedAsset] = useState<CryptoAsset | null>(null);
  const [amount, setAmount] = useState('');
  const [payoutType, setPayoutType] = useState<PayoutType>('bank');
  const [banks, setBanks] = useState<{ code: string; name: string }[]>([]);
  const [mobileProviders, setMobileProviders] = useState<{ code: string; name: string }[]>([]);
  const [selectedBank, setSelectedBank] = useState<{ code: string; name: string } | null>(null);
  const [selectedProvider, setSelectedProvider] = useState<{ code: string; name: string } | null>(null);
  const [accountNumber, setAccountNumber] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [accountName, setAccountName] = useState('');
  const [verifyingAccount, setVerifyingAccount] = useState(false);
  const [accountVerified, setAccountVerified] = useState(false);
  const [showAssetList, setShowAssetList] = useState(false);
  const [showBankList, setShowBankList] = useState(false);
  const [showProviderList, setShowProviderList] = useState(false);
  const [loadingRates, setLoadingRates] = useState(true);
  const [processing, setProcessing] = useState(false);

  // Load rates with fallback to CoinGecko
  const loadRatesWithFallback = async (): Promise<{ currency: string; sell: number; buy: number }[]> => {
    try {
      const rates = await getRates();
      if (rates && rates.length > 0) return rates;
    } catch (err) {
      console.log('Quidax rates failed, using CoinGecko fallback');
    }
    
    // Fallback to CoinGecko
    try {
      const response = await fetch(
        'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,tether,solana&vs_currencies=ngn'
      );
      const data = await response.json();
      
      const coinMap: Record<string, string> = {
        bitcoin: 'BTC',
        ethereum: 'ETH',
        tether: 'USDT',
        solana: 'SOL',
      };
      
      return Object.entries(coinMap).map(([id, symbol]) => {
        const ngnRate = data[id]?.ngn || 0;
        return {
          currency: symbol,
          sell: ngnRate * 0.98, // 2% spread
          buy: ngnRate,
        };
      }).filter(r => r.sell > 0);
    } catch (cgError) {
      console.error('CoinGecko fallback also failed:', cgError);
      return [];
    }
  };

  useEffect(() => {
    async function loadData() {
      try {
        setLoadingRates(true);
        
        // Load rates, banks, and providers independently
        const [rates, bankList, providerList] = await Promise.allSettled([
          loadRatesWithFallback(),
          getBanks().catch(() => []),
          getMobileMoneyProviders().catch(() => []),
        ]);

        // Process rates
        const ratesData = rates.status === 'fulfilled' ? rates.value : [];
        if (ratesData.length > 0) {
          const assets: CryptoAsset[] = ratesData.map((rate) => {
            const wallet = wallets.find(w => w.currency === rate.currency);
            return {
              symbol: rate.currency,
              name: getCryptoName(rate.currency),
              balance: wallet?.balance || 0,
              rateNGN: rate.sell,
            };
          });

          setCryptoAssets(assets);
          if (assets.length > 0) {
            setSelectedAsset(assets[0]);
          }
        } else {
          toast({
            title: 'Exchange rates unavailable',
            description: 'Unable to fetch exchange rates. Please try again later.',
            variant: 'destructive',
          });
        }

        // Process banks
        const banksData = bankList.status === 'fulfilled' ? bankList.value : [];
        setBanks(banksData.map((b: any) => ({ code: b.code, name: b.name })));

        // Process mobile providers
        const providersData = providerList.status === 'fulfilled' ? providerList.value : [];
        setMobileProviders(providersData.map((p: any) => ({ code: p.code, name: p.name })));
      } catch (err) {
        console.error('Failed to load data:', err);
        toast({
          title: 'Error loading data',
          description: 'Could not load exchange rates. Please try again.',
          variant: 'destructive',
        });
      } finally {
        setLoadingRates(false);
      }
    }

    if (user) {
      loadData();
    }
  }, [user, wallets]);

  function getCryptoName(symbol: string): string {
    const names: Record<string, string> = {
      BTC: 'Bitcoin',
      ETH: 'Ethereum',
      USDT: 'Tether',
      SOL: 'Solana',
    };
    return names[symbol] || symbol;
  }

  const nairaAmount = amount && selectedAsset
    ? (parseFloat(amount) * selectedAsset.rateNGN).toLocaleString('en-NG')
    : '0';

  // Verify bank account
  useEffect(() => {
    async function verify() {
      if (payoutType === 'bank' && selectedBank && accountNumber.length === 10) {
        setVerifyingAccount(true);
        setAccountVerified(false);
        try {
          const result = await verifyAccount(selectedBank.code, accountNumber);
          setAccountName(result.account_name);
          setAccountVerified(true);
        } catch (err) {
          console.error('Account verification failed:', err);
          setAccountName('');
          toast({
            title: 'Verification Failed',
            description: 'Could not verify account. Please check the details.',
            variant: 'destructive',
          });
        } finally {
          setVerifyingAccount(false);
        }
      }
    }
    verify();
  }, [selectedBank, accountNumber, payoutType]);

  // Verify mobile money
  useEffect(() => {
    async function verify() {
      if (payoutType === 'mobile_money' && selectedProvider && phoneNumber.length >= 10) {
        setVerifyingAccount(true);
        setAccountVerified(false);
        try {
          const result = await verifyMobileMoney(selectedProvider.code, phoneNumber);
          setAccountName(result.account_name);
          setAccountVerified(true);
        } catch (err) {
          console.error('Mobile money verification failed:', err);
          // For mobile money, allow proceeding even without verification
          setAccountName(`${selectedProvider.name} (${phoneNumber})`);
          setAccountVerified(true);
        } finally {
          setVerifyingAccount(false);
        }
      }
    }
    verify();
  }, [selectedProvider, phoneNumber, payoutType]);

  // Reset when switching payout type
  useEffect(() => {
    setAccountVerified(false);
    setAccountName('');
    setAccountNumber('');
    setPhoneNumber('');
    setSelectedBank(null);
    setSelectedProvider(null);
  }, [payoutType]);

  const handleSell = async () => {
    if (!selectedAsset) return;

    if (!amount || parseFloat(amount) <= 0) {
      toast({
        title: 'Invalid Amount',
        description: 'Please enter a valid amount to sell',
        variant: 'destructive',
      });
      return;
    }

    const isBank = payoutType === 'bank';
    const hasPayoutDetails = isBank 
      ? selectedBank && accountNumber && accountName
      : selectedProvider && phoneNumber && accountName;

    if (!hasPayoutDetails) {
      toast({
        title: 'Payout Details Required',
        description: `Please enter and verify your ${isBank ? 'bank account' : 'mobile money'} details`,
        variant: 'destructive',
      });
      return;
    }

    if (parseFloat(amount) > selectedAsset.balance) {
      toast({
        title: 'Insufficient Balance',
        description: `You don't have enough ${selectedAsset.symbol}`,
        variant: 'destructive',
      });
      return;
    }

    setProcessing(true);
    try {
      const result = await sellCrypto(
        selectedAsset.symbol,
        parseFloat(amount),
        isBank ? selectedBank!.code : selectedProvider!.code,
        isBank ? accountNumber : phoneNumber,
        accountName,
        payoutType
      );

      toast({
        title: 'Sell Order Placed!',
        description: result.message,
      });

      setAmount('');
      navigate('/sell-orders');
    } catch (err) {
      console.error('Sell failed:', err);
      toast({
        title: 'Sell Failed',
        description: err instanceof Error ? err.message : 'Unknown error occurred',
        variant: 'destructive',
      });
    } finally {
      setProcessing(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Please log in to sell crypto</p>
      </div>
    );
  }

  if (loadingRates) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-md mx-auto px-4 pb-8">
        <header className="flex items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/')}
              className="p-2 rounded-full bg-secondary/50 hover:bg-secondary transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-semibold">Sell to Naira</h1>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('/sell-orders')}
            className="text-primary"
          >
            View Orders
          </Button>
        </header>

        <div className="space-y-6 animate-fade-in">
          <div className="glass-card p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-green-500 to-green-700 flex items-center justify-center">
                <Banknote className="w-6 h-6 text-foreground" />
              </div>
              <div>
                <p className="font-semibold">Convert to NGN</p>
                <p className="text-sm text-muted-foreground">Receive Naira instantly</p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            {/* Crypto Selection */}
            <div className="space-y-2">
              <Label>Select Crypto</Label>
              <div className="relative">
                <button
                  onClick={() => setShowAssetList(!showAssetList)}
                  className="w-full flex items-center justify-between p-4 rounded-xl bg-secondary/50 border border-border/50"
                >
                  <div className="flex items-center gap-3">
                    <span className="font-medium">{selectedAsset?.symbol}</span>
                    <span className="text-muted-foreground">{selectedAsset?.name}</span>
                  </div>
                  <ChevronDown className="w-5 h-5 text-muted-foreground" />
                </button>
                {showAssetList && (
                  <div className="absolute top-full mt-2 left-0 right-0 bg-card border border-border rounded-xl shadow-xl z-10 overflow-hidden max-h-60 overflow-y-auto">
                    {cryptoAssets.map((asset) => (
                      <button
                        key={asset.symbol}
                        onClick={() => {
                          setSelectedAsset(asset);
                          setShowAssetList(false);
                        }}
                        className="w-full px-4 py-3 text-left hover:bg-secondary/50 transition-colors flex justify-between items-center"
                      >
                        <div>
                          <span className="font-medium">{asset.symbol}</span>
                          <span className="text-muted-foreground ml-2">{asset.name}</span>
                        </div>
                        <span className="text-sm text-muted-foreground">
                          {asset.balance.toFixed(6)} available
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Amount */}
            <div className="space-y-2">
              <div className="flex justify-between">
                <Label htmlFor="amount">Amount</Label>
                {selectedAsset && (
                  <button
                    onClick={() => setAmount(selectedAsset.balance.toString())}
                    className="text-xs text-primary hover:underline"
                  >
                    MAX
                  </button>
                )}
              </div>
              <Input
                id="amount"
                type="number"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="bg-secondary/50 border-border/50 text-xl font-semibold"
              />
              <p className="text-sm text-muted-foreground">
                Available: {selectedAsset?.balance.toFixed(6)} {selectedAsset?.symbol}
              </p>
            </div>

            {/* Naira Amount */}
            <div className="glass-card p-4">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">You'll receive</span>
                <div className="text-right">
                  <p className="text-2xl font-bold text-primary">₦{nairaAmount}</p>
                  <p className="text-xs text-muted-foreground">
                    Rate: ₦{selectedAsset?.rateNGN.toLocaleString()}/{selectedAsset?.symbol}
                  </p>
                </div>
              </div>
            </div>

            {/* Payout Type Selection */}
            <div className="space-y-2">
              <Label>Payout Method</Label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setPayoutType('bank')}
                  className={`p-4 rounded-xl border transition-all flex flex-col items-center gap-2 ${
                    payoutType === 'bank'
                      ? 'border-primary bg-primary/10'
                      : 'border-border/50 bg-secondary/50 hover:border-border'
                  }`}
                >
                  <Building2 className={`w-6 h-6 ${payoutType === 'bank' ? 'text-primary' : 'text-muted-foreground'}`} />
                  <span className={`font-medium ${payoutType === 'bank' ? 'text-primary' : ''}`}>Bank Transfer</span>
                </button>
                <button
                  onClick={() => setPayoutType('mobile_money')}
                  className={`p-4 rounded-xl border transition-all flex flex-col items-center gap-2 ${
                    payoutType === 'mobile_money'
                      ? 'border-primary bg-primary/10'
                      : 'border-border/50 bg-secondary/50 hover:border-border'
                  }`}
                >
                  <Smartphone className={`w-6 h-6 ${payoutType === 'mobile_money' ? 'text-primary' : 'text-muted-foreground'}`} />
                  <span className={`font-medium ${payoutType === 'mobile_money' ? 'text-primary' : ''}`}>Mobile Money</span>
                </button>
              </div>
            </div>

            {/* Bank Payout Details */}
            {payoutType === 'bank' && (
              <div className="space-y-4 pt-4 border-t border-border/30">
                <p className="font-medium">Bank Details</p>
                
                <div className="space-y-2">
                  <Label>Select Bank</Label>
                  <div className="relative">
                    <button
                      onClick={() => setShowBankList(!showBankList)}
                      className="w-full flex items-center justify-between p-4 rounded-xl bg-secondary/50 border border-border/50"
                    >
                      <span className={selectedBank ? 'font-medium' : 'text-muted-foreground'}>
                        {selectedBank?.name || 'Select a bank'}
                      </span>
                      <ChevronDown className="w-5 h-5 text-muted-foreground" />
                    </button>
                    {showBankList && (
                      <div className="absolute top-full mt-2 left-0 right-0 bg-card border border-border rounded-xl shadow-xl z-10 overflow-hidden max-h-60 overflow-y-auto">
                        {banks.map((bank) => (
                          <button
                            key={bank.code}
                            onClick={() => {
                              setSelectedBank(bank);
                              setShowBankList(false);
                              setAccountVerified(false);
                              setAccountName('');
                            }}
                            className="w-full px-4 py-3 text-left hover:bg-secondary/50 transition-colors"
                          >
                            {bank.name}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="accountNumber">Account Number</Label>
                  <div className="relative">
                    <Input
                      id="accountNumber"
                      placeholder="Enter 10-digit account number"
                      value={accountNumber}
                      onChange={(e) => {
                        setAccountNumber(e.target.value);
                        setAccountVerified(false);
                      }}
                      className="bg-secondary/50 border-border/50"
                      maxLength={10}
                    />
                    {verifyingAccount && (
                      <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-muted-foreground" />
                    )}
                    {accountVerified && (
                      <CheckCircle className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-green-500" />
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="accountName">Account Name</Label>
                  <Input
                    id="accountName"
                    placeholder="Auto-filled after verification"
                    value={accountName}
                    readOnly
                    className="bg-secondary/30 border-border/50"
                  />
                </div>
              </div>
            )}

            {/* Mobile Money Payout Details */}
            {payoutType === 'mobile_money' && (
              <div className="space-y-4 pt-4 border-t border-border/30">
                <p className="font-medium">Mobile Money Details</p>
                
                <div className="space-y-2">
                  <Label>Select Provider</Label>
                  <div className="relative">
                    <button
                      onClick={() => setShowProviderList(!showProviderList)}
                      className="w-full flex items-center justify-between p-4 rounded-xl bg-secondary/50 border border-border/50"
                    >
                      <span className={selectedProvider ? 'font-medium' : 'text-muted-foreground'}>
                        {selectedProvider?.name || 'Select a provider'}
                      </span>
                      <ChevronDown className="w-5 h-5 text-muted-foreground" />
                    </button>
                    {showProviderList && (
                      <div className="absolute top-full mt-2 left-0 right-0 bg-card border border-border rounded-xl shadow-xl z-10 overflow-hidden">
                        {mobileProviders.map((provider) => (
                          <button
                            key={provider.code}
                            onClick={() => {
                              setSelectedProvider(provider);
                              setShowProviderList(false);
                              setAccountVerified(false);
                              setAccountName('');
                            }}
                            className="w-full px-4 py-3 text-left hover:bg-secondary/50 transition-colors"
                          >
                            {provider.name}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phoneNumber">Phone Number</Label>
                  <div className="relative">
                    <Input
                      id="phoneNumber"
                      placeholder="e.g. 08012345678"
                      value={phoneNumber}
                      onChange={(e) => {
                        setPhoneNumber(e.target.value);
                        setAccountVerified(false);
                      }}
                      className="bg-secondary/50 border-border/50"
                      maxLength={11}
                    />
                    {verifyingAccount && (
                      <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-muted-foreground" />
                    )}
                    {accountVerified && (
                      <CheckCircle className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-green-500" />
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="accountNameMobile">Account Name</Label>
                  <Input
                    id="accountNameMobile"
                    placeholder="Auto-filled after verification"
                    value={accountName}
                    readOnly
                    className="bg-secondary/30 border-border/50"
                  />
                </div>
              </div>
            )}

            <Button 
              onClick={handleSell} 
              className="w-full bg-primary hover:bg-primary/90"
              disabled={processing || !accountVerified || loading}
            >
              {processing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                `Sell ${selectedAsset?.symbol || ''}`
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sell;
