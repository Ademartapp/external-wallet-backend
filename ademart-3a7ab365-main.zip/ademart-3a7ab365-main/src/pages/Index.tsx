import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { Header } from "@/components/Header";
import { BalanceCard } from "@/components/BalanceCard";
import { BalanceBreakdown } from "@/components/BalanceBreakdown";
import { QuickActions } from "@/components/QuickActions";
import { CryptoCarousel } from "@/components/CryptoCarousel";
import { AssetList } from "@/components/AssetList";
import { BottomNav } from "@/components/BottomNav";
import { PriceAlerts } from "@/components/PriceAlerts";
import { AlertHistory } from "@/components/AlertHistory";
import { DepositHistoryWidget } from "@/components/DepositHistoryWidget";
import { TokenBalanceMonitor } from "@/components/TokenBalanceMonitor";
import { PriceMovementMonitor } from "@/components/PriceMovementMonitor";
import { TransactionStatusTracker } from "@/components/TransactionStatusTracker";
import { useAuth } from "@/contexts/AuthContext";
import { useProfile } from "@/hooks/useProfile";
import { usePortfolio } from "@/hooks/usePortfolio";
import { useNotifications } from "@/hooks/useNotifications";
import { useWebPushNotifications } from "@/hooks/useWebPushNotifications";
import { useGlobalBalanceSync } from "@/hooks/useGlobalBalanceSync";
import { useRealtimeTransactions } from "@/hooks/useRealtimeTransactions";
import { Button } from "@/components/ui/button";
import { RefreshCw, Bell } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Index = () => {
  // Dashboard main component
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const { profile } = useProfile();
  const { assets, totalUSD, totalNGN, loading: portfolioLoading, refetch } = usePortfolio();
  const { unreadCount } = useNotifications();
  const { isSupported, permission, requestPermission } = useWebPushNotifications();
  const { syncAllBalances, syncing: globalSyncing } = useGlobalBalanceSync();
  const { getPendingTransactions } = useRealtimeTransactions();
  const { toast } = useToast();
  const [currency, setCurrency] = useState<'USD' | 'NGN'>('USD');
  const [pullStartY, setPullStartY] = useState<number | null>(null);
  const [isPulling, setIsPulling] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Request notification permission on first visit
  useEffect(() => {
    if (user && isSupported && permission === 'default') {
      // Don't auto-request, let user do it from profile
    }
  }, [user, isSupported, permission]);

  const handleCurrencyToggle = () => {
    setCurrency(curr => curr === 'USD' ? 'NGN' : 'USD');
  };

  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true);
    await Promise.all([refetch(), syncAllBalances()]);
    setIsRefreshing(false);
    toast({ title: 'Portfolio Updated', description: 'Balances refreshed and on-chain sync complete' });
  }, [refetch, syncAllBalances, toast]);

  // Pull-to-refresh handlers
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    if (window.scrollY === 0) {
      setPullStartY(e.touches[0].clientY);
    }
  }, []);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (pullStartY === null) return;
    const diff = e.touches[0].clientY - pullStartY;
    if (diff > 80 && !isPulling) {
      setIsPulling(true);
    }
  }, [pullStartY, isPulling]);

  const handleTouchEnd = useCallback(async () => {
    if (isPulling && !isRefreshing) {
      await handleRefresh();
    }
    setPullStartY(null);
    setIsPulling(false);
  }, [isPulling, isRefreshing, handleRefresh]);

  const handleEnableNotifications = async () => {
    const granted = await requestPermission();
    if (granted) {
      toast({ title: 'Notifications Enabled', description: 'You will receive alerts for transactions' });
    }
  };

const handleAction = (action: string) => {
    if (!user) {
      navigate('/auth');
      return;
    }

    switch (action) {
      case 'receive':
        navigate('/receive');
        break;
      case 'send':
        navigate('/send');
        break;
      case 'swap':
        navigate('/swap');
        break;
      case 'sell':
        navigate('/sell');
        break;
      case 'buy':
        navigate('/buy');
        break;
      case 'history':
        navigate('/transactions');
        break;
      case 'wallets':
        navigate('/wallets');
        break;
      case 'kyc':
        navigate('/kyc');
        break;
      case 'health':
        navigate('/health');
        break;
      default:
        break;
    }

  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <div className="flex-1 flex flex-col items-center justify-center px-4 text-center">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary to-cyan-400 flex items-center justify-center mb-6">
            <span className="text-3xl font-bold text-primary-foreground">A</span>
          </div>
          <h1 className="text-3xl font-bold mb-2">Ade Mart</h1>
          <p className="text-muted-foreground mb-8 max-w-xs">
            Buy, sell, and swap cryptocurrency. Convert digital assets to Naira instantly.
          </p>
          <div className="w-full max-w-xs space-y-3">
            <Button
              onClick={() => navigate('/auth')}
              className="w-full bg-primary hover:bg-primary/90"
            >
              Get Started
            </Button>
            <Button
              onClick={() => navigate('/markets')}
              variant="outline"
              className="w-full border-border/50"
            >
              View Markets
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Transform portfolio assets to match AssetList format
  const assetListItems = assets.map((asset, index) => ({
    id: index.toString(),
    name: asset.name,
    symbol: asset.symbol,
    balance: asset.balance,
    valueUSD: asset.valueUSD,
    change24h: asset.change24h,
  }));

  return (
    <div 
      className="min-h-screen bg-background"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Pull-to-refresh indicator */}
      {isPulling && (
        <div className="fixed top-0 left-0 right-0 z-50 flex justify-center py-4 bg-primary/10 backdrop-blur-sm">
          <RefreshCw className="w-5 h-5 animate-spin text-primary" />
          <span className="ml-2 text-sm text-primary">Release to refresh</span>
        </div>
      )}
      
      <div className="max-w-md mx-auto px-4 pb-24">
        <Header 
          username={user.user_metadata?.username || user.email?.split('@')[0] || 'User'}
          notificationCount={unreadCount} 
        />

        <div className="space-y-6">
          {/* Notification prompt */}
          {isSupported && permission !== 'granted' && (
            <button
              onClick={handleEnableNotifications}
              className="w-full flex items-center justify-between p-3 rounded-xl bg-primary/10 border border-primary/20 text-sm"
            >
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-primary" />
                <span>Enable notifications for transactions</span>
              </div>
              <span className="text-primary font-medium">Enable</span>
            </button>
          )}

          <div className="relative">
            <BalanceCard
              balance={currency === 'USD' ? totalUSD : totalNGN}
              currency={currency}
              cryptoTag={profile?.crypto_tag}
              onCurrencyChange={handleCurrencyToggle}
            />
            <button
              onClick={handleRefresh}
              disabled={isRefreshing || portfolioLoading}
              className="absolute top-4 right-4 p-2 rounded-full bg-background/50 hover:bg-background/80 transition-colors"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing || portfolioLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>

          <QuickActions onAction={handleAction} />

          <BalanceBreakdown />

          <TokenBalanceMonitor />

          <PriceMovementMonitor />

          {/* Pending Transactions Indicator */}
          {getPendingTransactions().length > 0 && (
            <div className="glass-card p-3 border-l-4 border-yellow-500 bg-yellow-500/10">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-yellow-500 animate-pulse" />
                  <span className="text-sm font-medium">
                    {getPendingTransactions().length} pending transaction(s)
                  </span>
                </div>
                <Button variant="ghost" size="sm" onClick={() => navigate('/transactions')}>
                  View
                </Button>
              </div>
            </div>
          )}

          {/* Transaction Status Tracker */}
          <div className="glass-card p-4">
            <TransactionStatusTracker limit={5} />
          </div>

          <CryptoCarousel />

          <DepositHistoryWidget />

          <AlertHistory />

          <PriceAlerts />

          {portfolioLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" />
            </div>
          ) : assets.length > 0 ? (
            <AssetList assets={assetListItems} />
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <p className="mb-2">No assets yet</p>
              <Button variant="outline" size="sm" onClick={() => navigate('/receive')}>
                Deposit crypto to get started
              </Button>
            </div>
          )}
        </div>
      </div>

      <BottomNav />
    </div>
  );
};

export default Index;