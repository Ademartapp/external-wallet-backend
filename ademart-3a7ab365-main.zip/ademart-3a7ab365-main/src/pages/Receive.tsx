import { useState, useEffect, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Loader2, AlertCircle, Zap, Clock, DollarSign, Bell, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useWalletAddresses, supportedAssets } from '@/hooks/useWalletAddresses';
import { useAuth } from '@/contexts/AuthContext';
import { QRCodeDisplay } from '@/components/QRCodeDisplay';
import { supabase } from '@/integrations/supabase/client';
import { Alert, AlertDescription } from '@/components/ui/alert';

// Network fee estimates with live update support
interface NetworkFeeInfo {
  fee: string;
  speed: string;
  recommended?: boolean;
  gwei?: number;
}

const defaultNetworkFees: Record<string, NetworkFeeInfo> = {
  'ETH': { fee: '$2-15', speed: '~2 min' },
  'TRX': { fee: '$0.5-1', speed: '~1 min', recommended: true },
  'BTC': { fee: '$1-5', speed: '~10 min' },
  'BSC': { fee: '$0.1-0.5', speed: '~15 sec', recommended: true },
  'MATIC': { fee: '$0.01-0.1', speed: '~2 sec', recommended: true },
  'LTC': { fee: '$0.01-0.1', speed: '~2.5 min' },
  'DOGE': { fee: '$0.01-0.05', speed: '~1 min' },
};

const Receive = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user } = useAuth();
  const { createWalletWithChain, isCreating, wallets } = useWalletAddresses();
  
  // Get unique token symbols
  const uniqueTokens = useMemo(() => {
    const tokens = new Map<string, typeof supportedAssets>();
    supportedAssets.forEach(asset => {
      if (!tokens.has(asset.symbol)) {
        tokens.set(asset.symbol, []);
      }
      tokens.get(asset.symbol)!.push(asset);
    });
    return tokens;
  }, []);

  const tokenList = useMemo(() => Array.from(uniqueTokens.keys()), [uniqueTokens]);
  
  const [selectedToken, setSelectedToken] = useState(tokenList[0]);
  const [selectedNetwork, setSelectedNetwork] = useState<string>('');
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [networkFees, setNetworkFees] = useState<Record<string, NetworkFeeInfo>>(defaultNetworkFees);
  const [fetchingFees, setFetchingFees] = useState(false);
  const [depositNotification, setDepositNotification] = useState<{ amount: number; symbol: string } | null>(null);

  // Get available networks for selected token
  const availableNetworks = useMemo(() => {
    return uniqueTokens.get(selectedToken) || [];
  }, [selectedToken, uniqueTokens]);

  // Get current selected asset
  const selectedAsset = useMemo(() => {
    if (!selectedNetwork) return availableNetworks[0];
    return availableNetworks.find(a => a.chain === selectedNetwork) || availableNetworks[0];
  }, [availableNetworks, selectedNetwork]);

  // Initialize and update network when token changes
  useEffect(() => {
    const networks = uniqueTokens.get(selectedToken);
    if (networks && networks.length > 0) {
      // Prefer recommended network if available
      const recommended = networks.find(n => defaultNetworkFees[n.chain]?.recommended);
      const newNetwork = recommended?.chain || networks[0].chain;
      setSelectedNetwork(newNetwork);
      setWalletAddress(null); // Reset address when token changes
    }
  }, [selectedToken, uniqueTokens]);

  // Reset wallet address when network changes
  useEffect(() => {
    setWalletAddress(null);
  }, [selectedNetwork]);

  // Load existing address when asset/network changes
  useEffect(() => {
    if (user && selectedAsset) {
      loadExistingAddress();
    }
  }, [selectedAsset, user, wallets]);

  // Fetch real-time gas fees
  const fetchLiveFees = useCallback(async () => {
    setFetchingFees(true);
    try {
      const { data, error } = await supabase.functions.invoke('gas-fees');
      if (error) throw error;
      if (data?.fees) {
        setNetworkFees(prev => ({
          ...prev,
          ...data.fees,
        }));
      }
    } catch (err) {
      console.log('Using default fees:', err);
    } finally {
      setFetchingFees(false);
    }
  }, []);

  // Fetch fees on mount and periodically
  useEffect(() => {
    fetchLiveFees();
    const interval = setInterval(fetchLiveFees, 30000); // Refresh every 30 seconds
    return () => clearInterval(interval);
  }, [fetchLiveFees]);

  // Subscribe to deposit notifications
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel('deposit-notifications')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'transactions',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          const transaction = payload.new as any;
          // Listen for both "deposit" (new) and "receive" (legacy) types
          if ((transaction.type === 'deposit' || transaction.type === 'receive') && transaction.status === 'completed') {
            setDepositNotification({
              amount: transaction.amount,
              symbol: transaction.from_currency,
            });
            toast({
              title: '💰 Deposit Received!',
              description: `${transaction.amount} ${transaction.from_currency} has been credited to your wallet`,
            });
            // Clear notification after 10 seconds
            setTimeout(() => setDepositNotification(null), 10000);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, toast]);

  const loadExistingAddress = async () => {
    if (!user || !selectedAsset) return;
    setError(null);
    
    // Check for existing address in wallets data (any wallet for this symbol+chain, not just primary)
    const existingWallet = wallets.find(
      w => w.symbol === selectedAsset.symbol && w.chain === selectedAsset.chain
    );

    if (existingWallet) {
      setWalletAddress(existingWallet.address);
      return;
    }
    
    // Check localStorage cache
    try {
      const cacheKey = `wallet_${user.id}_${selectedAsset.symbol}_${selectedAsset.chain}`;
      const cachedAddress = localStorage.getItem(cacheKey);
      if (cachedAddress) {
        setWalletAddress(cachedAddress);
        return;
      }
    } catch (e) {
      console.error('Cache read error:', e);
    }

    // Also check database directly (any wallet for this symbol+chain)
    const { data: dbWallet } = await supabase
      .from('wallet_addresses')
      .select('address')
      .eq('user_id', user.id)
      .eq('symbol', selectedAsset.symbol)
      .eq('chain', selectedAsset.chain)
      .maybeSingle();

    if (dbWallet) {
      setWalletAddress(dbWallet.address);
      // Cache it locally
      try {
        const cacheKey = `wallet_${user.id}_${selectedAsset.symbol}_${selectedAsset.chain}`;
        localStorage.setItem(cacheKey, dbWallet.address);
      } catch (e) {
        console.error('Cache write error:', e);
      }
    } else {
      setWalletAddress(null);
    }
  };

  const handleTokenChange = (token: string) => {
    setSelectedToken(token);
    setWalletAddress(null);
  };

  const handleNetworkChange = (chain: string) => {
    setSelectedNetwork(chain);
    setWalletAddress(null);
  };

  const handleGetAddress = async () => {
    if (!user) {
      toast({
        title: 'Authentication Required',
        description: 'Please log in to get a deposit address',
        variant: 'destructive',
      });
      navigate('/auth');
      return;
    }

    if (!selectedAsset) return;

    setLoading(true);
    setError(null);

    try {
      const result = await createWalletWithChain(selectedAsset.symbol, selectedAsset.chain);
      setWalletAddress(result.address);
      
      // Cache the address locally
      try {
        const cacheKey = `wallet_${user.id}_${selectedAsset.symbol}_${selectedAsset.chain}`;
        localStorage.setItem(cacheKey, result.address);
      } catch (e) {
        console.error('Cache write error:', e);
      }
      
      toast({
        title: 'Wallet Ready',
        description: `Your unique ${selectedAsset.symbol} (${selectedAsset.chain}) address is ready`,
      });
    } catch (err: any) {
      setError(err.message || 'Failed to generate wallet');
      toast({
        title: 'Error',
        description: err.message || 'Failed to generate wallet',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const currentFee = networkFees[selectedNetwork];

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-md mx-auto px-4 pb-8">
        <header className="flex items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/')}
              className="p-2 rounded-full bg-secondary/50 hover:bg-secondary transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-semibold">Receive Crypto</h1>
          </div>
        </header>

        <div className="space-y-6 animate-fade-in">
          {/* Deposit Notification */}
          {depositNotification && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-green-500/20 border border-green-500/30 animate-pulse">
              <CheckCircle className="w-6 h-6 text-green-500" />
              <div>
                <p className="font-medium text-green-500">Deposit Received!</p>
                <p className="text-sm text-green-400">
                  {depositNotification.amount} {depositNotification.symbol} credited
                </p>
              </div>
            </div>
          )}

          {/* Token Selector */}
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Select Token</p>
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
              {tokenList.map((token) => (
                <button
                  key={token}
                  onClick={() => handleTokenChange(token)}
                  className={`px-4 py-2 rounded-full whitespace-nowrap transition-all ${
                    selectedToken === token
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary/50 hover:bg-secondary'
                  }`}
                >
                  {token}
                </button>
              ))}
            </div>
          </div>

          {/* Network Selector (only show if multiple networks) */}
          {availableNetworks.length > 1 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground">Select Network</p>
                {fetchingFees && (
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <Loader2 className="w-3 h-3 animate-spin" />
                    Updating fees...
                  </span>
                )}
              </div>
              <div className="grid gap-2">
                {availableNetworks.map((network) => {
                  const fee = networkFees[network.chain];
                  const isSelected = selectedNetwork === network.chain;
                  
                  return (
                    <button
                      key={`${network.symbol}-${network.chain}`}
                      onClick={() => handleNetworkChange(network.chain)}
                      className={`p-4 rounded-xl border transition-all text-left ${
                        isSelected
                          ? 'border-primary bg-primary/10'
                          : 'border-border bg-secondary/30 hover:bg-secondary/50'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`w-3 h-3 rounded-full ${isSelected ? 'bg-primary' : 'bg-muted'}`} />
                          <div>
                            <p className="font-medium">{network.name}</p>
                            <p className="text-xs text-muted-foreground">{network.chain} Network</p>
                          </div>
                        </div>
                        {fee?.recommended && (
                          <span className="text-xs bg-green-500/20 text-green-500 px-2 py-1 rounded-full">
                            Recommended
                          </span>
                        )}
                      </div>
                      
                      {fee && (
                        <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <DollarSign className="w-3 h-3" />
                            <span>Fee: {fee.fee}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            <span>Speed: {fee.speed}</span>
                          </div>
                          {fee.gwei && (
                            <div className="flex items-center gap-1">
                              <Zap className="w-3 h-3" />
                              <span>{fee.gwei} Gwei</span>
                            </div>
                          )}
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Fee Comparison Card */}
          {currentFee && (
            <div className="flex items-center gap-3 p-3 rounded-xl bg-secondary/30 border border-border">
              <Zap className="w-5 h-5 text-primary" />
              <div className="flex-1">
                <p className="text-sm font-medium">Network: {selectedNetwork}</p>
                <p className="text-xs text-muted-foreground">
                  Est. Fee: {currentFee.fee} • Confirmation: {currentFee.speed}
                  {currentFee.gwei && ` • ${currentFee.gwei} Gwei`}
                </p>
              </div>
              {currentFee.recommended && (
                <span className="text-xs bg-green-500/20 text-green-500 px-2 py-0.5 rounded">
                  Low Fee
                </span>
              )}
            </div>
          )}

          {/* Deposit Listening Status */}
          {walletAddress && (
            <div className="flex items-center gap-2 p-2 rounded-lg bg-blue-500/10 border border-blue-500/20">
              <Bell className="w-4 h-4 text-blue-500" />
              <span className="text-xs text-blue-500">Listening for deposits...</span>
            </div>
          )}

          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="glass-card p-6 space-y-6">
            <div className="text-center">
              <p className="text-muted-foreground mb-2">Your {selectedAsset?.name} Address</p>
              <p className="font-semibold text-lg">{selectedAsset?.symbol}</p>
              <p className="text-xs text-muted-foreground mt-1">Network: {selectedAsset?.chain}</p>
            </div>

            {walletAddress ? (
              <>
                <QRCodeDisplay 
                  value={walletAddress} 
                  symbol={selectedAsset?.symbol || ''}
                  size={180}
                />

                <div className="p-3 rounded-xl bg-primary/10 border border-primary/20">
                  <p className="text-xs text-primary font-medium text-center mb-1">
                    Your Unique Address
                  </p>
                  <p className="text-xs text-muted-foreground text-center">
                    This address is permanently yours
                  </p>
                </div>

                <div className="text-center text-sm text-muted-foreground space-y-1">
                  <p>Only send {selectedAsset?.symbol} ({selectedAsset?.chain} network) to this address.</p>
                  <p className="text-xs">Deposits will be credited after network confirmation.</p>
                </div>
              </>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground mb-4">
                  Generate your unique {selectedAsset?.symbol} ({selectedAsset?.chain}) deposit address
                </p>
                <Button 
                  onClick={handleGetAddress} 
                  disabled={loading || isCreating}
                  className="bg-primary hover:bg-primary/90"
                >
                  {loading || isCreating ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    `Generate ${selectedAsset?.symbol} Address`
                  )}
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Receive;
