import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Users, Wallet, History, RefreshCw, Shield, Edit2, DollarSign, Settings, TrendingUp, FileText, UserCheck, TestTube } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { useAdmin, AppRole } from '@/hooks/useAdmin';
import { useAdminSettings } from '@/hooks/useAdminSettings';
import { useToast } from '@/hooks/use-toast';
import { formatDistanceToNow } from 'date-fns';
import { AdminKYCReview } from '@/components/AdminKYCReview';
import { AdminFeeDashboard } from '@/components/AdminFeeDashboard';
import { WalletSanityTest } from '@/components/WalletSanityTest';

const Admin = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const {
    isAdmin,
    loading,
    users,
    wallets,
    transactions,
    updateUserRole,
    updateWalletBalance,
    updateTransactionStatus,
    refetchUsers,
    refetchWallets,
    refetchTransactions,
  } = useAdmin();

  const {
    settings,
    settingsLoading,
    feeCollections,
    feesLoading,
    balanceAdjustments,
    adjustmentsLoading,
    getSetting,
    updateSetting,
    isUpdating,
    totalProfits,
  } = useAdminSettings();

  const [editingWallet, setEditingWallet] = useState<{ id: string; balance: string; reason: string } | null>(null);
  const [editingTransaction, setEditingTransaction] = useState<{ id: string; status: string } | null>(null);
  const [depositFee, setDepositFee] = useState('');
  const [withdrawalFee, setWithdrawalFee] = useState('');
  const [adminEmail, setAdminEmail] = useState('');

  // Initialize fee values from settings
  useState(() => {
    const depFee = getSetting('deposit_fee_percent');
    const witFee = getSetting('withdrawal_fee_percent');
    const alertEmail = getSetting('admin_alert_email');
    if (depFee?.value) setDepositFee(depFee.value.toString());
    if (witFee?.value) setWithdrawalFee(witFee.value.toString());
    if (alertEmail?.value) setAdminEmail(alertEmail.value.toString());
  });

  if (loading || settingsLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-4">
        <Shield className="w-16 h-16 text-muted-foreground" />
        <h1 className="text-2xl font-bold">Access Denied</h1>
        <p className="text-muted-foreground">You don't have permission to access this page.</p>
        <Button onClick={() => navigate('/')}>Go Home</Button>
      </div>
    );
  }

  const handleRoleChange = async (userId: string, role: string) => {
    await updateUserRole(userId, role as AppRole);
    toast({ title: 'Role Updated', description: 'User role has been updated.' });
  };

  const handleBalanceUpdate = async () => {
    if (!editingWallet) return;
    try {
      await updateWalletBalance(editingWallet.id, parseFloat(editingWallet.balance), editingWallet.reason);
      toast({ title: 'Balance Updated', description: 'Wallet balance has been updated with audit log.' });
      setEditingWallet(null);
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    }
  };

  const handleStatusUpdate = async () => {
    if (!editingTransaction) return;
    await updateTransactionStatus(editingTransaction.id, editingTransaction.status);
    toast({ title: 'Status Updated', description: 'Transaction status has been updated.' });
    setEditingTransaction(null);
  };

  const handleSaveFees = () => {
    if (depositFee) {
      updateSetting({ key: 'deposit_fee_percent', value: { value: parseFloat(depositFee) } });
    }
    if (withdrawalFee) {
      updateSetting({ key: 'withdrawal_fee_percent', value: { value: parseFloat(withdrawalFee) } });
    }
    if (adminEmail) {
      updateSetting({ key: 'admin_alert_email', value: { value: adminEmail } });
    }
    toast({ title: 'Settings Saved', description: 'Fee and alert settings have been updated.' });
  };

  const currentDepositFee = getSetting('deposit_fee_percent')?.value || 1.0;
  const currentWithdrawalFee = getSetting('withdrawal_fee_percent')?.value || 1.5;
  const currentAdminEmail = getSetting('admin_alert_email')?.value || '';

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-4 pb-8">
        <header className="flex items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/')}
              className="p-2 rounded-full bg-secondary/50 hover:bg-secondary transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-semibold">Admin Panel</h1>
          </div>
        </header>

        <Tabs defaultValue="fees" className="space-y-4">
          <TabsList className="grid w-full grid-cols-8">
            <TabsTrigger value="fees" className="flex items-center gap-2">
              <DollarSign className="w-4 h-4" />
              Fees
            </TabsTrigger>
            <TabsTrigger value="profits" className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              Profits
            </TabsTrigger>
            <TabsTrigger value="diagnostics" className="flex items-center gap-2">
              <TestTube className="w-4 h-4" />
              Test
            </TabsTrigger>
            <TabsTrigger value="kyc" className="flex items-center gap-2">
              <UserCheck className="w-4 h-4" />
              KYC
            </TabsTrigger>
            <TabsTrigger value="audit" className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Audit
            </TabsTrigger>
            <TabsTrigger value="users" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              Users
            </TabsTrigger>
            <TabsTrigger value="wallets" className="flex items-center gap-2">
              <Wallet className="w-4 h-4" />
              Wallets
            </TabsTrigger>
            <TabsTrigger value="transactions" className="flex items-center gap-2">
              <History className="w-4 h-4" />
              Txns
            </TabsTrigger>
          </TabsList>

          {/* Fee Settings Tab */}
          <TabsContent value="fees" className="space-y-6">
            <div className="glass-card p-6 space-y-6">
              <div className="flex items-center gap-3">
                <Settings className="w-6 h-6 text-primary" />
                <h2 className="text-lg font-semibold">Fee Configuration</h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="depositFee">Deposit Fee (%)</Label>
                  <Input
                    id="depositFee"
                    type="number"
                    step="0.1"
                    min="0"
                    max="100"
                    placeholder={currentDepositFee.toString()}
                    value={depositFee}
                    onChange={(e) => setDepositFee(e.target.value)}
                    className="bg-secondary/50"
                  />
                  <p className="text-xs text-muted-foreground">
                    Current: {currentDepositFee}% - Applied to all incoming deposits
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="withdrawalFee">Withdrawal Fee (%)</Label>
                  <Input
                    id="withdrawalFee"
                    type="number"
                    step="0.1"
                    min="0"
                    max="100"
                    placeholder={currentWithdrawalFee.toString()}
                    value={withdrawalFee}
                    onChange={(e) => setWithdrawalFee(e.target.value)}
                    className="bg-secondary/50"
                  />
                  <p className="text-xs text-muted-foreground">
                    Current: {currentWithdrawalFee}% - Applied to all outgoing withdrawals
                  </p>
                </div>

                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="adminEmail">Admin Alert Email</Label>
                  <Input
                    id="adminEmail"
                    type="email"
                    placeholder={currentAdminEmail || "admin@example.com"}
                    value={adminEmail}
                    onChange={(e) => setAdminEmail(e.target.value)}
                    className="bg-secondary/50"
                  />
                  <p className="text-xs text-muted-foreground">
                    {currentAdminEmail ? `Current: ${currentAdminEmail}` : 'Not set'} - Receives alerts for all deposits and withdrawals
                  </p>
                </div>
              </div>

              <Button 
                onClick={handleSaveFees} 
                disabled={isUpdating}
                className="w-full md:w-auto"
              >
                {isUpdating ? 'Saving...' : 'Save Settings'}
              </Button>
            </div>

            <div className="glass-card p-6">
              <h3 className="font-medium mb-4">How It Works</h3>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>• <strong>Deposit fees</strong> are automatically deducted when users receive crypto via Bybit webhook</li>
                <li>• <strong>Withdrawal fees</strong> are applied when users send crypto out of the platform</li>
                <li>• <strong>Admin alerts</strong> send email notifications for all completed deposits and withdrawals</li>
                <li>• All collected fees are tracked in the Profits tab</li>
                <li>• Changes take effect immediately for new transactions</li>
              </ul>
            </div>
          </TabsContent>

          {/* Profits Tab - Now uses AdminFeeDashboard */}
          <TabsContent value="profits">
            <AdminFeeDashboard />
          </TabsContent>

          {/* Diagnostics/Test Tab */}
          <TabsContent value="diagnostics">
            <WalletSanityTest />
          </TabsContent>

          {/* Legacy Profits Tab (hidden, kept for reference) */}
          <TabsContent value="profits-legacy" className="space-y-4 hidden">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {Object.entries(totalProfits).map(([currency, amount]) => (
                <div key={currency} className="glass-card p-4 text-center">
                  <p className="text-2xl font-bold text-primary">{amount.toFixed(8)}</p>
                  <p className="text-sm text-muted-foreground">{currency} Collected</p>
                </div>
              ))}
              {Object.keys(totalProfits).length === 0 && (
                <div className="col-span-full text-center py-8 text-muted-foreground">
                  No fees collected yet
                </div>
              )}
            </div>

            <div className="rounded-lg border border-border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Type</TableHead>
                    <TableHead>Currency</TableHead>
                    <TableHead>Fee Amount</TableHead>
                    <TableHead>Original Amount</TableHead>
                    <TableHead>Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {feeCollections.map((fee) => (
                    <TableRow key={fee.id}>
                      <TableCell className="capitalize">{fee.fee_type}</TableCell>
                      <TableCell className="font-medium">{fee.currency}</TableCell>
                      <TableCell className="text-primary font-medium">
                        +{fee.fee_amount.toFixed(8)}
                      </TableCell>
                      <TableCell>{fee.original_amount.toFixed(8)}</TableCell>
                      <TableCell className="text-muted-foreground text-sm">
                        {formatDistanceToNow(new Date(fee.created_at), { addSuffix: true })}
                      </TableCell>
                    </TableRow>
                  ))}
                  {feeCollections.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                        No fee collections yet
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          {/* KYC Review Tab */}
          <TabsContent value="kyc">
            <AdminKYCReview />
          </TabsContent>

          {/* Audit Log Tab */}
          <TabsContent value="audit" className="space-y-4">
            <div className="glass-card p-6">
              <div className="flex items-center gap-3 mb-4">
                <FileText className="w-6 h-6 text-primary" />
                <h2 className="text-lg font-semibold">Balance Adjustment Audit Log</h2>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Track all manual wallet balance modifications made by administrators.
              </p>
            </div>

            <div className="rounded-lg border border-border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Admin ID</TableHead>
                    <TableHead>Wallet ID</TableHead>
                    <TableHead>Old Balance</TableHead>
                    <TableHead>New Balance</TableHead>
                    <TableHead>Reason</TableHead>
                    <TableHead>Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {balanceAdjustments.map((adj) => (
                    <TableRow key={adj.id}>
                      <TableCell className="font-mono text-xs">
                        {adj.admin_id.slice(0, 8)}...
                      </TableCell>
                      <TableCell className="font-mono text-xs">
                        {adj.wallet_id.slice(0, 8)}...
                      </TableCell>
                      <TableCell className="text-destructive">
                        {adj.old_balance.toFixed(8)}
                      </TableCell>
                      <TableCell className="text-primary font-medium">
                        {adj.new_balance.toFixed(8)}
                      </TableCell>
                      <TableCell className="max-w-[200px] truncate" title={adj.reason}>
                        {adj.reason}
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm">
                        {formatDistanceToNow(new Date(adj.created_at), { addSuffix: true })}
                      </TableCell>
                    </TableRow>
                  ))}
                  {balanceAdjustments.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                        No balance adjustments recorded yet
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="users" className="space-y-4">
            <div className="flex justify-end">
              <Button variant="outline" size="sm" onClick={refetchUsers}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
            <div className="rounded-lg border border-border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Crypto Tag</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Joined</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{user.full_name || user.username || 'Anonymous'}</p>
                          <p className="text-xs text-muted-foreground">{user.id.slice(0, 8)}...</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        {user.crypto_tag ? (
                          <span className="text-primary">@{user.crypto_tag}</span>
                        ) : (
                          <span className="text-muted-foreground">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Select
                          value={user.role}
                          onValueChange={(value) => handleRoleChange(user.id, value)}
                        >
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="user">User</SelectItem>
                            <SelectItem value="moderator">Moderator</SelectItem>
                            <SelectItem value="admin">Admin</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm">
                        {formatDistanceToNow(new Date(user.created_at), { addSuffix: true })}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="wallets" className="space-y-4">
            <div className="flex justify-end">
              <Button variant="outline" size="sm" onClick={refetchWallets}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
            <div className="rounded-lg border border-border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User ID</TableHead>
                    <TableHead>Currency</TableHead>
                    <TableHead>Balance</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {wallets.map((wallet) => (
                    <TableRow key={wallet.id}>
                      <TableCell className="font-mono text-xs">
                        {wallet.user_id.slice(0, 8)}...
                      </TableCell>
                      <TableCell className="font-medium">{wallet.currency}</TableCell>
                      <TableCell>{wallet.balance.toFixed(8)}</TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setEditingWallet({ id: wallet.id, balance: wallet.balance.toString(), reason: '' })}
                        >
                          <Edit2 className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="transactions" className="space-y-4">
            <div className="flex justify-end">
              <Button variant="outline" size="sm" onClick={refetchTransactions}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
            <div className="rounded-lg border border-border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Type</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Fee</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>TX Hash</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {transactions.map((tx) => (
                    <TableRow key={tx.id}>
                      <TableCell className="capitalize">{tx.type}</TableCell>
                      <TableCell>
                        {tx.amount} {tx.from_currency}
                        {tx.to_currency && ` → ${tx.to_currency}`}
                      </TableCell>
                      <TableCell className="text-muted-foreground">-</TableCell>
                      <TableCell>
                        <span
                          className={`px-2 py-1 rounded-full text-xs ${
                            tx.status === 'completed'
                              ? 'bg-green-500/20 text-green-500'
                              : tx.status === 'pending'
                              ? 'bg-yellow-500/20 text-yellow-500'
                              : 'bg-red-500/20 text-red-500'
                          }`}
                        >
                          {tx.status}
                        </span>
                      </TableCell>
                      <TableCell className="font-mono text-xs">
                        {tx.tx_hash ? `${tx.tx_hash.slice(0, 10)}...` : '-'}
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm">
                        {formatDistanceToNow(new Date(tx.created_at), { addSuffix: true })}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setEditingTransaction({ id: tx.id, status: tx.status })}
                        >
                          <Edit2 className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Edit Balance Dialog */}
      <Dialog open={!!editingWallet} onOpenChange={() => setEditingWallet(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Wallet Balance</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="newBalance">New Balance</Label>
              <Input
                id="newBalance"
                type="number"
                step="0.00000001"
                value={editingWallet?.balance || ''}
                onChange={(e) => setEditingWallet((prev) => prev ? { ...prev, balance: e.target.value } : null)}
                placeholder="Enter new balance"
              />
            </div>
            <div>
              <Label htmlFor="adjustmentReason">Reason for Adjustment (required)</Label>
              <Input
                id="adjustmentReason"
                value={editingWallet?.reason || ''}
                onChange={(e) => setEditingWallet((prev) => prev ? { ...prev, reason: e.target.value } : null)}
                placeholder="Enter detailed reason (min 10 characters)"
                minLength={10}
              />
              <p className="text-xs text-muted-foreground mt-1">
                This will be logged for audit purposes
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingWallet(null)}>Cancel</Button>
            <Button onClick={handleBalanceUpdate}>Update</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Transaction Status Dialog */}
      <Dialog open={!!editingTransaction} onOpenChange={() => setEditingTransaction(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Transaction Status</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Select
              value={editingTransaction?.status || ''}
              onValueChange={(value) => setEditingTransaction((prev) => prev ? { ...prev, status: value } : null)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingTransaction(null)}>Cancel</Button>
            <Button onClick={handleStatusUpdate}>Update</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Admin;