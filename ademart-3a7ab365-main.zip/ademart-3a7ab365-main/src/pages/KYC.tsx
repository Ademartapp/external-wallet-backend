import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Upload, CheckCircle, AlertCircle, XCircle, Clock, Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useKYC, KYCFormData } from '@/hooks/useKYC';
import { BottomNav } from '@/components/BottomNav';

const KYC = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const { kycStatus, isLoading, submitKYC, isSubmitting } = useKYC();
  const idDocRef = useRef<HTMLInputElement>(null);
  const selfieRef = useRef<HTMLInputElement>(null);

  const [formData, setFormData] = useState<KYCFormData>({
    fullName: '',
    dateOfBirth: '',
    address: '',
    city: '',
    state: '',
    idType: '',
    idNumber: '',
    bvn: '',
  });
  const [idDocument, setIdDocument] = useState<File | null>(null);
  const [selfie, setSelfie] = useState<File | null>(null);

  // Redirect to auth if not logged in
  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/auth');
    }
  }, [user, authLoading, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    submitKYC({
      ...formData,
      idDocument: idDocument || undefined,
      selfie: selfie || undefined,
    }, {
      onSuccess: () => {
        navigate('/');
      },
    });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'id' | 'selfie') => {
    const file = e.target.files?.[0];
    if (file) {
      if (type === 'id') {
        setIdDocument(file);
      } else {
        setSelfie(file);
      }
    }
  };

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin" />
      </div>
    );
  }

  // Show status if KYC already submitted
  if (kycStatus) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-md mx-auto px-4 pb-24">
          <header className="flex items-center gap-4 py-4">
            <button
              onClick={() => navigate('/')}
              className="p-2 rounded-full bg-secondary/50 hover:bg-secondary transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-semibold">KYC Verification</h1>
          </header>

          <div className="space-y-6 animate-fade-in">
            {kycStatus.status === 'pending' && (
              <div className="p-6 rounded-xl bg-amber-500/10 border border-amber-500/20 text-center">
                <Clock className="w-12 h-12 text-amber-500 mx-auto mb-4" />
                <h2 className="text-lg font-semibold text-amber-500 mb-2">Verification In Progress</h2>
                <p className="text-sm text-muted-foreground">
                  Your KYC documents are being reviewed. This typically takes 1-2 business days.
                </p>
              </div>
            )}

            {kycStatus.status === 'approved' && (
              <div className="p-6 rounded-xl bg-green-500/10 border border-green-500/20 text-center">
                <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                <h2 className="text-lg font-semibold text-green-500 mb-2">Verified</h2>
                <p className="text-sm text-muted-foreground">
                  Your identity has been verified. You have full access to all features.
                </p>
              </div>
            )}

            {kycStatus.status === 'rejected' && (
              <div className="p-6 rounded-xl bg-red-500/10 border border-red-500/20 text-center">
                <XCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
                <h2 className="text-lg font-semibold text-red-500 mb-2">Verification Failed</h2>
                <p className="text-sm text-muted-foreground mb-4">
                  {kycStatus.rejection_reason || 'Your verification was not approved. Please resubmit with valid documents.'}
                </p>
                <Button onClick={() => window.location.reload()}>
                  Resubmit KYC
                </Button>
              </div>
            )}

            <div className="glass-card p-4">
              <h3 className="font-medium mb-3">Submission Details</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Name</span>
                  <span>{kycStatus.full_name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">ID Type</span>
                  <span className="capitalize">{kycStatus.id_type.replace('_', ' ')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Submitted</span>
                  <span>{new Date(kycStatus.created_at).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <BottomNav />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-md mx-auto px-4 pb-24">
        <header className="flex items-center gap-4 py-4">
          <button
            onClick={() => navigate('/')}
            className="p-2 rounded-full bg-secondary/50 hover:bg-secondary transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-semibold">KYC Verification</h1>
        </header>

        <div className="space-y-6 animate-fade-in">
          <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-amber-500 mt-0.5" />
              <div>
                <p className="font-medium text-amber-500">Verification Required</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Complete KYC to unlock higher transaction limits and sell crypto to NGN.
                </p>
              </div>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="fullName">Full Name (as on ID)</Label>
              <Input
                id="fullName"
                value={formData.fullName}
                onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                placeholder="Enter your full name"
                required
                className="bg-secondary/50 border-border/50"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="dateOfBirth">Date of Birth</Label>
              <Input
                id="dateOfBirth"
                type="date"
                value={formData.dateOfBirth}
                onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                required
                className="bg-secondary/50 border-border/50"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="bvn">BVN (Bank Verification Number)</Label>
              <Input
                id="bvn"
                value={formData.bvn}
                onChange={(e) => setFormData({ ...formData, bvn: e.target.value })}
                placeholder="Enter your 11-digit BVN"
                maxLength={11}
                pattern="[0-9]{11}"
                required
                className="bg-secondary/50 border-border/50"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="address">Address</Label>
              <Input
                id="address"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                placeholder="Enter your address"
                required
                className="bg-secondary/50 border-border/50"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="city">City</Label>
                <Input
                  id="city"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  placeholder="City"
                  required
                  className="bg-secondary/50 border-border/50"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="state">State</Label>
                <Input
                  id="state"
                  value={formData.state}
                  onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                  placeholder="State"
                  required
                  className="bg-secondary/50 border-border/50"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="idType">ID Type</Label>
              <Select
                value={formData.idType}
                onValueChange={(value) => setFormData({ ...formData, idType: value })}
                required
              >
                <SelectTrigger className="bg-secondary/50 border-border/50">
                  <SelectValue placeholder="Select ID type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="nin">National ID (NIN)</SelectItem>
                  <SelectItem value="passport">International Passport</SelectItem>
                  <SelectItem value="drivers_license">Driver's License</SelectItem>
                  <SelectItem value="voters_card">Voter's Card</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="idNumber">ID Number</Label>
              <Input
                id="idNumber"
                value={formData.idNumber}
                onChange={(e) => setFormData({ ...formData, idNumber: e.target.value })}
                placeholder="Enter your ID number"
                required
                className="bg-secondary/50 border-border/50"
              />
            </div>

            <div className="space-y-2">
              <Label>Upload ID Document</Label>
              <input
                ref={idDocRef}
                type="file"
                accept="image/*,.pdf"
                onChange={(e) => handleFileChange(e, 'id')}
                className="hidden"
              />
              <div 
                onClick={() => idDocRef.current?.click()}
                className="border-2 border-dashed border-border/50 rounded-xl p-6 text-center hover:border-primary/50 transition-colors cursor-pointer"
              >
                {idDocument ? (
                  <div className="flex items-center justify-center gap-2 text-primary">
                    <CheckCircle className="w-5 h-5" />
                    <span className="text-sm">{idDocument.name}</span>
                  </div>
                ) : (
                  <>
                    <Upload className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground">
                      Click to upload ID document
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      PNG, JPG, PDF up to 5MB
                    </p>
                  </>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Upload Selfie</Label>
              <input
                ref={selfieRef}
                type="file"
                accept="image/*"
                onChange={(e) => handleFileChange(e, 'selfie')}
                className="hidden"
              />
              <div 
                onClick={() => selfieRef.current?.click()}
                className="border-2 border-dashed border-border/50 rounded-xl p-6 text-center hover:border-primary/50 transition-colors cursor-pointer"
              >
                {selfie ? (
                  <div className="flex items-center justify-center gap-2 text-primary">
                    <CheckCircle className="w-5 h-5" />
                    <span className="text-sm">{selfie.name}</span>
                  </div>
                ) : (
                  <>
                    <Upload className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground">
                      Click to upload a selfie
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      PNG, JPG up to 5MB
                    </p>
                  </>
                )}
              </div>
            </div>

            <Button type="submit" className="w-full" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Submitting...
                </>
              ) : (
                'Submit for Verification'
              )}
            </Button>
          </form>

          <div className="p-4 rounded-xl bg-secondary/30">
            <h3 className="font-medium mb-3 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-primary" />
              Verification Benefits
            </h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>• Higher daily transaction limits</li>
              <li>• Sell crypto directly to NGN</li>
              <li>• Access to P2P trading</li>
              <li>• Priority customer support</li>
            </ul>
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  );
};

export default KYC;
