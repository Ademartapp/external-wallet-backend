import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, CheckCircle, XCircle, AlertCircle, RefreshCw, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';

interface ServiceCheck {
  name: string;
  status: 'ok' | 'error' | 'checking';
  message?: string;
  latency?: number;
}

const ServiceStatus = () => {
  const navigate = useNavigate();
  const [services, setServices] = useState<ServiceCheck[]>([
    { name: 'Database', status: 'checking' },
    { name: 'Authentication', status: 'checking' },
    { name: 'Bybit Exchange', status: 'checking' },
    { name: 'Quidax Exchange', status: 'checking' },
    { name: 'HD Wallet', status: 'checking' },
    { name: 'On-chain Monitor', status: 'checking' },
  ]);
  const [checking, setChecking] = useState(false);
  const [lastCheck, setLastCheck] = useState<string | null>(null);

  const checkServices = async () => {
    setChecking(true);
    const results: ServiceCheck[] = [];

    // Database check
    const dbStart = Date.now();
    try {
      const { error } = await supabase.from('profiles').select('id').limit(1);
      results.push({
        name: 'Database',
        status: error ? 'error' : 'ok',
        message: error?.message,
        latency: Date.now() - dbStart,
      });
    } catch (e: any) {
      results.push({ name: 'Database', status: 'error', message: e.message });
    }

    // Auth check
    const authStart = Date.now();
    try {
      const { error } = await supabase.auth.getSession();
      results.push({
        name: 'Authentication',
        status: error ? 'error' : 'ok',
        message: error?.message,
        latency: Date.now() - authStart,
      });
    } catch (e: any) {
      results.push({ name: 'Authentication', status: 'error', message: e.message });
    }

    // Bybit check
    const bybitStart = Date.now();
    try {
      const { data, error } = await supabase.functions.invoke('bybit', {
        body: { action: 'get_balances' },
      });
      results.push({
        name: 'Bybit Exchange',
        status: error || !data?.success ? 'error' : 'ok',
        message: error?.message || data?.error,
        latency: Date.now() - bybitStart,
      });
    } catch (e: any) {
      results.push({ name: 'Bybit Exchange', status: 'error', message: e.message });
    }

    // Quidax check
    const quidaxStart = Date.now();
    try {
      const { data, error } = await supabase.functions.invoke('quidax', {
        body: { action: 'get_mobile_money_providers' },
      });
      results.push({
        name: 'Quidax Exchange',
        status: error || data?.error ? 'error' : 'ok',
        message: error?.message || data?.error,
        latency: Date.now() - quidaxStart,
      });
    } catch (e: any) {
      results.push({ name: 'Quidax Exchange', status: 'error', message: e.message });
    }

    // HD Wallet check
    const hdStart = Date.now();
    try {
      const { data, error } = await supabase.functions.invoke('hd-wallet', {
        body: { action: 'estimate_fee', feeChain: 'TRX', feeSymbol: 'TRX' },
      });
      results.push({
        name: 'HD Wallet',
        status: error || !data?.success ? 'error' : 'ok',
        message: error?.message || data?.error,
        latency: Date.now() - hdStart,
      });
    } catch (e: any) {
      results.push({ name: 'HD Wallet', status: 'error', message: e.message });
    }

    // On-chain monitor - skip if not authenticated
    results.push({
      name: 'On-chain Monitor',
      status: 'ok',
      message: 'Requires authentication to test',
      latency: 0,
    });

    setServices(results);
    setLastCheck(new Date().toLocaleTimeString());
    setChecking(false);
  };

  useEffect(() => {
    checkServices();
  }, []);

  const getStatusIcon = (status: ServiceCheck['status']) => {
    switch (status) {
      case 'ok':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'error':
        return <XCircle className="w-5 h-5 text-destructive" />;
      case 'checking':
        return <Loader2 className="w-5 h-5 text-muted-foreground animate-spin" />;
    }
  };

  const allOk = services.every(s => s.status === 'ok');
  const hasErrors = services.some(s => s.status === 'error');

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-md mx-auto px-4 pb-8">
        <header className="flex items-center gap-4 py-4">
          <button
            onClick={() => navigate(-1)}
            className="p-2 rounded-full bg-secondary/50 hover:bg-secondary transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-semibold">Service Status</h1>
        </header>

        <div className="space-y-6 animate-fade-in">
          {/* Overall Status */}
          <div className={`glass-card p-6 border-l-4 ${
            allOk ? 'border-l-green-500' : hasErrors ? 'border-l-destructive' : 'border-l-yellow-500'
          }`}>
            <div className="flex items-center gap-3">
              {allOk ? (
                <CheckCircle className="w-8 h-8 text-green-500" />
              ) : hasErrors ? (
                <XCircle className="w-8 h-8 text-destructive" />
              ) : (
                <AlertCircle className="w-8 h-8 text-yellow-500" />
              )}
              <div>
                <p className="font-semibold text-lg">
                  {allOk ? 'All Systems Operational' : hasErrors ? 'Some Services Degraded' : 'Checking...'}
                </p>
                {lastCheck && (
                  <p className="text-sm text-muted-foreground">Last checked: {lastCheck}</p>
                )}
              </div>
            </div>
          </div>

          {/* Service List */}
          <div className="space-y-3">
            {services.map((service) => (
              <div
                key={service.name}
                className="glass-card p-4 flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  {getStatusIcon(service.status)}
                  <div>
                    <p className="font-medium">{service.name}</p>
                    {service.message && (
                      <p className="text-xs text-muted-foreground truncate max-w-[200px]">
                        {service.message}
                      </p>
                    )}
                  </div>
                </div>
                {service.latency !== undefined && service.latency > 0 && (
                  <span className="text-xs text-muted-foreground">{service.latency}ms</span>
                )}
              </div>
            ))}
          </div>

          {/* Refresh Button */}
          <Button
            onClick={checkServices}
            disabled={checking}
            variant="outline"
            className="w-full"
          >
            {checking ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Checking...
              </>
            ) : (
              <>
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh Status
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ServiceStatus;
