import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Activity, RefreshCw, CheckCircle, XCircle, Clock, Zap, Server, AlertTriangle, Play, Loader2, Shield, Wallet, Database, Key } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { BottomNav } from '@/components/BottomNav';

interface EndpointStatus {
  name: string;
  url: string;
  status: 'checking' | 'online' | 'offline' | 'slow';
  latency?: number;
}

interface SanityTestResult {
  test: string;
  passed: boolean;
  details?: Record<string, unknown>;
  error?: string;
}

interface WalletSanityResult {
  success: boolean;
  allTestsPassed: boolean;
  safeTestMode: boolean;
  tests: SanityTestResult[];
  warnings?: string[];
}

interface RecentTransaction {
  id: string;
  type: string;
  status: string;
  amount: number;
  from_currency: string;
  recipient_address: string | null;
  tx_hash: string | null;
  error_details: string | null;
  can_retry: boolean;
  retry_count: number;
  created_at: string;
}

const MAX_AUTO_RETRIES = 3;
const RETRY_DELAY_MS = 5000;

const Diagnostics = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [endpoints, setEndpoints] = useState<EndpointStatus[]>([
    { name: 'TRON (TronGrid)', url: 'https://api.trongrid.io', status: 'checking' },
    { name: 'TRON (TronStack)', url: 'https://api.tronstack.io', status: 'checking' },
    { name: 'Ethereum', url: 'https://eth.llamarpc.com', status: 'checking' },
    { name: 'BSC', url: 'https://bsc-dataseed.binance.org', status: 'checking' },
    { name: 'Polygon', url: 'https://polygon-rpc.com', status: 'checking' },
  ]);
  
  const [recentTxs, setRecentTxs] = useState<RecentTransaction[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [retryingTxId, setRetryingTxId] = useState<string | null>(null);
  const [autoRetryEnabled, setAutoRetryEnabled] = useState(true);
  
  // Wallet sanity test state
  const [sanityResult, setSanityResult] = useState<WalletSanityResult | null>(null);
  const [sanityLoading, setSanityLoading] = useState(false);
  const [sanityError, setSanityError] = useState<string | null>(null);

  // Check endpoint health
  const checkEndpoints = async () => {
    const checks = endpoints.map(async (ep) => {
      const start = Date.now();
      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 8000);
        
        let url = ep.url;
        let method = 'POST';
        let body: string | undefined;
        
        if (ep.url.includes('tron')) {
          url = `${ep.url}/wallet/getnowblock`;
          method = 'POST';
          body = JSON.stringify({});
        } else {
          body = JSON.stringify({
            jsonrpc: '2.0',
            id: 1,
            method: 'eth_blockNumber',
            params: [],
          });
        }
        
        const res = await fetch(url, { 
          method,
          headers: { 'Content-Type': 'application/json' },
          body,
          signal: controller.signal,
        });
        clearTimeout(timeout);
        
        const latency = Date.now() - start;
        return {
          ...ep,
          status: latency > 3000 ? 'slow' : 'online',
          latency,
        } as EndpointStatus;
      } catch {
        return { ...ep, status: 'offline', latency: undefined } as EndpointStatus;
      }
    });

    const results = await Promise.all(checks);
    setEndpoints(results);
  };

  // Run wallet sanity test
  const runWalletSanityTest = async () => {
    setSanityLoading(true);
    setSanityError(null);
    
    try {
      const { data, error } = await supabase.functions.invoke('unified-wallet', {
        body: { action: 'health_check' },
      });
      
      if (error) {
        throw new Error(error.message);
      }
      
      if (!data?.success) {
        throw new Error(data?.error || 'Health check failed');
      }
      
      // Also run get_config to see full status
      const { data: configData } = await supabase.functions.invoke('unified-wallet', {
        body: { action: 'get_config' },
      });
      
      setSanityResult({
        success: true,
        allTestsPassed: true,
        safeTestMode: data.safeTestMode || false,
        tests: [
          { test: 'unified_wallet', passed: true, details: { status: data.status } },
          { test: 'supported_assets', passed: (data.supportedAssets?.length || 0) > 0, details: { count: data.supportedAssets?.length } },
          { test: 'config_loaded', passed: !!configData?.success, details: configData?.withdrawalLimits },
        ],
        warnings: data.warnings || configData?.warnings || [],
      });
      
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setSanityError(errorMessage);
      setSanityResult(null);
    } finally {
      setSanityLoading(false);
    }
  };

  // Fetch recent transactions with errors
  const fetchRecentTxs = async () => {
    if (!user) return;
    
    const { data } = await supabase
      .from('transactions')
      .select('id, type, status, amount, from_currency, recipient_address, tx_hash, error_details, can_retry, retry_count, created_at')
      .eq('user_id', user.id)
      .in('type', ['send'])
      .order('created_at', { ascending: false })
      .limit(15);
    
    setRecentTxs((data as RecentTransaction[]) || []);
  };

  // Retry a failed transaction
  const handleRetry = useCallback(async (tx: RecentTransaction) => {
    if (!tx.can_retry || !tx.recipient_address || !user) return;
    
    setRetryingTxId(tx.id);
    try {
      const { data, error } = await supabase.functions.invoke('unified-wallet', {
        body: {
          action: 'send',
          symbol: tx.from_currency,
          toAddress: tx.recipient_address,
          amount: tx.amount.toString(),
        },
      });

      if (error) throw new Error(error.message);
      
      if (data?.success) {
        await supabase
          .from('transactions')
          .update({ 
            can_retry: false,
            error_details: `Retried successfully. New TX: ${data.txHash}`,
          })
          .eq('id', tx.id);
        
        toast({
          title: 'Retry Successful!',
          description: `Transaction resubmitted. TX: ${data.txHash?.slice(0, 16)}...`,
        });
      } else {
        const newRetryCount = tx.retry_count + 1;
        await supabase
          .from('transactions')
          .update({ 
            retry_count: newRetryCount,
            last_error: data?.error || 'Retry failed',
            can_retry: newRetryCount < MAX_AUTO_RETRIES,
          })
          .eq('id', tx.id);
        
        toast({
          title: 'Retry Failed',
          description: data?.error || 'Transaction retry failed',
          variant: 'destructive',
        });
      }
      
      await fetchRecentTxs();
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      toast({
        title: 'Retry Failed',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setRetryingTxId(null);
    }
  }, [toast, user]);

  // Auto-retry failed transactions
  const processAutoRetries = useCallback(async () => {
    if (!autoRetryEnabled || !user) return;
    
    const failedTxs = recentTxs.filter(
      tx => tx.status === 'failed' && 
            tx.can_retry && 
            tx.retry_count < MAX_AUTO_RETRIES &&
            tx.recipient_address
    );
    
    for (const tx of failedTxs) {
      const txAge = Date.now() - new Date(tx.created_at).getTime();
      if (txAge < 10 * 60 * 1000) {
        console.log(`Auto-retrying transaction ${tx.id}...`);
        await handleRetry(tx);
        await new Promise(r => setTimeout(r, RETRY_DELAY_MS));
      }
    }
  }, [autoRetryEnabled, user, recentTxs, handleRetry]);

  // Run diagnostics
  const runDiagnostics = async () => {
    setIsLoading(true);
    await Promise.all([checkEndpoints(), fetchRecentTxs(), runWalletSanityTest()]);
    setIsLoading(false);
  };

  useEffect(() => {
    if (user) {
      runDiagnostics();
    }
  }, [user]);

  useEffect(() => {
    if (autoRetryEnabled && recentTxs.length > 0) {
      const timer = setTimeout(processAutoRetries, 2000);
      return () => clearTimeout(timer);
    }
  }, [autoRetryEnabled, recentTxs, processAutoRetries]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'online': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'slow': return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'offline': return <XCircle className="w-4 h-4 text-red-500" />;
      default: return <RefreshCw className="w-4 h-4 animate-spin text-muted-foreground" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed': return <Badge variant="secondary" className="bg-green-500/20 text-green-500">Completed</Badge>;
      case 'pending': return <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-500">Pending</Badge>;
      case 'failed': return <Badge variant="destructive">Failed</Badge>;
      default: return <Badge variant="outline">{status}</Badge>;
    }
  };

  const failedCount = recentTxs.filter(tx => tx.status === 'failed' && tx.can_retry).length;

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-md mx-auto px-4 pb-24">
        <header className="flex items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/settings')}
              className="p-2 rounded-full bg-secondary/50 hover:bg-secondary transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-semibold">Diagnostics</h1>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={runDiagnostics}
            disabled={isLoading}
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </header>

        <div className="space-y-6 animate-fade-in">
          {/* Wallet Sanity Test Results */}
          <Card className={sanityResult?.allTestsPassed ? 'border-green-500/50' : sanityError ? 'border-red-500/50' : ''}>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Shield className="w-5 h-5" />
                Wallet Backend Status
              </CardTitle>
              <CardDescription>
                API connectivity and configuration check
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {sanityLoading ? (
                <div className="flex items-center justify-center py-4">
                  <Loader2 className="w-6 h-6 animate-spin text-primary" />
                  <span className="ml-2 text-sm text-muted-foreground">Running sanity tests...</span>
                </div>
              ) : sanityError ? (
                <div className="p-4 rounded-lg bg-red-500/10 border border-red-500/30">
                  <div className="flex items-start gap-3">
                    <XCircle className="w-5 h-5 text-red-500 shrink-0" />
                    <div>
                      <p className="font-medium text-red-600 dark:text-red-400">Backend Error</p>
                      <p className="text-sm text-muted-foreground mt-1">{sanityError}</p>
                    </div>
                  </div>
                </div>
              ) : sanityResult ? (
                <div className="space-y-3">
                  {/* Overall status */}
                  <div className={`p-3 rounded-lg ${sanityResult.allTestsPassed ? 'bg-green-500/10 border border-green-500/30' : 'bg-yellow-500/10 border border-yellow-500/30'}`}>
                    <div className="flex items-center gap-2">
                      {sanityResult.allTestsPassed ? (
                        <CheckCircle className="w-5 h-5 text-green-500" />
                      ) : (
                        <AlertTriangle className="w-5 h-5 text-yellow-500" />
                      )}
                      <span className="font-medium">
                        {sanityResult.allTestsPassed ? 'All Systems Operational' : 'Some Issues Detected'}
                      </span>
                    </div>
                    {sanityResult.safeTestMode && (
                      <p className="text-xs text-muted-foreground mt-1">Safe Test Mode: ON (withdrawal limits active)</p>
                    )}
                  </div>

                  {/* Individual tests */}
                  {sanityResult.tests.map((test) => (
                    <div key={test.test} className="flex items-center justify-between p-2 rounded-lg bg-secondary/30">
                      <div className="flex items-center gap-2">
                        {test.passed ? (
                          <CheckCircle className="w-4 h-4 text-green-500" />
                        ) : (
                          <XCircle className="w-4 h-4 text-red-500" />
                        )}
                        <span className="text-sm capitalize">{test.test.replace(/_/g, ' ')}</span>
                      </div>
                      <Badge variant={test.passed ? 'secondary' : 'destructive'}>
                        {test.passed ? 'Pass' : 'Fail'}
                      </Badge>
                    </div>
                  ))}

                  {/* Warnings */}
                  {sanityResult.warnings && sanityResult.warnings.length > 0 && (
                    <div className="p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/30">
                      <div className="flex items-start gap-2">
                        <AlertTriangle className="w-4 h-4 text-yellow-500 shrink-0 mt-0.5" />
                        <div>
                          <p className="font-medium text-sm text-yellow-600 dark:text-yellow-400">Warnings</p>
                          <ul className="text-xs text-muted-foreground mt-1 space-y-1">
                            {sanityResult.warnings.map((w, i) => (
                              <li key={i}>• {w}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <Button variant="outline" onClick={runWalletSanityTest} className="w-full">
                  <Play className="w-4 h-4 mr-2" />
                  Run Sanity Test
                </Button>
              )}
            </CardContent>
          </Card>

          {/* API Keys Status */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Key className="w-5 h-5" />
                Required API Keys
              </CardTitle>
              <CardDescription>
                Your backend uses these services
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {[
                { name: 'Alchemy (ETH/BSC/MATIC)', desc: 'EVM chain RPCs' },
                { name: 'CryptoAPIs (BTC/LTC/DOGE)', desc: 'UTXO chain wallet' },
                { name: 'TronGrid (TRX)', desc: 'TRON network' },
                { name: 'Quidax (NGN)', desc: 'Fiat exchange' },
              ].map((api) => (
                <div key={api.name} className="flex items-center justify-between p-2 rounded-lg bg-secondary/30">
                  <div>
                    <p className="text-sm font-medium">{api.name}</p>
                    <p className="text-xs text-muted-foreground">{api.desc}</p>
                  </div>
                  <CheckCircle className="w-4 h-4 text-green-500" />
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Auto-Retry Status */}
          {failedCount > 0 && (
            <Card className="border-amber-500/50 bg-amber-500/10">
              <CardContent className="py-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <AlertTriangle className="w-5 h-5 text-amber-500" />
                    <div>
                      <p className="font-medium">{failedCount} Failed Transaction{failedCount > 1 ? 's' : ''}</p>
                      <p className="text-xs text-muted-foreground">
                        {autoRetryEnabled ? 'Auto-retry enabled' : 'Manual retry only'}
                      </p>
                    </div>
                  </div>
                  <Button
                    variant={autoRetryEnabled ? 'secondary' : 'default'}
                    size="sm"
                    onClick={() => setAutoRetryEnabled(!autoRetryEnabled)}
                  >
                    {autoRetryEnabled ? 'Pause' : 'Enable'} Auto
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Provider Status */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Server className="w-5 h-5" />
                Provider Status
              </CardTitle>
              <CardDescription>
                Blockchain RPC endpoint health
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {endpoints.map((ep) => (
                <div key={ep.url} className="flex items-center justify-between p-3 rounded-lg bg-secondary/30">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(ep.status)}
                    <div>
                      <p className="font-medium text-sm">{ep.name}</p>
                      <p className="text-xs text-muted-foreground truncate max-w-[180px]">{ep.url}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    {ep.latency !== undefined && (
                      <p className={`text-sm font-mono ${ep.latency > 3000 ? 'text-yellow-500' : 'text-green-500'}`}>
                        {ep.latency}ms
                      </p>
                    )}
                    <p className={`text-xs capitalize ${
                      ep.status === 'online' ? 'text-green-500' : 
                      ep.status === 'slow' ? 'text-yellow-500' : 
                      ep.status === 'offline' ? 'text-red-500' : 'text-muted-foreground'
                    }`}>
                      {ep.status}
                    </p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Recent Send Transactions */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Activity className="w-5 h-5" />
                Recent Sends
              </CardTitle>
              <CardDescription>
                Your recent on-chain send transactions
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {recentTxs.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">
                  No recent send transactions
                </p>
              ) : (
                recentTxs.slice(0, 5).map((tx) => (
                  <div key={tx.id} className="p-3 rounded-lg bg-secondary/30 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Zap className="w-4 h-4 text-primary" />
                        <span className="font-medium">{tx.amount} {tx.from_currency}</span>
                      </div>
                      {getStatusBadge(tx.status)}
                    </div>
                    
                    {tx.recipient_address && (
                      <p className="text-xs text-muted-foreground font-mono truncate">
                        To: {tx.recipient_address.slice(0, 12)}...{tx.recipient_address.slice(-8)}
                      </p>
                    )}
                    
                    {tx.tx_hash && (
                      <p className="text-xs text-muted-foreground font-mono truncate">
                        TX: {tx.tx_hash.slice(0, 16)}...
                      </p>
                    )}
                    
                    {tx.error_details && (
                      <div className="flex items-start gap-2 p-2 rounded bg-destructive/10 border border-destructive/20">
                        <AlertTriangle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
                        <div className="flex-1">
                          <p className="text-xs text-destructive break-words">{tx.error_details}</p>
                          {tx.retry_count > 0 && (
                            <p className="text-xs text-muted-foreground mt-1">
                              Retried {tx.retry_count}/{MAX_AUTO_RETRIES} times
                            </p>
                          )}
                        </div>
                      </div>
                    )}
                    
                    {tx.can_retry && tx.status === 'failed' && tx.recipient_address && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full mt-2"
                        onClick={() => handleRetry(tx)}
                        disabled={retryingTxId === tx.id}
                      >
                        {retryingTxId === tx.id ? (
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        ) : (
                          <Play className="w-4 h-4 mr-2" />
                        )}
                        {retryingTxId === tx.id ? 'Retrying...' : 'Retry Now'}
                      </Button>
                    )}
                  </div>
                ))
              )}
            </CardContent>
          </Card>

          {/* Tips */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Troubleshooting Tips</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-muted-foreground">
              <p>• <strong>TRON/TRC20 sends failing:</strong> Ensure you have 15-30 TRX for energy/bandwidth fees</p>
              <p>• <strong>Slow confirmations:</strong> Network congestion can delay confirmations up to a few minutes</p>
              <p>• <strong>Failed transactions:</strong> Auto-retry will attempt up to {MAX_AUTO_RETRIES} times within 10 minutes</p>
              <p>• <strong>Balance issues:</strong> Use "Sync" button on the home page to refresh on-chain balances</p>
              <p>• <strong>Provider offline:</strong> We automatically fall back to alternate providers</p>
            </CardContent>
          </Card>
        </div>
      </div>

      <BottomNav />
    </div>
  );
};

export default Diagnostics;
