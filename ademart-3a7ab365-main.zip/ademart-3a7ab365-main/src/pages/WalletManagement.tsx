import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Plus, Wallet, Copy, Star, Trash2, Loader2, RefreshCw, Clock, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useWalletAddresses, supportedAssets } from '@/hooks/useWalletAddresses';
import { useRealtimeWallets } from '@/hooks/useRealtimeWallets';
import { useOnchainSync } from '@/hooks/useOnchainSync';
import { useToast } from '@/hooks/use-toast';
import { BottomNav } from '@/components/BottomNav';
import { WalletBackup } from '@/components/WalletBackup';
import { WalletImport } from '@/components/WalletImport';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

// Group assets by symbol (unique tokens)
function getUniqueTokens() {
  const tokens = new Map<string, typeof supportedAssets>();
  supportedAssets.forEach(asset => {
    if (!tokens.has(asset.symbol)) {
      tokens.set(asset.symbol, []);
    }
    tokens.get(asset.symbol)!.push(asset);
  });
  return tokens;
}

const WalletManagement = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { wallets, isLoading, createWalletWithChain, isCreating, deleteWallet, setPrimary } = useWalletAddresses();
  const { wallets: balanceWallets, getWalletBalance } = useRealtimeWallets();
  const { syncBalances, syncing, lastSync } = useOnchainSync();
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const uniqueTokens = useMemo(() => getUniqueTokens(), []);

  const copyAddress = (address: string) => {
    navigator.clipboard.writeText(address);
    toast({ title: 'Copied', description: 'Address copied to clipboard' });
  };

  const handleCreateWallet = async (symbol: string, chain: string) => {
    try {
      await createWalletWithChain(symbol, chain);
    } catch (error) {
      // Error handled by mutation
    }
  };

  // Group wallets by symbol
  const walletsBySymbol = useMemo(() => {
    const grouped = new Map<string, typeof wallets>();
    wallets.forEach(w => {
      if (!grouped.has(w.symbol)) {
        grouped.set(w.symbol, []);
      }
      grouped.get(w.symbol)!.push(w);
    });
    return grouped;
  }, [wallets]);

  // Format last sync time
  const formatLastSync = (isoString: string | null) => {
    if (!isoString) return 'Never';
    const date = new Date(isoString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffMins < 1440) return `${Math.floor(diffMins / 60)}h ago`;
    return date.toLocaleDateString();
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-md mx-auto px-4 pb-24">
        <header className="flex items-center gap-4 py-4">
          <button
            onClick={() => navigate('/')}
            className="p-2 rounded-full bg-secondary/50 hover:bg-secondary transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-semibold">Wallet Management</h1>
        </header>

        {/* On-chain Sync Section */}
        <div className="mb-4 p-4 rounded-xl bg-gradient-to-r from-primary/10 to-primary/5 border border-primary/20">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <RefreshCw className={`w-5 h-5 text-primary ${syncing ? 'animate-spin' : ''}`} />
              <span className="font-medium">On-Chain Sync</span>
            </div>
            <Button
              size="sm"
              onClick={() => syncBalances()}
              disabled={syncing}
              className="bg-primary hover:bg-primary/90"
            >
              {syncing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                  Syncing...
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4 mr-1" />
                  Sync Now
                </>
              )}
            </Button>
          </div>
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <Clock className="w-3 h-3" />
            <span>Last sync: {formatLastSync(lastSync)}</span>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Check on-chain balances and credit any new deposits automatically.
          </p>
        </div>

        {/* Wallet Backup & Import Section */}
        <div className="mb-6 space-y-3">
          <WalletBackup />
          <WalletImport />
        </div>

        <div className="space-y-6 animate-fade-in">
          {/* Group by token symbol */}
          {Array.from(uniqueTokens.entries()).map(([symbol, assets]) => {
            const tokenWallets = walletsBySymbol.get(symbol) || [];
            const balance = getWalletBalance(symbol);

            return (
              <div key={symbol} className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary/20 to-primary/40 flex items-center justify-center">
                      <Wallet className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="font-medium">{symbol}</span>
                      {balance > 0 && (
                        <p className="text-xs text-muted-foreground">
                          Balance: {balance.toFixed(8)}
                        </p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Show wallets for each network this symbol supports */}
                <div className="space-y-2 ml-2 border-l-2 border-border/50 pl-4">
                  {assets.map(asset => {
                    const networkWallet = tokenWallets.find(w => w.chain === asset.chain);
                    
                    return (
                      <div key={`${asset.symbol}-${asset.chain}`} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium text-muted-foreground">
                              {asset.chain} Network
                            </span>
                            {asset.chain === 'TRX' && asset.symbol !== 'TRX' && (
                              <span className="text-xs bg-green-500/20 text-green-500 px-1.5 py-0.5 rounded">
                                Low Fee
                              </span>
                            )}
                          </div>
                          {!networkWallet && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleCreateWallet(asset.symbol, asset.chain)}
                              disabled={isCreating}
                            >
                              {isCreating ? (
                                <Loader2 className="w-4 h-4 animate-spin" />
                              ) : (
                                <>
                                  <Plus className="w-4 h-4 mr-1" />
                                  Generate
                                </>
                              )}
                            </Button>
                          )}
                        </div>

                        {networkWallet && (
                          <div className="p-3 rounded-xl bg-secondary/30 space-y-2">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                {networkWallet.is_primary && (
                                  <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                                )}
                                <span className="text-xs font-medium">
                                  {networkWallet.is_primary ? 'Primary' : 'Address'}
                                </span>
                              </div>
                              <div className="flex items-center gap-1">
                                {!networkWallet.is_primary && (
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-7 w-7"
                                    onClick={() => setPrimary({ walletId: networkWallet.id, symbol: networkWallet.symbol })}
                                  >
                                    <Star className="w-3 h-3" />
                                  </Button>
                                )}
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-7 w-7"
                                  onClick={() => copyAddress(networkWallet.address)}
                                >
                                  <Copy className="w-3 h-3" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-7 w-7 text-destructive hover:text-destructive"
                                  onClick={() => setDeleteId(networkWallet.id)}
                                >
                                  <Trash2 className="w-3 h-3" />
                                </Button>
                              </div>
                            </div>
                            <p className="text-xs text-muted-foreground font-mono break-all">
                              {networkWallet.address}
                            </p>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}

          {isLoading && (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
            </div>
          )}
        </div>
      </div>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Wallet</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this address? This action cannot be undone.
              Make sure you have copied it somewhere safe.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive hover:bg-destructive/90"
              onClick={() => {
                if (deleteId) deleteWallet(deleteId);
                setDeleteId(null);
              }}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <BottomNav />
    </div>
  );
};

export default WalletManagement;
