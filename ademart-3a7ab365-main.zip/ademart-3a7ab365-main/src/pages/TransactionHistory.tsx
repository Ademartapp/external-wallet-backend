import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ArrowUpRight, ArrowDownLeft, RefreshCw, Banknote, Search, RotateCw, ExternalLink, Copy, Check, Receipt, ShoppingCart } from 'lucide-react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { BottomNav } from '@/components/BottomNav';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { useWallet } from '@/hooks/useWallet';
import { useToast } from '@/hooks/use-toast';
import { format, formatDistanceToNow } from 'date-fns';
import { TransactionReceipt } from '@/components/TransactionReceipt';
import { TransactionExport } from '@/components/TransactionExport';

interface Transaction {
  id: string;
  type: string;
  amount: number;
  from_currency: string;
  to_currency?: string | null;
  status: string;
  created_at: string;
  tx_hash?: string | null;
  recipient_address?: string | null;
  fee?: number | null;
}

const TransactionHistory = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { syncTransactions, isSyncing } = useWallet();
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'send' | 'receive' | 'swap' | 'sell' | 'buy' | 'onchain'>('all');
  const [copiedTxHash, setCopiedTxHash] = useState<string | null>(null);
  const [selectedReceipt, setSelectedReceipt] = useState<Transaction | null>(null);

  const { data: transactions, isLoading } = useQuery({
    queryKey: ['transactions', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('transactions')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!user?.id,
  });

  // Set up realtime subscription
  useEffect(() => {
    if (!user?.id) return;

    const channel = supabase
      .channel('transactions-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'transactions',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          console.log('Transaction update:', payload);
          queryClient.invalidateQueries({ queryKey: ['transactions'] });
          
          if (payload.eventType === 'INSERT') {
            const tx = payload.new as any;
            toast({
              title: tx.type === 'receive' ? 'Deposit Received' : 'Transaction Created',
              description: `${tx.amount} ${tx.from_currency}`,
            });
          } else if (payload.eventType === 'UPDATE') {
            const tx = payload.new as any;
            const oldTx = payload.old as any;
            if (tx.status !== oldTx.status) {
              toast({
                title: 'Transaction Updated',
                description: `Status changed to ${tx.status}`,
              });
            }
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, queryClient, toast]);

  const handleSync = () => {
    syncTransactions(undefined);
  };

  const handleCopyTxHash = async (txHash: string) => {
    await navigator.clipboard.writeText(txHash);
    setCopiedTxHash(txHash);
    setTimeout(() => setCopiedTxHash(null), 2000);
  };

  const getExplorerUrl = (currency: string, txHash: string) => {
    const explorers: Record<string, string> = {
      BTC: `https://www.blockchain.com/btc/tx/${txHash}`,
      ETH: `https://etherscan.io/tx/${txHash}`,
      LTC: `https://blockchair.com/litecoin/transaction/${txHash}`,
      TRX: `https://tronscan.org/#/transaction/${txHash}`,
      BNB: `https://bscscan.com/tx/${txHash}`,
      MATIC: `https://polygonscan.com/tx/${txHash}`,
      DOGE: `https://dogechain.info/tx/${txHash}`,
      USDT: `https://tronscan.org/#/transaction/${txHash}`,
      USDC: `https://etherscan.io/tx/${txHash}`,
    };
    return explorers[currency] || `https://www.blockchain.com/search?search=${txHash}`;
  };

  const filteredTransactions = transactions?.filter((tx) => {
    const matchesSearch =
      tx.from_currency.toLowerCase().includes(search.toLowerCase()) ||
      tx.to_currency?.toLowerCase().includes(search.toLowerCase()) ||
      tx.type.toLowerCase().includes(search.toLowerCase()) ||
      tx.tx_hash?.toLowerCase().includes(search.toLowerCase());
    
    // Filter by type or by send method (on-chain)
    let matchesFilter = false;
    if (filter === 'all') {
      matchesFilter = true;
    } else if (filter === 'onchain') {
      // On-chain transactions have a tx_hash and are send/receive type
      matchesFilter = !!tx.tx_hash && (tx.type === 'send' || tx.type === 'receive');
    } else {
      matchesFilter = tx.type === filter;
    }
    
    return matchesSearch && matchesFilter;
  });

  const getIcon = (type: string) => {
    switch (type) {
      case 'send':
        return <ArrowUpRight className="w-5 h-5 text-red-500" />;
      case 'receive':
        return <ArrowDownLeft className="w-5 h-5 text-green-500" />;
      case 'swap':
        return <RefreshCw className="w-5 h-5 text-blue-500" />;
      case 'sell':
        return <Banknote className="w-5 h-5 text-amber-500" />;
      case 'buy':
        return <ShoppingCart className="w-5 h-5 text-primary" />;
      default:
        return <ArrowUpRight className="w-5 h-5" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'text-green-500 bg-green-500/10';
      case 'pending':
        return 'text-amber-500 bg-amber-500/10';
      case 'failed':
        return 'text-red-500 bg-red-500/10';
      default:
        return 'text-muted-foreground bg-secondary';
    }
  };

  const getAmountDisplay = (tx: Transaction) => {
    const prefix = tx.type === 'receive' || tx.type === 'buy' ? '+' : '-';
    const color = tx.type === 'receive' || tx.type === 'buy' ? 'text-green-500' : '';
    return <span className={color}>{prefix}{tx.amount} {tx.from_currency}</span>;
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-md mx-auto px-4 pb-24">
        <header className="flex items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/')}
              className="p-2 rounded-full bg-secondary/50 hover:bg-secondary transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-semibold">Transaction History</h1>
          </div>
          <div className="flex items-center gap-2">
            {transactions && transactions.length > 0 && (
              <TransactionExport transactions={transactions} />
            )}
            <Button
              variant="ghost"
              size="icon"
              onClick={handleSync}
              disabled={isSyncing || isLoading}
              className="hover:bg-secondary/50"
            >
              <RotateCw className={`w-5 h-5 ${isSyncing ? 'animate-spin' : ''}`} />
            </Button>
          </div>
        </header>

        <div className="space-y-4 animate-fade-in">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="Search transactions..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 bg-secondary/50 border-border/50"
            />
          </div>

          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {(['all', 'send', 'receive', 'swap', 'sell', 'buy', 'onchain'] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${
                  filter === f
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary/50 hover:bg-secondary'
                }`}
              >
                {f === 'onchain' ? '⛓️ On-Chain' : f.charAt(0).toUpperCase() + f.slice(1)}
              </button>
            ))}
          </div>

          {isLoading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-24 w-full rounded-xl" />
              ))}
            </div>
          ) : filteredTransactions?.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No transactions found</p>
              <Button 
                variant="outline" 
                size="sm" 
                className="mt-4"
                onClick={handleSync}
                disabled={isSyncing}
              >
                Sync from Bybit
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredTransactions?.map((tx) => (
                <div
                  key={tx.id}
                  className="p-4 rounded-xl bg-secondary/30 hover:bg-secondary/50 transition-colors space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center">
                        {getIcon(tx.type)}
                      </div>
                      <div>
                        <p className="font-medium capitalize">{tx.type}</p>
                        <p className="text-sm text-muted-foreground">
                          {tx.from_currency}
                          {tx.to_currency && ` → ${tx.to_currency}`}
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <p className="font-semibold">
                        {getAmountDisplay(tx)}
                      </p>
                      <span
                        className={`text-xs px-2 py-0.5 rounded-full ${getStatusColor(tx.status)}`}
                      >
                        {tx.status}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span title={format(new Date(tx.created_at), 'PPpp')}>
                      {formatDistanceToNow(new Date(tx.created_at), { addSuffix: true })}
                    </span>
                    
                    {tx.tx_hash && (
                      <div className="flex items-center gap-1">
                        <span className="font-mono truncate max-w-[100px]">
                          {tx.tx_hash.slice(0, 8)}...{tx.tx_hash.slice(-6)}
                        </span>
                        <button
                          onClick={() => handleCopyTxHash(tx.tx_hash!)}
                          className="p-1 rounded hover:bg-secondary/50"
                        >
                          {copiedTxHash === tx.tx_hash ? (
                            <Check className="w-3 h-3 text-green-500" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </button>
                        <a
                          href={getExplorerUrl(tx.from_currency, tx.tx_hash)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-1 rounded hover:bg-secondary/50"
                        >
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    )}
                  </div>

                  {tx.recipient_address && !tx.recipient_address.includes(':') && (
                    <div className="text-xs text-muted-foreground">
                      <span>To: </span>
                      <span className="font-mono">
                        {tx.recipient_address.slice(0, 10)}...{tx.recipient_address.slice(-8)}
                      </span>
                    </div>
                  )}

                  {tx.fee && tx.fee > 0 && (
                    <div className="text-xs text-muted-foreground">
                      Fee: {tx.fee} {tx.from_currency}
                    </div>
                  )}

                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full mt-2 text-xs"
                    onClick={() => setSelectedReceipt(tx)}
                  >
                    <Receipt className="w-3 h-3 mr-1" />
                    View Receipt
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <BottomNav />

      {/* Transaction Receipt Modal */}
      {selectedReceipt && (
        <TransactionReceipt
          open={!!selectedReceipt}
          onOpenChange={() => setSelectedReceipt(null)}
          transaction={{
            id: selectedReceipt.id,
            type: selectedReceipt.type as 'buy' | 'sell' | 'send' | 'receive' | 'swap',
            amount: selectedReceipt.amount,
            currency: selectedReceipt.type === 'buy' ? selectedReceipt.to_currency || selectedReceipt.from_currency : selectedReceipt.from_currency,
            status: selectedReceipt.status,
            createdAt: selectedReceipt.created_at,
            txHash: selectedReceipt.tx_hash || undefined,
            recipientAddress: selectedReceipt.recipient_address?.includes(':') ? undefined : selectedReceipt.recipient_address || undefined,
            fee: selectedReceipt.fee || undefined,
          }}
        />
      )}
    </div>
  );
};

export default TransactionHistory;
