import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, CheckCircle2, CircleDashed, Copy, RefreshCw, Trash2, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BottomNav } from '@/components/BottomNav';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { clearRecentErrors, getRecentErrors } from '@/lib/errorLogger';
import { useToast } from '@/hooks/use-toast';

type CheckStatus = 'idle' | 'running' | 'ok' | 'fail';

type HealthCheckResult = {
  status: CheckStatus;
  detail?: string;
  data?: unknown;
};

const Health = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();

  const [coingecko, setCoingecko] = useState<HealthCheckResult>({ status: 'idle' });
  const [rates, setRates] = useState<HealthCheckResult>({ status: 'idle' });
  const [feeEstimate, setFeeEstimate] = useState<HealthCheckResult>({ status: 'idle' });

  const recentErrors = useMemo(() => getRecentErrors(), []);

  const runChecks = async () => {
    setCoingecko({ status: 'running' });
    setRates({ status: 'running' });
    setFeeEstimate({ status: 'running' });

    // 1) CoinGecko ping (client-side)
    const coingeckoPromise = (async () => {
      try {
        const res = await fetch('https://api.coingecko.com/api/v3/ping', { method: 'GET' });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        setCoingecko({ status: 'ok', detail: 'Reachable', data });
      } catch (e: any) {
        setCoingecko({ status: 'fail', detail: e?.message || 'Failed' });
      }
    })();

    // 2) Rates (backend) - Quidax function
    const ratesPromise = (async () => {
      try {
        const { data, error } = await supabase.functions.invoke('quidax', {
          body: { action: 'get_all_rates' },
        });
        if (error) throw error;
        if (!data?.success) throw new Error(data?.error || 'Rates failed');
        setRates({ status: 'ok', detail: 'Rates loaded', data: data.data });
      } catch (e: any) {
        setRates({ status: 'fail', detail: e?.message || 'Rates failed' });
      }
    })();

    // 3) Fee estimate (backend) - HD wallet
    const feePromise = (async () => {
      try {
        const { data, error } = await supabase.functions.invoke('hd-wallet', {
          body: { action: 'estimate_fee', feeChain: 'TRX', feeSymbol: 'USDT' },
        });
        if (error) throw error;
        if (!data?.success) throw new Error(data?.error || 'Fee estimate failed');
        setFeeEstimate({ status: 'ok', detail: 'Fee estimated', data: data.data });
      } catch (e: any) {
        setFeeEstimate({ status: 'fail', detail: e?.message || 'Fee estimate failed' });
      }
    })();

    await Promise.allSettled([coingeckoPromise, ratesPromise, feePromise]);

    toast({
      title: 'Health check complete',
      description: 'See results below for any failing services.',
    });
  };

  const statusIcon = (s: CheckStatus) => {
    if (s === 'ok') return <CheckCircle2 className="w-4 h-4 text-green-500" />;
    if (s === 'fail') return <XCircle className="w-4 h-4 text-destructive" />;
    if (s === 'running') return <CircleDashed className="w-4 h-4 animate-spin text-muted-foreground" />;
    return <CircleDashed className="w-4 h-4 text-muted-foreground" />;
  };

  const statusBadge = (s: CheckStatus) => {
    if (s === 'ok') return <Badge variant="secondary" className="bg-green-500/20 text-green-500">OK</Badge>;
    if (s === 'fail') return <Badge variant="destructive">FAIL</Badge>;
    if (s === 'running') return <Badge variant="outline">RUNNING</Badge>;
    return <Badge variant="outline">IDLE</Badge>;
  };

  const copyJson = async (obj: unknown) => {
    await navigator.clipboard.writeText(JSON.stringify(obj, null, 2));
    toast({ title: 'Copied', description: 'Copied to clipboard' });
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-md mx-auto px-4 pb-24">
        <header className="flex items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/settings')}
              className="p-2 rounded-full bg-secondary/50 hover:bg-secondary transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-semibold">Health</h1>
              <p className="text-xs text-muted-foreground">
                {user ? `Signed in as ${user.email}` : 'Not signed in'}
              </p>
            </div>
          </div>

          <Button variant="outline" size="sm" onClick={runChecks} className="gap-2">
            <RefreshCw className="w-4 h-4" />
            Run
          </Button>
        </header>

        <div className="space-y-6 animate-fade-in">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Service checks</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/30">
                <div className="flex items-center gap-3">
                  {statusIcon(coingecko.status)}
                  <div>
                    <p className="text-sm font-medium">CoinGecko</p>
                    <p className="text-xs text-muted-foreground">Public market data</p>
                  </div>
                </div>
                <div className="text-right space-y-1">
                  {statusBadge(coingecko.status)}
                  {coingecko.detail && <p className="text-xs text-muted-foreground">{coingecko.detail}</p>}
                </div>
              </div>

              <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/30">
                <div className="flex items-center gap-3">
                  {statusIcon(rates.status)}
                  <div>
                    <p className="text-sm font-medium">Rates provider</p>
                    <p className="text-xs text-muted-foreground">Used by Swap/Buy/Sell</p>
                  </div>
                </div>
                <div className="text-right space-y-1">
                  {statusBadge(rates.status)}
                  {rates.detail && <p className="text-xs text-muted-foreground">{rates.detail}</p>}
                </div>
              </div>

              <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/30">
                <div className="flex items-center gap-3">
                  {statusIcon(feeEstimate.status)}
                  <div>
                    <p className="text-sm font-medium">TRC-20 Fee estimate</p>
                    <p className="text-xs text-muted-foreground">Used by Send (USDT/USDC on TRON)</p>
                  </div>
                </div>
                <div className="text-right space-y-1">
                  {statusBadge(feeEstimate.status)}
                  {feeEstimate.detail && <p className="text-xs text-muted-foreground">{feeEstimate.detail}</p>}
                </div>
              </div>

              {(rates.data || feeEstimate.data || coingecko.data) && (
                <div className="pt-2 grid grid-cols-2 gap-2">
                  {rates.data && (
                    <Button variant="outline" onClick={() => copyJson(rates.data)} className="gap-2">
                      <Copy className="w-4 h-4" /> Rates JSON
                    </Button>
                  )}
                  {feeEstimate.data && (
                    <Button variant="outline" onClick={() => copyJson(feeEstimate.data)} className="gap-2">
                      <Copy className="w-4 h-4" /> Fee JSON
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Recent app errors</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {recentErrors.length === 0 ? (
                <p className="text-sm text-muted-foreground">No captured client errors.</p>
              ) : (
                <div className="space-y-2">
                  {recentErrors.slice(0, 10).map((e) => (
                    <div key={e.id} className="p-3 rounded-lg bg-secondary/30">
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <p className="text-sm font-medium truncate">{e.message}</p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(e.timestamp).toLocaleString()} · {e.route || 'unknown route'}
                          </p>
                        </div>
                        <Button variant="ghost" size="sm" onClick={() => copyJson(e)} className="gap-2">
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    clearRecentErrors();
                    toast({ title: 'Cleared', description: 'Client error log cleared' });
                    window.location.reload();
                  }}
                  className="gap-2"
                >
                  <Trash2 className="w-4 h-4" />
                  Clear
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <BottomNav />
    </div>
  );
};

export default Health;
