import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ArrowUpRight, QrCode, Loader2, AtSign, AlertCircle, RefreshCw, Globe, Fuel, Info, Percent, Gift } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useWallet, supportedAssets } from '@/hooks/useWallet';
import { useAuth } from '@/contexts/AuthContext';
import { QRScanner } from '@/components/QRScanner';
import { supabase } from '@/integrations/supabase/client';
import { validateCryptoAddress, isCryptoTag, normalizeCryptoTag } from '@/utils/addressValidation';
import { usePushNotifications } from '@/hooks/usePushNotifications';
import { useEmailNotifications } from '@/hooks/useEmailNotifications';
import { useUnifiedBalances, UnifiedBalance, FeeEstimate } from '@/hooks/useUnifiedBalances';
import { Badge } from '@/components/ui/badge';
import { SendConfirmationDialog } from '@/components/SendConfirmationDialog';
import { TransactionStatusTracker } from '@/components/TransactionStatusTracker';
import { TwoFactorTransactionDialog } from '@/components/TwoFactorTransactionDialog';
import { useTwoFactorRequired } from '@/hooks/useTwoFactorRequired';
import { useTransactionStatusNotifications } from '@/hooks/useTransactionStatusNotifications';

const Send = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user } = useAuth();
  const { send, isSending: isWalletSending, refetchBalances } = useWallet();
  const { 
    balances: unifiedBalances, 
    loading: balancesLoading, 
    sendOnchain, 
    getFeeEstimate,
    isOnchainSendSupported,
    getBestSendMethod 
  } = useUnifiedBalances();
  const { sendTransactionNotification } = usePushNotifications();
  const { sendTransactionSentEmail } = useEmailNotifications();
  const { has2FAEnabled, verify2FA, is2FAVerified, reset2FAVerification } = useTwoFactorRequired();
  const { createInAppNotification } = useTransactionStatusNotifications();
  
  const [selectedAsset, setSelectedAsset] = useState<UnifiedBalance | null>(null);
  const [recipient, setRecipient] = useState('');
  const [amount, setAmount] = useState('');
  const [showScanner, setShowScanner] = useState(false);
  const [resolvedAddress, setResolvedAddress] = useState<string | null>(null);
  const [resolving, setResolving] = useState(false);
  const [addressError, setAddressError] = useState<string | null>(null);
  const [isSending, setIsSending] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [feeEstimate, setFeeEstimate] = useState<FeeEstimate | null>(null);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [show2FADialog, setShow2FADialog] = useState(false);
  const [pendingConfirmation, setPendingConfirmation] = useState(false);

  // Set default selected asset once loaded
  useEffect(() => {
    if (unifiedBalances.length > 0 && !selectedAsset) {
      setSelectedAsset(unifiedBalances[0]);
    }
  }, [unifiedBalances, selectedAsset]);

  // Get available balance
  const availableBalance = selectedAsset?.internal || 0;

  // App fee calculation (2%)
  const APP_FEE_PERCENTAGE = 0.02;
  const numAmount = parseFloat(amount) || 0;
  const appFee = numAmount * APP_FEE_PERCENTAGE;
  const recipientAmount = numAmount - appFee;

  // TRC-20 fee requirement (USDT/USDC on TRON needs TRX for fees)
  const TRC20_FEE_MIN_TRX = 15;
  const requiresTrxFees = selectedAsset && 
    (selectedAsset.symbol === 'USDT' || selectedAsset.symbol === 'USDC') && 
    selectedAsset.chain === 'TRX';
  
  const trxBalance = unifiedBalances.find(b => b.symbol === 'TRX')?.internal || 0;
  const hasEnoughTrxForFees = trxBalance >= TRC20_FEE_MIN_TRX;

  // Fetch fee estimate when asset/chain changes
  useEffect(() => {
    const fetchFee = async () => {
      if (selectedAsset) {
        const estimate = await getFeeEstimate(selectedAsset.chain, selectedAsset.symbol);
        setFeeEstimate(estimate);
      } else {
        setFeeEstimate(null);
      }
    };
    fetchFee();
  }, [selectedAsset, getFeeEstimate]);

  // Resolve crypto tag or validate address
  useEffect(() => {
    const resolveRecipient = async () => {
      if (!recipient || !selectedAsset) {
        setResolvedAddress(null);
        setAddressError(null);
        return;
      }

      if (isCryptoTag(recipient)) {
        setResolving(true);
        const tag = normalizeCryptoTag(recipient);
        
        const { data, error } = await supabase.rpc('get_user_by_crypto_tag', { tag });
        
        if (error || !data || data.length === 0) {
          setAddressError('Crypto tag not found');
          setResolvedAddress(null);
        } else {
          const match = data.find((d: { symbol: string }) => d.symbol === selectedAsset.symbol);
          if (match) {
            setResolvedAddress(match.wallet_address);
            setAddressError(null);
          } else {
            setAddressError(`User doesn't have a ${selectedAsset.symbol} wallet`);
            setResolvedAddress(null);
          }
        }
        setResolving(false);
      } else {
        const validation = validateCryptoAddress(recipient, selectedAsset.symbol);
        if (!validation.isValid) {
          setAddressError(validation.error || 'Invalid address');
          setResolvedAddress(null);
        } else {
          setResolvedAddress(recipient);
          setAddressError(null);
        }
      }
    };

    const debounce = setTimeout(resolveRecipient, 500);
    return () => clearTimeout(debounce);
  }, [recipient, selectedAsset?.symbol]);

  const handleQRScan = (result: string) => {
    const addressMatch = result.match(/^(?:[a-zA-Z]+:)?([a-zA-Z0-9]+)/);
    if (addressMatch) {
      setRecipient(addressMatch[1] || result);
    } else {
      setRecipient(result);
    }
    setShowScanner(false);
  };

  const handleSyncBalances = async () => {
    setIsSyncing(true);
    try {
      // Trigger auto-sync deposits
      const { data, error } = await supabase.functions.invoke('auto-sync-deposits', {
        body: { manual: true },
      });

      if (error) {
        throw error;
      }

      // Also refetch balances
      refetchBalances();

      toast({
        title: 'Balances Synced',
        description: data?.synced > 0 
          ? `Synced ${data.synced} new deposit(s)` 
          : 'All balances are up to date',
      });
    } catch (error: any) {
      toast({
        title: 'Sync Failed',
        description: error.message || 'Failed to sync balances',
        variant: 'destructive',
      });
    } finally {
      setIsSyncing(false);
    }
  };

  // Validate and show confirmation dialog
  const handleSendClick = () => {
    if (!user) {
      toast({
        title: 'Authentication Required',
        description: 'Please log in to send crypto',
        variant: 'destructive',
      });
      navigate('/auth');
      return;
    }

    if (!selectedAsset) {
      toast({
        title: 'Select Asset',
        description: 'Please select an asset to send',
        variant: 'destructive',
      });
      return;
    }

    if (!resolvedAddress || addressError) {
      toast({
        title: 'Invalid Recipient',
        description: addressError || 'Please enter a valid address or crypto tag',
        variant: 'destructive',
      });
      return;
    }

    if (!amount || parseFloat(amount) <= 0) {
      toast({
        title: 'Invalid Amount',
        description: 'Please enter a valid amount',
        variant: 'destructive',
      });
      return;
    }

    const sendAmount = parseFloat(amount);
    if (sendAmount > availableBalance) {
      toast({
        title: 'Insufficient Balance',
        description: `You have ${availableBalance.toFixed(8)} ${selectedAsset.symbol} available`,
        variant: 'destructive',
      });
      return;
    }

    // Show confirmation dialog first
    setShowConfirmation(true);
  };

  // Handle confirmation - check if 2FA is needed
  const handleConfirmationComplete = () => {
    setShowConfirmation(false);
    
    // If 2FA is enabled and not yet verified, show 2FA dialog
    if (has2FAEnabled && !is2FAVerified) {
      setShow2FADialog(true);
      setPendingConfirmation(true);
    } else {
      // Proceed directly to send
      handleConfirmedSend();
    }
  };

  // Handle 2FA verification success
  const handle2FAVerified = () => {
    setShow2FADialog(false);
    setPendingConfirmation(false);
    handleConfirmedSend();
  };

  // Handle 2FA skip (not recommended)
  const handle2FASkip = () => {
    setShow2FADialog(false);
    setPendingConfirmation(false);
    handleConfirmedSend();
  };

  // Execute the actual send after confirmation
  const handleConfirmedSend = async () => {
    if (!selectedAsset || !resolvedAddress) return;
    
    setIsSending(true);
    try {
      // Use on-chain sending
      const result = await sendOnchain(
        resolvedAddress,
        amount,
        selectedAsset.symbol,
        selectedAsset.chain
      );

      if (!result.success) {
        throw new Error(result.error || 'Transaction failed');
      }

      sendTransactionNotification('sent', amount, selectedAsset.symbol);
      sendTransactionSentEmail(amount, selectedAsset.symbol, resolvedAddress, result.txHash || '');
      
      toast({
        title: 'Transaction Sent!',
        description: (
          <div className="space-y-1">
            <p>Your {amount} {selectedAsset.symbol} has been sent</p>
            {result.explorerUrl && (
              <a 
                href={result.explorerUrl} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-primary underline text-sm"
              >
                View on Explorer →
              </a>
            )}
          </div>
        ),
      });

      setRecipient('');
      setAmount('');
      refetchBalances();
      navigate('/transactions');
    } catch (error: any) {
      toast({
        title: 'Send Failed',
        description: error.message || 'Failed to send transaction',
        variant: 'destructive',
      });
    } finally {
      setIsSending(false);
      setShowConfirmation(false);
    }
  };

  const isProcessing = isSending || isWalletSending;

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-md mx-auto px-4 pb-8">
        <header className="flex items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/')}
              className="p-2 rounded-full bg-secondary/50 hover:bg-secondary transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-semibold">Send Crypto</h1>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={handleSyncBalances}
            disabled={isSyncing}
            className="gap-2"
          >
            <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
            Sync
          </Button>
        </header>

        <div className="space-y-6 animate-fade-in">
          {/* TRC-20 Fee Warning - Show upfront for USDT/USDC on TRON */}
          {selectedAsset && 
           (selectedAsset.symbol === 'USDT' || selectedAsset.symbol === 'USDC') && 
           selectedAsset.chain === 'TRX' && (
            <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <Fuel className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                <div className="space-y-2 flex-1">
                  <p className="font-medium text-amber-600 dark:text-amber-400">
                    TRX Required for Fees
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Sending {selectedAsset.symbol} (TRC-20) requires <strong className="text-foreground">15-30 TRX</strong> for 
                    network energy/bandwidth. Make sure you have enough TRX in your wallet.
                  </p>
                  <div className="flex items-center justify-between gap-3 flex-wrap">
                    <div className="flex items-center gap-2 text-xs">
                      <Info className="w-3 h-3" />
                      <span className="text-muted-foreground">
                        Current TRX: {unifiedBalances.find(b => b.symbol === 'TRX')?.internal.toFixed(4) || '0'} TRX
                      </span>
                    </div>

                    {!hasEnoughTrxForFees && (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => navigate(`/swap?from=${selectedAsset.symbol}&to=TRX`)}
                      >
                        Convert to TRX
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Native TRON Fee Info */}
          {selectedAsset && 
           selectedAsset.symbol === 'TRX' && selectedAsset.chain === 'TRX' && (
            <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-3">
              <div className="flex items-center gap-2 text-sm">
                <Fuel className="w-4 h-4 text-blue-500" />
                <span className="text-blue-600 dark:text-blue-400">
                  Network fee: ~1 TRX (deducted from send amount)
                </span>
              </div>
            </div>
          )}

          {/* EVM Fee Info */}
          {selectedAsset && 
           ['ETH', 'BSC', 'MATIC'].includes(selectedAsset.chain) && (
            <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-3">
              <div className="flex items-center gap-2 text-sm">
                <Fuel className="w-4 h-4 text-blue-500" />
                <span className="text-blue-600 dark:text-blue-400">
                  {feeEstimate ? `Network fee: ~${feeEstimate.fee} ${feeEstimate.feeSymbol}` : 'Estimating fee...'}
                </span>
              </div>
            </div>
          )}

          {/* Asset Selection */}
          <div className="space-y-2">
            <Label>Select Asset</Label>
            {balancesLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <div className="grid grid-cols-3 gap-2">
                {unifiedBalances.map((balance) => (
                  <button
                    key={`${balance.symbol}-${balance.chain}`}
                    onClick={() => setSelectedAsset(balance)}
                    className={`p-3 rounded-xl border transition-all ${
                      selectedAsset?.symbol === balance.symbol && selectedAsset?.chain === balance.chain
                        ? 'border-primary bg-primary/10'
                        : 'border-border/50 bg-secondary/30 hover:bg-secondary/50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <p className="font-medium">{balance.symbol}</p>
                      {balance.total > 0 && (
                        <Badge variant="secondary" className="text-[10px] px-1">
                          ⛓️
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {balance.total.toFixed(4)}
                    </p>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Recipient Input */}
          <div className="space-y-2">
            <Label htmlFor="recipient">Recipient (Address or @CryptoTag)</Label>
            <div className="relative">
              <Input
                id="recipient"
                placeholder="Enter wallet address or @cryptotag"
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                className={`bg-secondary/50 border-border/50 pr-12 ${
                  addressError ? 'border-destructive' : resolvedAddress ? 'border-green-500' : ''
                }`}
              />
              <button 
                onClick={() => setShowScanner(true)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <QrCode className="w-5 h-5" />
              </button>
            </div>
            {resolving && (
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <Loader2 className="w-3 h-3 animate-spin" />
                Looking up crypto tag...
              </p>
            )}
            {addressError && (
              <p className="text-xs text-destructive flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                {addressError}
              </p>
            )}
            {resolvedAddress && isCryptoTag(recipient) && (
              <p className="text-xs text-green-500 flex items-center gap-1">
                <AtSign className="w-3 h-3" />
                Sending to: {resolvedAddress.slice(0, 12)}...
              </p>
            )}
          </div>

          {/* Amount Input */}
          <div className="space-y-2">
            <div className="flex justify-between">
              <Label htmlFor="amount">Amount</Label>
              <button
                onClick={() => setAmount(availableBalance.toString())}
                className="text-xs text-primary hover:underline"
              >
                MAX
              </button>
            </div>
            <Input
              id="amount"
              type="number"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="bg-secondary/50 border-border/50 text-xl font-semibold"
            />
            <p className="text-sm text-muted-foreground">
              Available: {availableBalance.toFixed(8)} {selectedAsset?.symbol}
            </p>
          </div>

          {/* Transaction Details */}
          <div className="glass-card p-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Method</span>
              <span className="flex items-center gap-1">
                <Globe className="w-3 h-3" /> On-Chain
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Network</span>
              <span>{selectedAsset?.chain}</span>
            </div>
            
            {/* App Fee (2%) */}
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground flex items-center gap-1">
                <Percent className="w-3 h-3" />
                App Fee (2%)
              </span>
              <span className="text-amber-500 font-medium">
                {appFee > 0 ? appFee.toFixed(8) : '0'} {selectedAsset?.symbol}
              </span>
            </div>
            
            {/* Recipient Gets */}
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground flex items-center gap-1">
                <Gift className="w-3 h-3" />
                Recipient Gets
              </span>
              <span className="text-green-500 font-medium">
                {recipientAmount > 0 ? recipientAmount.toFixed(8) : '0'} {selectedAsset?.symbol}
              </span>
            </div>
            
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Network Fee</span>
              <span>
                {feeEstimate 
                  ? `~${feeEstimate.fee} ${feeEstimate.feeSymbol}`
                  : 'Calculating...'}
              </span>
            </div>
            {feeEstimate && (
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Est. Time</span>
                <span>{feeEstimate.speed}</span>
              </div>
            )}
            <div className="border-t border-border/50 pt-2 mt-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">You Send</span>
                <span className="font-semibold">
                  {amount || '0'} {selectedAsset?.symbol}
                </span>
              </div>
            </div>
          </div>

          {/* Send Button */}
          <Button 
            onClick={handleSendClick} 
            disabled={isProcessing || !resolvedAddress || !!addressError || !amount || !selectedAsset || availableBalance <= 0}
            className="w-full bg-primary hover:bg-primary/90"
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <Globe className="w-4 h-4 mr-2" />
                Send {selectedAsset?.symbol}
              </>
            )}
          </Button>

          {/* Recent Transaction Status */}
          <div className="glass-card p-4">
            <TransactionStatusTracker limit={3} showOnlyPending />
          </div>

          {/* Balance Warning */}
          {selectedAsset && availableBalance <= 0 && (
            <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-3">
              <p className="text-sm text-yellow-600 dark:text-yellow-400">
                No balance available. Deposit crypto to your wallet first.
              </p>
            </div>
          )}
        </div>
      </div>

      {showScanner && (
        <QRScanner onScan={handleQRScan} onClose={() => setShowScanner(false)} />
      )}

      {/* Confirmation Dialog */}
      <SendConfirmationDialog
        open={showConfirmation}
        onOpenChange={setShowConfirmation}
        onConfirm={handleConfirmationComplete}
        recipient={resolvedAddress || recipient}
        amount={amount}
        symbol={selectedAsset?.symbol || ''}
        chain={selectedAsset?.chain || ''}
        sendMethod="onchain"
        feeEstimate={feeEstimate}
        isLoading={isSending}
        appFee={appFee}
        recipientAmount={recipientAmount}
      />

      {/* 2FA Verification Dialog */}
      <TwoFactorTransactionDialog
        open={show2FADialog}
        onOpenChange={setShow2FADialog}
        onVerified={handle2FAVerified}
        onSkip={handle2FASkip}
        verify2FA={verify2FA}
        title="Verify Transaction"
        description="Enter your 2FA code to confirm this transaction"
      />
    </div>
  );
};

export default Send;
