import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ChevronDown, Wallet, Loader2, AlertCircle, CreditCard, Building2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useQuidax } from '@/hooks/useQuidax';
import { useRealtimeWallets } from '@/hooks/useRealtimeWallets';
import { useAuth } from '@/contexts/AuthContext';

interface CryptoAsset {
  symbol: string;
  name: string;
  rateNGN: number;
}

type PaymentMethod = 'bank_transfer' | 'card';

const Buy = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user } = useAuth();
  const { wallets } = useRealtimeWallets();
  const { loading, getRates, buyCrypto } = useQuidax();
  
  const [cryptoAssets, setCryptoAssets] = useState<CryptoAsset[]>([]);
  const [selectedAsset, setSelectedAsset] = useState<CryptoAsset | null>(null);
  const [ngnAmount, setNgnAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('bank_transfer');
  const [showAssetList, setShowAssetList] = useState(false);
  const [loadingRates, setLoadingRates] = useState(true);
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    async function loadData() {
      try {
        setLoadingRates(true);
        const rates = await getRates();

        const assets: CryptoAsset[] = rates.map((rate) => ({
          symbol: rate.currency,
          name: getCryptoName(rate.currency),
          rateNGN: rate.buy,
        }));

        setCryptoAssets(assets);
        if (assets.length > 0) {
          setSelectedAsset(assets[0]);
        }
      } catch (err) {
        console.error('Failed to load data:', err);
        toast({
          title: 'Error loading data',
          description: 'Could not load exchange rates. Please try again.',
          variant: 'destructive',
        });
      } finally {
        setLoadingRates(false);
      }
    }

    if (user) {
      loadData();
    }
  }, [user]);

  function getCryptoName(symbol: string): string {
    const names: Record<string, string> = {
      BTC: 'Bitcoin',
      ETH: 'Ethereum',
      USDT: 'Tether',
      SOL: 'Solana',
    };
    return names[symbol] || symbol;
  }

  const cryptoAmount = ngnAmount && selectedAsset
    ? (parseFloat(ngnAmount) / selectedAsset.rateNGN).toFixed(8)
    : '0';

  const handleBuy = async () => {
    if (!selectedAsset) return;

    if (!ngnAmount || parseFloat(ngnAmount) <= 0) {
      toast({
        title: 'Invalid Amount',
        description: 'Please enter a valid amount in Naira',
        variant: 'destructive',
      });
      return;
    }

    const minAmount = 1000;
    if (parseFloat(ngnAmount) < minAmount) {
      toast({
        title: 'Minimum Amount',
        description: `Minimum buy amount is ₦${minAmount.toLocaleString()}`,
        variant: 'destructive',
      });
      return;
    }

    setProcessing(true);
    try {
      const result = await buyCrypto(
        selectedAsset.symbol,
        parseFloat(ngnAmount),
        paymentMethod
      );

      toast({
        title: 'Buy Order Created!',
        description: result.message,
      });

      setNgnAmount('');
      
      if (result.payment_url) {
        window.open(result.payment_url, '_blank');
      }
      
      navigate('/buy-orders');
    } catch (err) {
      console.error('Buy failed:', err);
      toast({
        title: 'Buy Failed',
        description: err instanceof Error ? err.message : 'Unknown error occurred',
        variant: 'destructive',
      });
    } finally {
      setProcessing(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Please log in to buy crypto</p>
      </div>
    );
  }

  if (loadingRates) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-md mx-auto px-4 pb-8">
        <header className="flex items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/')}
              className="p-2 rounded-full bg-secondary/50 hover:bg-secondary transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-semibold">Buy Crypto</h1>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('/buy-orders')}
            className="text-primary"
          >
            View Orders
          </Button>
        </header>

        <div className="space-y-6 animate-fade-in">
          <div className="glass-card p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center">
                <Wallet className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <p className="font-semibold">Buy with NGN</p>
                <p className="text-sm text-muted-foreground">Instant crypto purchase</p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            {/* Crypto Selection */}
            <div className="space-y-2">
              <Label>Select Crypto</Label>
              <div className="relative">
                <button
                  onClick={() => setShowAssetList(!showAssetList)}
                  className="w-full flex items-center justify-between p-4 rounded-xl bg-secondary/50 border border-border/50"
                >
                  <div className="flex items-center gap-3">
                    <span className="font-medium">{selectedAsset?.symbol}</span>
                    <span className="text-muted-foreground">{selectedAsset?.name}</span>
                  </div>
                  <ChevronDown className="w-5 h-5 text-muted-foreground" />
                </button>
                {showAssetList && (
                  <div className="absolute top-full mt-2 left-0 right-0 bg-card border border-border rounded-xl shadow-xl z-10 overflow-hidden max-h-60 overflow-y-auto">
                    {cryptoAssets.map((asset) => (
                      <button
                        key={asset.symbol}
                        onClick={() => {
                          setSelectedAsset(asset);
                          setShowAssetList(false);
                        }}
                        className="w-full px-4 py-3 text-left hover:bg-secondary/50 transition-colors flex justify-between items-center"
                      >
                        <div>
                          <span className="font-medium">{asset.symbol}</span>
                          <span className="text-muted-foreground ml-2">{asset.name}</span>
                        </div>
                        <span className="text-sm text-muted-foreground">
                          ₦{asset.rateNGN.toLocaleString()}/{asset.symbol}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* NGN Amount */}
            <div className="space-y-2">
              <Label htmlFor="ngnAmount">Amount (NGN)</Label>
              <Input
                id="ngnAmount"
                type="number"
                placeholder="0.00"
                value={ngnAmount}
                onChange={(e) => setNgnAmount(e.target.value)}
                className="bg-secondary/50 border-border/50 text-xl font-semibold"
              />
              <p className="text-xs text-muted-foreground">
                Minimum: ₦1,000
              </p>
            </div>

            {/* Crypto Amount */}
            <div className="glass-card p-4">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">You'll receive</span>
                <div className="text-right">
                  <p className="text-2xl font-bold text-primary">{cryptoAmount} {selectedAsset?.symbol}</p>
                  <p className="text-xs text-muted-foreground">
                    Rate: ₦{selectedAsset?.rateNGN.toLocaleString()}/{selectedAsset?.symbol}
                  </p>
                </div>
              </div>
            </div>

            {/* Payment Method Selection */}
            <div className="space-y-2">
              <Label>Payment Method</Label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setPaymentMethod('bank_transfer')}
                  className={`p-4 rounded-xl border transition-all flex flex-col items-center gap-2 ${
                    paymentMethod === 'bank_transfer'
                      ? 'border-primary bg-primary/10'
                      : 'border-border/50 bg-secondary/50 hover:border-border'
                  }`}
                >
                  <Building2 className={`w-6 h-6 ${paymentMethod === 'bank_transfer' ? 'text-primary' : 'text-muted-foreground'}`} />
                  <span className={`font-medium ${paymentMethod === 'bank_transfer' ? 'text-primary' : ''}`}>Bank Transfer</span>
                </button>
                <button
                  onClick={() => setPaymentMethod('card')}
                  className={`p-4 rounded-xl border transition-all flex flex-col items-center gap-2 ${
                    paymentMethod === 'card'
                      ? 'border-primary bg-primary/10'
                      : 'border-border/50 bg-secondary/50 hover:border-border'
                  }`}
                >
                  <CreditCard className={`w-6 h-6 ${paymentMethod === 'card' ? 'text-primary' : 'text-muted-foreground'}`} />
                  <span className={`font-medium ${paymentMethod === 'card' ? 'text-primary' : ''}`}>Card Payment</span>
                </button>
              </div>
            </div>

            {/* Info Notice */}
            <div className="flex items-start gap-3 p-4 rounded-xl bg-primary/10 border border-primary/20">
              <AlertCircle className="w-5 h-5 text-primary mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-primary">Instant Purchase</p>
                <p className="text-muted-foreground">
                  {paymentMethod === 'bank_transfer' 
                    ? 'You will receive bank account details to complete the payment. Crypto will be credited after confirmation.'
                    : 'You will be redirected to complete the card payment. Crypto will be credited instantly.'}
                </p>
              </div>
            </div>

            {/* Buy Button */}
            <Button
              onClick={handleBuy}
              disabled={processing || !ngnAmount || parseFloat(ngnAmount) < 1000}
              className="w-full h-14 text-lg font-semibold"
            >
              {processing ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                `Buy ${selectedAsset?.symbol}`
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Buy;
