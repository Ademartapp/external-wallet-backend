// Cryptocurrency address validation utilities

const BTC_REGEX = /^(1|3)[a-km-zA-HJ-NP-Z1-9]{25,34}$|^bc1[a-zA-HJ-NP-Z0-9]{39,59}$/;
const ETH_REGEX = /^0x[a-fA-F0-9]{40}$/;
const LTC_REGEX = /^[LM3][a-km-zA-HJ-NP-Z1-9]{26,33}$|^ltc1[a-zA-HJ-NP-Z0-9]{39,59}$/;
const TRON_REGEX = /^T[a-zA-HJ-NP-Z0-9]{33}$/;
const DOGE_REGEX = /^D[a-km-zA-HJ-NP-Z1-9]{25,34}$/;

export interface AddressValidationResult {
  isValid: boolean;
  error?: string;
}

export function validateCryptoAddress(address: string, symbol: string): AddressValidationResult {
  if (!address || address.trim() === '') {
    return { isValid: false, error: 'Address is required' };
  }

  const trimmedAddress = address.trim();

  switch (symbol.toUpperCase()) {
    case 'BTC':
      if (!BTC_REGEX.test(trimmedAddress)) {
        return { isValid: false, error: 'Invalid Bitcoin address format' };
      }
      break;
    case 'ETH':
    case 'BNB':
    case 'MATIC':
      // ETH, BSC, and Polygon all use the same address format
      if (!ETH_REGEX.test(trimmedAddress)) {
        return { isValid: false, error: `Invalid ${symbol} address format` };
      }
      break;
    case 'LTC':
      if (!LTC_REGEX.test(trimmedAddress)) {
        return { isValid: false, error: 'Invalid Litecoin address format' };
      }
      break;
    case 'TRX':
      if (!TRON_REGEX.test(trimmedAddress)) {
        return { isValid: false, error: 'Invalid TRON address format' };
      }
      break;
    case 'DOGE':
      if (!DOGE_REGEX.test(trimmedAddress)) {
        return { isValid: false, error: 'Invalid Dogecoin address format' };
      }
      break;
    case 'USDT':
      // USDT can be on TRON (TRC20) or Ethereum (ERC20)
      if (TRON_REGEX.test(trimmedAddress)) {
        return { isValid: true }; // TRC20 USDT
      }
      if (ETH_REGEX.test(trimmedAddress)) {
        return { isValid: true }; // ERC20 USDT
      }
      return { isValid: false, error: 'Invalid USDT address. Use a TRON (T...) or Ethereum (0x...) address' };
    case 'USDC':
      // USDC can be on TRON (TRC20) or Ethereum (ERC20)
      if (TRON_REGEX.test(trimmedAddress)) {
        return { isValid: true }; // TRC20 USDC
      }
      if (ETH_REGEX.test(trimmedAddress)) {
        return { isValid: true }; // ERC20 USDC
      }
      return { isValid: false, error: 'Invalid USDC address. Use a TRON (T...) or Ethereum (0x...) address' };
    default:
      // For other tokens, validate based on their parent chain
      if (trimmedAddress.startsWith('T') && TRON_REGEX.test(trimmedAddress)) {
        return { isValid: true }; // TRC20 token
      }
      if (trimmedAddress.startsWith('0x') && ETH_REGEX.test(trimmedAddress)) {
        return { isValid: true }; // ERC20/BEP20 token
      }
      return { isValid: false, error: `Unsupported cryptocurrency: ${symbol}` };
  }

  return { isValid: true };
}

export function isCryptoTag(input: string): boolean {
  // Crypto tags start with @ and contain only alphanumeric characters
  return /^@[a-zA-Z0-9_]{3,20}$/.test(input);
}

export function normalizeCryptoTag(input: string): string {
  return input.startsWith('@') ? input.slice(1) : input;
}