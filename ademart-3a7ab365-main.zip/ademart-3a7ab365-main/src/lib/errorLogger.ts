export type LoggedAppError = {
  id: string;
  timestamp: number;
  message: string;
  stack?: string;
  route?: string;
  context?: string;
  extra?: Record<string, unknown>;
};

const STORAGE_KEY = "app_error_log_v1";
const MAX_ITEMS = 20;

function safeParse<T>(raw: string | null): T | null {
  if (!raw) return null;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

export function getRecentErrors(): LoggedAppError[] {
  const parsed = safeParse<LoggedAppError[]>(localStorage.getItem(STORAGE_KEY));
  return Array.isArray(parsed) ? parsed : [];
}

export function clearRecentErrors() {
  localStorage.removeItem(STORAGE_KEY);
}

export function logAppError(input: Omit<LoggedAppError, "id" | "timestamp"> & { timestamp?: number }) {
  const entry: LoggedAppError = {
    id: `${Date.now()}_${Math.random().toString(16).slice(2)}`,
    timestamp: input.timestamp ?? Date.now(),
    message: input.message,
    stack: input.stack,
    route: input.route,
    context: input.context,
    extra: input.extra,
  };

  const existing = getRecentErrors();
  const next = [entry, ...existing].slice(0, MAX_ITEMS);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
}
