import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface QuidaxRate {
  currency: string;
  sell: number;
  buy: number;
}

interface QuidaxBank {
  id: string;
  code: string;
  name: string;
}

interface MobileMoneyProvider {
  code: string;
  name: string;
  type: string;
}

interface SellResult {
  success: boolean;
  order_id?: string;
  withdrawal_id?: string;
  ngn_amount: number;
  rate: number;
  status: string;
  payout_type: string;
  message: string;
}

interface BuyResult {
  success: boolean;
  order_id?: string;
  crypto_amount: number;
  rate: number;
  status: string;
  payment_url?: string;
  message: string;
}

interface SellOrder {
  id: string;
  crypto_amount: number;
  crypto_currency: string;
  ngn_currency: string;
  status: string;
  created_at: string;
  tx_hash: string;
  payout_type: string;
  bank_code: string;
  account_number: string;
  account_name: string;
}

interface BuyOrder {
  id: string;
  ngn_amount: number;
  crypto_amount: number;
  crypto_currency: string;
  status: string;
  created_at: string;
  payment_method: string;
}

export function useQuidax() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const callQuidax = useCallback(async (action: string, params: Record<string, any> = {}) => {
    setLoading(true);
    setError(null);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('quidax', {
        body: { action, ...params },
      });

      if (fnError) {
        throw new Error(fnError.message);
      }

      if (data?.error) {
        throw new Error(data.error);
      }

      return data;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      setError(message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const getRates = useCallback(async (): Promise<QuidaxRate[]> => {
    return callQuidax('get_all_rates');
  }, [callQuidax]);

  const getRate = useCallback(async (currency: string): Promise<QuidaxRate> => {
    const result = await callQuidax('get_rates', { currency });
    return {
      currency: currency.toUpperCase(),
      sell: parseFloat(result.sell),
      buy: parseFloat(result.buy),
    };
  }, [callQuidax]);

  const getBanks = useCallback(async (): Promise<QuidaxBank[]> => {
    return callQuidax('get_banks');
  }, [callQuidax]);

  const getMobileMoneyProviders = useCallback(async (): Promise<MobileMoneyProvider[]> => {
    return callQuidax('get_mobile_money_providers');
  }, [callQuidax]);

  const verifyAccount = useCallback(async (bankCode: string, accountNumber: string) => {
    return callQuidax('verify_account', { bank_code: bankCode, account_number: accountNumber });
  }, [callQuidax]);

  const verifyMobileMoney = useCallback(async (providerCode: string, phoneNumber: string) => {
    return callQuidax('verify_mobile_money', { provider_code: providerCode, phone_number: phoneNumber });
  }, [callQuidax]);

  const sellCrypto = useCallback(async (
    currency: string,
    amount: number,
    bankCode: string,
    accountNumber: string,
    accountName: string,
    payoutType: 'bank' | 'mobile_money' = 'bank'
  ): Promise<SellResult> => {
    return callQuidax('sell_crypto', {
      currency,
      amount,
      bank_code: bankCode,
      account_number: accountNumber,
      account_name: accountName,
      payout_type: payoutType,
    });
  }, [callQuidax]);

  const buyCrypto = useCallback(async (
    currency: string,
    ngnAmount: number,
    paymentMethod: 'bank_transfer' | 'card' = 'bank_transfer'
  ): Promise<BuyResult> => {
    return callQuidax('buy_crypto', {
      currency,
      ngn_amount: ngnAmount,
      payment_method: paymentMethod,
    });
  }, [callQuidax]);

  const getSellOrders = useCallback(async (): Promise<SellOrder[]> => {
    return callQuidax('get_sell_orders');
  }, [callQuidax]);

  const getBuyOrders = useCallback(async (): Promise<BuyOrder[]> => {
    return callQuidax('get_buy_orders');
  }, [callQuidax]);

  const cancelSellOrder = useCallback(async (transactionId: string): Promise<{ success: boolean; message: string }> => {
    return callQuidax('cancel_sell_order', { transaction_id: transactionId });
  }, [callQuidax]);

  const cancelBuyOrder = useCallback(async (transactionId: string): Promise<{ success: boolean; message: string }> => {
    return callQuidax('cancel_buy_order', { transaction_id: transactionId });
  }, [callQuidax]);

  return {
    loading,
    error,
    getRates,
    getRate,
    getBanks,
    getMobileMoneyProviders,
    verifyAccount,
    verifyMobileMoney,
    sellCrypto,
    buyCrypto,
    getSellOrders,
    getBuyOrders,
    cancelSellOrder,
    cancelBuyOrder,
  };
}
