import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export type AppRole = 'admin' | 'moderator' | 'user';

interface UserWithDetails {
  id: string;
  email: string;
  full_name: string | null;
  username: string | null;
  crypto_tag: string | null;
  avatar_url: string | null;
  created_at: string;
  role: AppRole;
}

interface WalletWithUser {
  id: string;
  user_id: string;
  currency: string;
  balance: number;
  created_at: string;
  user_email?: string;
  user_name?: string;
}

interface TransactionWithUser {
  id: string;
  user_id: string;
  type: string;
  from_currency: string;
  to_currency: string | null;
  amount: number;
  status: string;
  tx_hash: string | null;
  recipient_address: string | null;
  created_at: string;
  user_email?: string;
}

export function useAdmin() {
  const { user } = useAuth();
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState<UserWithDetails[]>([]);
  const [wallets, setWallets] = useState<WalletWithUser[]>([]);
  const [transactions, setTransactions] = useState<TransactionWithUser[]>([]);

  const checkAdminStatus = useCallback(async () => {
    if (!user) {
      setIsAdmin(false);
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id)
        .eq('role', 'admin')
        .maybeSingle();

      setIsAdmin(!!data && !error);
    } catch {
      setIsAdmin(false);
    } finally {
      setLoading(false);
    }
  }, [user]);

  const fetchAllUsers = useCallback(async () => {
    if (!isAdmin) return;

    const { data: profiles } = await supabase
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false });

    if (profiles) {
      const usersWithRoles = await Promise.all(
        profiles.map(async (profile) => {
          const { data: roleData } = await supabase
            .from('user_roles')
            .select('role')
            .eq('user_id', profile.user_id)
            .maybeSingle();

          return {
            id: profile.user_id,
            email: '', // Email would need auth access
            full_name: profile.full_name,
            username: profile.username,
            crypto_tag: profile.crypto_tag,
            avatar_url: profile.avatar_url,
            created_at: profile.created_at,
            role: (roleData?.role || 'user') as AppRole,
          };
        })
      );

      setUsers(usersWithRoles);
    }
  }, [isAdmin]);

  const fetchAllWallets = useCallback(async () => {
    if (!isAdmin) return;

    const { data } = await supabase
      .from('wallets')
      .select('*')
      .order('created_at', { ascending: false });

    if (data) {
      setWallets(data);
    }
  }, [isAdmin]);

  const fetchAllTransactions = useCallback(async () => {
    if (!isAdmin) return;

    const { data } = await supabase
      .from('transactions')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(100);

    if (data) {
      setTransactions(data);
    }
  }, [isAdmin]);

  const updateUserRole = async (userId: string, role: AppRole) => {
    const { data: existing } = await supabase
      .from('user_roles')
      .select('id')
      .eq('user_id', userId)
      .maybeSingle();

    if (existing) {
      await supabase
        .from('user_roles')
        .update({ role })
        .eq('user_id', userId);
    } else {
      await supabase
        .from('user_roles')
        .insert({ user_id: userId, role });
    }

    await fetchAllUsers();
  };

  const updateWalletBalance = async (walletId: string, newBalance: number, reason: string) => {
    if (!user) throw new Error('Not authenticated');
    
    // Validate inputs
    if (newBalance < 0) {
      throw new Error('Balance cannot be negative');
    }
    if (newBalance > 1000000) {
      throw new Error('Balance exceeds reasonable limit (1,000,000)');
    }
    if (!reason || reason.trim().length < 10) {
      throw new Error('Please provide a detailed reason (at least 10 characters)');
    }

    // Get current wallet data
    const { data: wallet, error: walletError } = await supabase
      .from('wallets')
      .select('balance, user_id, currency')
      .eq('id', walletId)
      .single();

    if (walletError || !wallet) {
      throw new Error('Wallet not found');
    }

    // Log the adjustment for audit trail
    const { error: auditError } = await supabase
      .from('admin_balance_adjustments')
      .insert({
        admin_id: user.id,
        wallet_id: walletId,
        old_balance: wallet.balance,
        new_balance: newBalance,
        reason: reason.trim(),
      });

    if (auditError) {
      console.error('Failed to log adjustment:', auditError);
      throw new Error('Failed to log adjustment');
    }

    // Update balance
    const { error: updateError } = await supabase
      .from('wallets')
      .update({ balance: newBalance })
      .eq('id', walletId);

    if (updateError) {
      throw new Error('Failed to update balance');
    }

    await fetchAllWallets();
  };

  const updateTransactionStatus = async (transactionId: string, status: string) => {
    await supabase
      .from('transactions')
      .update({ status })
      .eq('id', transactionId);

    await fetchAllTransactions();
  };

  useEffect(() => {
    checkAdminStatus();
  }, [checkAdminStatus]);

  useEffect(() => {
    if (isAdmin) {
      fetchAllUsers();
      fetchAllWallets();
      fetchAllTransactions();
    }
  }, [isAdmin, fetchAllUsers, fetchAllWallets, fetchAllTransactions]);

  return {
    isAdmin,
    loading,
    users,
    wallets,
    transactions,
    updateUserRole,
    updateWalletBalance,
    updateTransactionStatus,
    refetchUsers: fetchAllUsers,
    refetchWallets: fetchAllWallets,
    refetchTransactions: fetchAllTransactions,
  };
}