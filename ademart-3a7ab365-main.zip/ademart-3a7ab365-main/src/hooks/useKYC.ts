import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { useCallback } from 'react';

export interface KYCSubmission {
  id: string;
  user_id: string;
  full_name: string;
  date_of_birth: string;
  bvn: string;
  address: string;
  city: string;
  state: string;
  id_type: string;
  id_number: string;
  id_document_url: string | null;
  selfie_url: string | null;
  status: 'pending' | 'approved' | 'rejected';
  reviewed_by: string | null;
  reviewed_at: string | null;
  rejection_reason: string | null;
  created_at: string;
  updated_at: string;
}

export interface KYCFormData {
  fullName: string;
  dateOfBirth: string;
  bvn: string;
  address: string;
  city: string;
  state: string;
  idType: string;
  idNumber: string;
  idDocument?: File;
  selfie?: File;
}

// Security: Generate signed URLs for KYC documents (expires in 5 minutes)
export async function getSignedDocumentUrl(path: string): Promise<string | null> {
  if (!path) return null;
  
  try {
    // Extract the file path from the full URL if needed
    let filePath = path;
    if (path.includes('/storage/v1/object/public/kyc-documents/')) {
      filePath = path.split('/storage/v1/object/public/kyc-documents/')[1];
    } else if (path.includes('/kyc-documents/')) {
      filePath = path.split('/kyc-documents/').pop() || path;
    }

    const { data, error } = await supabase.storage
      .from('kyc-documents')
      .createSignedUrl(filePath, 300); // 5 minutes expiration

    if (error) {
      console.error('Error creating signed URL:', error);
      return null;
    }

    return data.signedUrl;
  } catch (err) {
    console.error('Failed to get signed URL:', err);
    return null;
  }
}

export function useKYC() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: kycStatus, isLoading } = useQuery({
    queryKey: ['kyc-status', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('kyc_submissions')
        .select('id, user_id, full_name, date_of_birth, address, city, state, id_type, status, reviewed_at, rejection_reason, created_at, updated_at')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) throw error;
      
      // Return sanitized data without sensitive fields for regular users
      return data as Omit<KYCSubmission, 'bvn' | 'id_number' | 'id_document_url' | 'selfie_url' | 'reviewed_by'> | null;
    },
    enabled: !!user?.id,
  });

  // Secure document upload - stores file path reference, not public URL
  const uploadDocument = async (file: File, type: 'id' | 'selfie'): Promise<string | null> => {
    if (!user) return null;

    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];
    if (!allowedTypes.includes(file.type)) {
      throw new Error('Invalid file type. Only JPEG, PNG, WebP, and PDF are allowed.');
    }

    // Validate file size (max 10MB)
    const maxSize = 10 * 1024 * 1024;
    if (file.size > maxSize) {
      throw new Error('File too large. Maximum size is 10MB.');
    }

    const fileExt = file.name.split('.').pop()?.toLowerCase();
    const sanitizedExt = ['jpg', 'jpeg', 'png', 'webp', 'pdf'].includes(fileExt || '') ? fileExt : 'bin';
    const fileName = `${user.id}/${type}-${Date.now()}.${sanitizedExt}`;

    const { error: uploadError } = await supabase.storage
      .from('kyc-documents')
      .upload(fileName, file, {
        cacheControl: '3600',
        upsert: false
      });

    if (uploadError) {
      console.error('Upload error:', uploadError);
      throw uploadError;
    }

    // Return the file path only, NOT a public URL
    // Signed URLs will be generated on-demand when viewing
    return fileName;
  };

  const submitKYC = useMutation({
    mutationFn: async (formData: KYCFormData) => {
      if (!user) throw new Error('Not authenticated');

      // Input validation
      if (!formData.fullName.trim() || formData.fullName.length > 100) {
        throw new Error('Invalid full name');
      }
      if (!formData.bvn.match(/^\d{11}$/)) {
        throw new Error('BVN must be exactly 11 digits');
      }
      if (!formData.idNumber.trim() || formData.idNumber.length > 50) {
        throw new Error('Invalid ID number');
      }

      let idDocumentPath: string | null = null;
      let selfiePath: string | null = null;

      // Upload documents if provided
      if (formData.idDocument) {
        idDocumentPath = await uploadDocument(formData.idDocument, 'id');
      }
      if (formData.selfie) {
        selfiePath = await uploadDocument(formData.selfie, 'selfie');
      }

      const { data, error } = await supabase
        .from('kyc_submissions')
        .insert({
          user_id: user.id,
          full_name: formData.fullName.trim().slice(0, 100),
          date_of_birth: formData.dateOfBirth,
          bvn: formData.bvn,
          address: formData.address.trim().slice(0, 255),
          city: formData.city.trim().slice(0, 100),
          state: formData.state.trim().slice(0, 100),
          id_type: formData.idType,
          id_number: formData.idNumber.trim().slice(0, 50),
          id_document_url: idDocumentPath, // Store path, not URL
          selfie_url: selfiePath, // Store path, not URL
        })
        .select('id, status, created_at')
        .single();

      if (error) throw error;

      // Also update profile with full name
      await supabase
        .from('profiles')
        .update({ full_name: formData.fullName.trim().slice(0, 100) })
        .eq('user_id', user.id);

      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['kyc-status'] });
      toast({
        title: 'KYC Submitted',
        description: 'Your verification documents have been submitted for review.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Submission Failed',
        description: error instanceof Error ? error.message : 'Failed to submit KYC',
        variant: 'destructive',
      });
    },
  });

  const updateKYCStatus = useMutation({
    mutationFn: async ({ submissionId, status, rejectionReason }: { 
      submissionId: string; 
      status: 'approved' | 'rejected';
      rejectionReason?: string;
    }) => {
      const { error } = await supabase
        .from('kyc_submissions')
        .update({
          status,
          reviewed_by: user?.id,
          reviewed_at: new Date().toISOString(),
          rejection_reason: rejectionReason?.trim().slice(0, 500) || null,
        })
        .eq('id', submissionId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['kyc-status'] });
      queryClient.invalidateQueries({ queryKey: ['all-kyc'] });
      toast({
        title: 'KYC Updated',
        description: 'KYC status has been updated.',
      });
    },
  });

  return {
    kycStatus,
    isLoading,
    submitKYC: submitKYC.mutate,
    isSubmitting: submitKYC.isPending,
    updateKYCStatus: updateKYCStatus.mutate,
    isUpdatingStatus: updateKYCStatus.isPending,
  };
}

// Admin hook to fetch all KYC submissions with secure document access
export function useAllKYC() {
  const { data: submissions = [], isLoading } = useQuery({
    queryKey: ['all-kyc'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('kyc_submissions')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as KYCSubmission[];
    },
  });

  // Function to get signed URLs for documents on-demand
  const getSecureDocumentUrls = useCallback(async (submission: KYCSubmission): Promise<{
    idDocumentUrl: string | null;
    selfieUrl: string | null;
  }> => {
    const [idDocumentUrl, selfieUrl] = await Promise.all([
      submission.id_document_url ? getSignedDocumentUrl(submission.id_document_url) : null,
      submission.selfie_url ? getSignedDocumentUrl(submission.selfie_url) : null,
    ]);

    return { idDocumentUrl, selfieUrl };
  }, []);

  return { submissions, isLoading, getSecureDocumentUrls };
}