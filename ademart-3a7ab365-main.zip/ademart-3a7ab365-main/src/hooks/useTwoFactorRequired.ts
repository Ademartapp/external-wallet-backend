import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export function useTwoFactorRequired() {
  const { user } = useAuth();
  const [has2FAEnabled, setHas2FAEnabled] = useState(false);
  const [isChecking, setIsChecking] = useState(true);
  const [is2FAVerified, setIs2FAVerified] = useState(false);

  useEffect(() => {
    const check2FA = async () => {
      if (!user) {
        setHas2FAEnabled(false);
        setIsChecking(false);
        return;
      }

      try {
        const { data: factors, error } = await supabase.auth.mfa.listFactors();
        
        if (error) {
          console.error('Error checking 2FA status:', error);
          setHas2FAEnabled(false);
        } else {
          const hasVerifiedFactor = factors.totp.some(f => f.status === 'verified');
          setHas2FAEnabled(hasVerifiedFactor);
        }
      } catch (err) {
        console.error('2FA check failed:', err);
        setHas2FAEnabled(false);
      }
      
      setIsChecking(false);
    };

    check2FA();
  }, [user]);

  const verify2FA = useCallback(async (code: string): Promise<boolean> => {
    try {
      const { data: factors, error: factorsError } = await supabase.auth.mfa.listFactors();
      
      if (factorsError) throw factorsError;

      const verifiedFactor = factors.totp.find(f => f.status === 'verified');
      
      if (!verifiedFactor) {
        throw new Error('No verified 2FA factor found');
      }

      // Create a challenge
      const { data: challengeData, error: challengeError } = await supabase.auth.mfa.challenge({
        factorId: verifiedFactor.id,
      });

      if (challengeError) throw challengeError;

      // Verify the code
      const { error: verifyError } = await supabase.auth.mfa.verify({
        factorId: verifiedFactor.id,
        challengeId: challengeData.id,
        code,
      });

      if (verifyError) {
        return false;
      }

      setIs2FAVerified(true);
      return true;
    } catch (error) {
      console.error('2FA verification failed:', error);
      return false;
    }
  }, []);

  const reset2FAVerification = useCallback(() => {
    setIs2FAVerified(false);
  }, []);

  return {
    has2FAEnabled,
    isChecking,
    is2FAVerified,
    verify2FA,
    reset2FAVerification,
  };
}
