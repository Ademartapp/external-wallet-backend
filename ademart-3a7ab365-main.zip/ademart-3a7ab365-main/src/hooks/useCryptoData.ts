import { useQuery } from '@tanstack/react-query';
import { fetchTopCoins, fetchCoinPrices, CoinPrice } from '@/services/coingecko';

export const useCryptoMarkets = (currency = 'usd', limit = 20) => {
  return useQuery({
    queryKey: ['crypto-markets', currency, limit],
    queryFn: () => fetchTopCoins(currency, limit),
    refetchInterval: 60000, // Refresh every 60 seconds (reduced from 30)
    staleTime: 30000, // Data considered fresh for 30 seconds
    retry: 2,
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 10000),
  });
};

export const useCryptoPrices = (coinIds: string[], currency = 'ngn') => {
  return useQuery({
    queryKey: ['crypto-prices', coinIds, currency],
    queryFn: () => fetchCoinPrices(coinIds, currency),
    refetchInterval: 60000, // Refresh every 60 seconds (reduced from 30)
    staleTime: 30000, // Data considered fresh for 30 seconds
    enabled: coinIds.length > 0,
    retry: 2,
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 10000),
  });
};
