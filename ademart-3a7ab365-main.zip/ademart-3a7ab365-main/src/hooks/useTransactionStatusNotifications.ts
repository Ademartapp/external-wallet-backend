import { useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { usePushNotifications } from './usePushNotifications';
import { useToast } from '@/hooks/use-toast';

interface TransactionStatusChange {
  id: string;
  status: string;
  type: string;
  from_currency: string;
  amount: number;
  tx_hash?: string;
}

export function useTransactionStatusNotifications() {
  const { user } = useAuth();
  const { sendNotification, permission } = usePushNotifications();
  const { toast } = useToast();

  const notifyStatusChange = useCallback((transaction: TransactionStatusChange) => {
    const { status, type, from_currency, amount, tx_hash } = transaction;
    
    let title = '';
    let message = '';
    let variant: 'default' | 'destructive' = 'default';
    
    switch (status) {
      case 'completed':
        title = `${type === 'send' ? 'Send' : type.charAt(0).toUpperCase() + type.slice(1)} Completed`;
        message = `Your ${amount} ${from_currency} ${type} has been completed.`;
        break;
      case 'confirmed':
        title = 'Transaction Confirmed';
        message = `Your ${amount} ${from_currency} transaction has been confirmed on-chain.`;
        break;
      case 'failed':
        title = 'Transaction Failed';
        message = `Your ${amount} ${from_currency} ${type} has failed. Please try again.`;
        variant = 'destructive';
        break;
      case 'pending':
        title = 'Transaction Pending';
        message = `Your ${amount} ${from_currency} ${type} is being processed.`;
        break;
      default:
        return;
    }

    // Show toast notification
    toast({
      title,
      description: message,
      variant,
    });

    // Send push notification if enabled
    if (permission === 'granted') {
      sendNotification(title, {
        body: message,
        tag: `tx-${transaction.id}`,
        data: { txHash: tx_hash },
      });
    }
  }, [toast, sendNotification, permission]);

  // Subscribe to realtime transaction status changes
  useEffect(() => {
    if (!user?.id) return;

    const channel = supabase
      .channel('transaction-status-changes')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'transactions',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          const oldStatus = (payload.old as any)?.status;
          const newStatus = (payload.new as TransactionStatusChange).status;
          
          // Only notify if status actually changed
          if (oldStatus !== newStatus) {
            notifyStatusChange(payload.new as TransactionStatusChange);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, notifyStatusChange]);

  // Also create in-app notifications for status changes
  const createInAppNotification = useCallback(async (
    title: string,
    message: string,
    type: string,
    data?: Record<string, unknown>
  ) => {
    if (!user?.id) return;

    try {
      const notificationData = data ? JSON.parse(JSON.stringify(data)) : null;
      await supabase.from('notifications').insert([{
        user_id: user.id,
        title,
        message,
        type,
        data: notificationData,
      }]);
    } catch (error) {
      console.error('Failed to create in-app notification:', error);
    }
  }, [user?.id]);

  return {
    notifyStatusChange,
    createInAppNotification,
  };
}
