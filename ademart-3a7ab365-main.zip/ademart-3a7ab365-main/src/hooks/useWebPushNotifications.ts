import { useEffect, useState, useCallback } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

// VAPID public key would be set here in production
const VAPID_PUBLIC_KEY = '';

export function useWebPushNotifications() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [permission, setPermission] = useState<NotificationPermission>('default');
  const [isSupported, setIsSupported] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);

  useEffect(() => {
    // Check if push notifications are supported
    const supported = 'Notification' in window && 'serviceWorker' in navigator && 'PushManager' in window;
    setIsSupported(supported);
    
    if (supported) {
      setPermission(Notification.permission);
    }
  }, []);

  const requestPermission = useCallback(async () => {
    if (!isSupported) {
      toast({
        title: 'Not Supported',
        description: 'Push notifications are not supported in this browser',
        variant: 'destructive',
      });
      return false;
    }

    try {
      const result = await Notification.requestPermission();
      setPermission(result);
      
      if (result === 'granted') {
        toast({
          title: 'Notifications Enabled',
          description: 'You will receive push notifications for deposits',
        });
        return true;
      } else {
        toast({
          title: 'Notifications Blocked',
          description: 'Please enable notifications in your browser settings',
          variant: 'destructive',
        });
        return false;
      }
    } catch (error) {
      console.error('Error requesting notification permission:', error);
      return false;
    }
  }, [isSupported, toast]);

  // Show local notification (works when app is in foreground)
  const showNotification = useCallback((title: string, body: string, data?: Record<string, unknown>) => {
    if (permission !== 'granted') return;

    try {
      new Notification(title, {
        body,
        icon: '/favicon.ico',
        tag: 'deposit-notification',
        data,
      });
    } catch (error) {
      console.error('Error showing notification:', error);
    }
  }, [permission]);

  // Subscribe to real-time deposit notifications
  useEffect(() => {
    if (!user || permission !== 'granted') return;

    const channel = supabase
      .channel('push-notifications')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'transactions',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          const transaction = payload.new as any;
          
          if (transaction.type === 'deposit' && transaction.status === 'completed') {
            showNotification(
              '💰 Deposit Received!',
              `${transaction.amount} ${transaction.from_currency} has been credited to your wallet`,
              { transactionId: transaction.id }
            );
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'transactions',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          const transaction = payload.new as any;
          const oldTransaction = payload.old as any;
          
          // Notify when status changes to completed
          if (oldTransaction.status !== 'completed' && transaction.status === 'completed') {
            if (transaction.type === 'deposit') {
              showNotification(
                '💰 Deposit Confirmed!',
                `${transaction.amount} ${transaction.from_currency} is now available`,
              );
            } else if (transaction.type === 'send') {
              showNotification(
                '✅ Transfer Complete',
                `${transaction.amount} ${transaction.from_currency} has been sent`,
              );
            }
          }
        }
      )
      .subscribe();

    setIsSubscribed(true);

    return () => {
      supabase.removeChannel(channel);
      setIsSubscribed(false);
    };
  }, [user, permission, showNotification]);

  return {
    isSupported,
    permission,
    isSubscribed,
    requestPermission,
    showNotification,
  };
}
