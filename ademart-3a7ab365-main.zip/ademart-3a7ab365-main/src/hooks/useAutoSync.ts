import { useEffect, useRef, useCallback } from 'react';
import { useOnchainSync } from './useOnchainSync';
import { useAuth } from '@/contexts/AuthContext';

const SYNC_INTERVAL = 5 * 60 * 1000; // 5 minutes

export function useAutoSync() {
  const { user } = useAuth();
  const { syncBalances, syncing, lastSync } = useOnchainSync();
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const hasInitialSync = useRef(false);

  const startAutoSync = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    
    intervalRef.current = setInterval(() => {
      if (!syncing) {
        syncBalances();
      }
    }, SYNC_INTERVAL);
  }, [syncBalances, syncing]);

  const stopAutoSync = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);

  // Initial sync on mount and start interval
  useEffect(() => {
    if (user && !hasInitialSync.current) {
      hasInitialSync.current = true;
      // Delay initial sync by 2 seconds to let page load
      const timeout = setTimeout(() => {
        syncBalances();
        startAutoSync();
      }, 2000);
      
      return () => clearTimeout(timeout);
    }
  }, [user, syncBalances, startAutoSync]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopAutoSync();
    };
  }, [stopAutoSync]);

  // Restart interval when user changes
  useEffect(() => {
    if (user) {
      startAutoSync();
    } else {
      stopAutoSync();
      hasInitialSync.current = false;
    }
  }, [user, startAutoSync, stopAutoSync]);

  return {
    syncing,
    lastSync,
    syncNow: syncBalances,
    startAutoSync,
    stopAutoSync,
  };
}
