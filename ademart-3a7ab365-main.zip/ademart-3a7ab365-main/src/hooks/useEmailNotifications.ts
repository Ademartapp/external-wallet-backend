import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

type EmailType = 'transaction_sent' | 'transaction_received' | 'wallet_created' | 'welcome' | 'deposit_received' | 'payout_completed' | 'payout_failed' | 'order_cancelled' | 'buy_order_placed' | 'buy_order_completed' | 'buy_order_cancelled';

interface EmailData {
  amount?: string;
  symbol?: string;
  txHash?: string;
  recipientAddress?: string;
  senderAddress?: string;
  walletAddress?: string;
  chain?: string;
  username?: string;
  ngnAmount?: string;
  payoutMethod?: string;
  accountName?: string;
  reason?: string;
  cryptoAmount?: string;
}

export function useEmailNotifications() {
  const { user } = useAuth();

  const sendEmail = async (type: EmailType, data: EmailData) => {
    if (!user?.email) {
      console.log('No user email available for notification');
      return;
    }

    try {
      const { error } = await supabase.functions.invoke('send-email', {
        body: {
          type,
          to: user.email,
          data,
        },
      });

      if (error) {
        console.error('Failed to send email notification:', error);
      } else {
        console.log(`Email notification sent: ${type}`);
      }
    } catch (error) {
      console.error('Error sending email notification:', error);
    }
  };

  const sendTransactionSentEmail = (amount: string, symbol: string, recipientAddress: string, txHash?: string) => {
    return sendEmail('transaction_sent', { amount, symbol, recipientAddress, txHash });
  };

  const sendTransactionReceivedEmail = (amount: string, symbol: string, senderAddress: string, txHash?: string) => {
    return sendEmail('transaction_received', { amount, symbol, senderAddress, txHash });
  };

  const sendWalletCreatedEmail = (chain: string, symbol: string, walletAddress: string) => {
    return sendEmail('wallet_created', { chain, symbol, walletAddress });
  };

  const sendWelcomeEmail = (username?: string) => {
    return sendEmail('welcome', { username });
  };

  const sendDepositReceivedEmail = (amount: string, symbol: string, txHash?: string) => {
    return sendEmail('deposit_received', { amount, symbol, txHash });
  };

  const sendPayoutCompletedEmail = (amount: string, symbol: string, ngnAmount: string, payoutMethod: string, accountName: string) => {
    return sendEmail('payout_completed', { amount, symbol, ngnAmount, payoutMethod, accountName });
  };

  const sendPayoutFailedEmail = (amount: string, symbol: string, reason?: string) => {
    return sendEmail('payout_failed', { amount, symbol, reason });
  };

  const sendOrderCancelledEmail = (amount: string, symbol: string) => {
    return sendEmail('order_cancelled', { amount, symbol });
  };

  const sendBuyOrderPlacedEmail = (cryptoAmount: string, symbol: string, ngnAmount: string, paymentMethod: string) => {
    return sendEmail('buy_order_placed', { cryptoAmount, symbol, ngnAmount, payoutMethod: paymentMethod });
  };

  const sendBuyOrderCompletedEmail = (cryptoAmount: string, symbol: string, ngnAmount: string) => {
    return sendEmail('buy_order_completed', { cryptoAmount, symbol, ngnAmount });
  };

  const sendBuyOrderCancelledEmail = (cryptoAmount: string, symbol: string, ngnAmount: string) => {
    return sendEmail('buy_order_cancelled', { cryptoAmount, symbol, ngnAmount });
  };

  return {
    sendTransactionSentEmail,
    sendTransactionReceivedEmail,
    sendWalletCreatedEmail,
    sendWelcomeEmail,
    sendDepositReceivedEmail,
    sendPayoutCompletedEmail,
    sendPayoutFailedEmail,
    sendOrderCancelledEmail,
    sendBuyOrderPlacedEmail,
    sendBuyOrderCompletedEmail,
    sendBuyOrderCancelledEmail,
  };
}
