import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useQueryClient } from '@tanstack/react-query';

interface SyncResult {
  symbol: string;
  chain: string;
  onchainBalance: number;
  credited: number;
}

interface SyncResponse {
  synced: number;
  totalCredited: number;
  results: SyncResult[];
  syncedAt: string;
}

export function useOnchainSync() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [syncing, setSyncing] = useState(false);
  const [lastSync, setLastSync] = useState<string | null>(() => {
    try {
      return localStorage.getItem('last_onchain_sync');
    } catch {
      return null;
    }
  });

  const syncBalances = async (): Promise<SyncResponse | null> => {
    setSyncing(true);
    try {
      const { data, error } = await supabase.functions.invoke('onchain-monitor', {
        body: { action: 'sync_balances' },
      });

      if (error) throw error;
      if (!data?.success) throw new Error(data?.error || 'Sync failed');

      const response = data.data as SyncResponse;
      
      // Update last sync time
      const syncTime = response.syncedAt || new Date().toISOString();
      setLastSync(syncTime);
      try {
        localStorage.setItem('last_onchain_sync', syncTime);
      } catch {}

      // Invalidate wallet queries to refresh UI
      queryClient.invalidateQueries({ queryKey: ['wallet_addresses'] });
      queryClient.invalidateQueries({ queryKey: ['wallets'] });

      // Show toast with results
      if (response.totalCredited > 0) {
        const creditedItems = response.results.filter(r => r.credited > 0);
        toast({
          title: '💰 Deposits Found!',
          description: `${creditedItems.length} deposit(s) credited to your wallet.`,
        });
      } else {
        toast({
          title: 'Sync Complete',
          description: `Checked ${response.synced} wallet(s). No new deposits found.`,
        });
      }

      return response;
    } catch (err: any) {
      console.error('Onchain sync error:', err);
      toast({
        title: 'Sync Failed',
        description: err.message || 'Failed to sync on-chain balances',
        variant: 'destructive',
      });
      return null;
    } finally {
      setSyncing(false);
    }
  };

  return {
    syncBalances,
    syncing,
    lastSync,
  };
}
