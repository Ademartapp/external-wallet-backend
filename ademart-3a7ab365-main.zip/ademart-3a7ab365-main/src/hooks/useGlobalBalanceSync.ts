import { useState, useCallback, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { useQueryClient } from '@tanstack/react-query';

interface SyncResult {
  synced: number;
  totalCredited: number;
  results: Array<{
    symbol: string;
    chain: string;
    balance: number;
    credited: number;
  }>;
}

export function useGlobalBalanceSync() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [syncing, setSyncing] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(() => {
    try {
      return localStorage.getItem('last_global_sync');
    } catch {
      return null;
    }
  });

  // Auto-sync on mount if last sync was more than 5 minutes ago
  useEffect(() => {
    if (!user) return;
    
    const lastSync = lastSyncTime ? new Date(lastSyncTime).getTime() : 0;
    const fiveMinutesAgo = Date.now() - 5 * 60 * 1000;
    
    if (lastSync < fiveMinutesAgo) {
      syncAllBalances(true); // silent sync
    }
  }, [user]);

  const syncAllBalances = useCallback(async (silent = false) => {
    if (!user || syncing) return null;

    setSyncing(true);
    try {
      // Sync on-chain balances
      const { data: onchainData, error: onchainError } = await supabase.functions.invoke('onchain-monitor', {
        body: { action: 'sync_balances' },
      });

      if (onchainError) {
        console.error('On-chain sync error:', onchainError);
      }

      // Invalidate all wallet-related queries
      queryClient.invalidateQueries({ queryKey: ['wallet_addresses'] });
      queryClient.invalidateQueries({ queryKey: ['wallets'] });
      queryClient.invalidateQueries({ queryKey: ['bybit_balances'] });

      const now = new Date().toISOString();
      setLastSyncTime(now);
      try {
        localStorage.setItem('last_global_sync', now);
      } catch {}

      const result = onchainData?.data as SyncResult | undefined;

      if (!silent) {
        if (result?.totalCredited && result.totalCredited > 0) {
          toast({
            title: '💰 New Deposits Found!',
            description: `Credited ${result.totalCredited.toFixed(4)} from on-chain deposits`,
          });
        } else {
          toast({
            title: 'Balances Synced',
            description: 'All wallet balances are up to date',
          });
        }
      }

      return result || null;
    } catch (error: any) {
      console.error('Global sync error:', error);
      if (!silent) {
        toast({
          title: 'Sync Failed',
          description: error.message || 'Failed to sync balances',
          variant: 'destructive',
        });
      }
      return null;
    } finally {
      setSyncing(false);
    }
  }, [user, syncing, queryClient, toast]);

  const syncBybitBalances = useCallback(async () => {
    queryClient.invalidateQueries({ queryKey: ['bybit_balances'] });
  }, [queryClient]);

  return {
    syncAllBalances,
    syncBybitBalances,
    syncing,
    lastSyncTime,
  };
}