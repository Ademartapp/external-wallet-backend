import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useWallet, supportedAssets } from '@/hooks/useWallet';
import { useRealtimeWallets } from '@/hooks/useRealtimeWallets';
import { useCryptoPrices } from '@/hooks/useCryptoData';

interface BalanceItem {
  coin: string;
  walletBalance: string;
}

const COINGECKO_IDS: Record<string, string> = {
  BTC: 'bitcoin',
  ETH: 'ethereum',
  LTC: 'litecoin',
  TRX: 'tron',
  BNB: 'binancecoin',
  MATIC: 'polygon-ecosystem-token',
  DOGE: 'dogecoin',
  USDT: 'tether',
  USDC: 'usd-coin',
};

const NGN_RATE = 1550; // Approximate USD to NGN rate

export interface PortfolioAsset {
  symbol: string;
  name: string;
  balance: number;
  valueUSD: number;
  valueNGN: number;
  priceUSD: number;
  change24h?: number;
}

export function usePortfolio() {
  const { user } = useAuth();
  const { balances, balancesLoading, refetchBalances } = useWallet();
  const { wallets } = useRealtimeWallets();
  const [assets, setAssets] = useState<PortfolioAsset[]>([]);
  const [totalUSD, setTotalUSD] = useState(0);
  const [totalNGN, setTotalNGN] = useState(0);
  const [loading, setLoading] = useState(true);

  const coinIds = Object.values(COINGECKO_IDS);
  const { data: prices } = useCryptoPrices(coinIds, 'usd');

  const calculatePortfolio = useCallback(() => {
    if (!user) {
      setAssets([]);
      setTotalUSD(0);
      setTotalNGN(0);
      setLoading(false);
      return;
    }

    const portfolioAssets: PortfolioAsset[] = [];

    for (const asset of supportedAssets) {
      // Get balance from unified wallet or local wallets
      const walletBalance = balances?.find((b: BalanceItem) => b.coin === asset.symbol);
      const localBalance = wallets.find(w => w.currency === asset.symbol);
      
      const balance = parseFloat(walletBalance?.walletBalance || '0') || localBalance?.balance || 0;
      
      if (balance > 0) {
        const coingeckoId = COINGECKO_IDS[asset.symbol];
        const priceData = prices?.[coingeckoId];
        const priceUSD = priceData?.usd || (asset.symbol.includes('USD') ? 1 : 0);
        const change24h = priceData?.usd_24h_change;
        
        const valueUSD = balance * priceUSD;
        const valueNGN = valueUSD * NGN_RATE;

        portfolioAssets.push({
          symbol: asset.symbol,
          name: asset.name,
          balance,
          valueUSD,
          valueNGN,
          priceUSD,
          change24h,
        });
      }
    }

    // Sort by value descending
    portfolioAssets.sort((a, b) => b.valueUSD - a.valueUSD);

    const total = portfolioAssets.reduce((sum, a) => sum + a.valueUSD, 0);
    
    setAssets(portfolioAssets);
    setTotalUSD(total);
    setTotalNGN(total * NGN_RATE);
    setLoading(false);
  }, [user, balances, wallets, prices]);

  useEffect(() => {
    calculatePortfolio();
  }, [calculatePortfolio]);

  // Set up polling for real-time updates
  useEffect(() => {
    if (!user) return;

    const interval = setInterval(() => {
      refetchBalances();
    }, 30000); // Poll every 30 seconds

    return () => clearInterval(interval);
  }, [user, refetchBalances]);

  return {
    assets,
    totalUSD,
    totalNGN,
    loading: loading || balancesLoading,
    refetch: () => {
      refetchBalances();
      calculatePortfolio();
    },
  };
}
