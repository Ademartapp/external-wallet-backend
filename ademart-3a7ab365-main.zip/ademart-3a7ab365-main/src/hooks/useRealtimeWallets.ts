import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { RealtimeChannel } from '@supabase/supabase-js';

interface Wallet {
  id: string;
  user_id: string;
  currency: string;
  balance: number;
  created_at: string;
  updated_at: string;
}

export function useRealtimeWallets() {
  const { user } = useAuth();
  const [wallets, setWallets] = useState<Wallet[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchWallets = useCallback(async () => {
    if (!user) {
      setWallets([]);
      setLoading(false);
      return;
    }

    const { data, error } = await supabase
      .from('wallets')
      .select('*')
      .eq('user_id', user.id)
      .order('currency');

    if (!error && data) {
      setWallets(data);
    }
    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchWallets();
  }, [fetchWallets]);

  useEffect(() => {
    if (!user) return;

    let channel: RealtimeChannel;

    const setupRealtime = () => {
      channel = supabase
        .channel(`wallets-${user.id}`)
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'wallets',
            filter: `user_id=eq.${user.id}`,
          },
          (payload) => {
            if (payload.eventType === 'INSERT') {
              setWallets((prev) => [...prev, payload.new as Wallet]);
            } else if (payload.eventType === 'UPDATE') {
              setWallets((prev) =>
                prev.map((w) => (w.id === (payload.new as Wallet).id ? (payload.new as Wallet) : w))
              );
            } else if (payload.eventType === 'DELETE') {
              setWallets((prev) => prev.filter((w) => w.id !== (payload.old as { id: string }).id));
            }
          }
        )
        .subscribe();
    };

    setupRealtime();

    return () => {
      if (channel) {
        supabase.removeChannel(channel);
      }
    };
  }, [user]);

  const getWalletBalance = (currency: string): number => {
    const wallet = wallets.find((w) => w.currency === currency);
    return wallet?.balance || 0;
  };

  const getTotalBalance = (prices: Record<string, number>): number => {
    return wallets.reduce((total, wallet) => {
      const price = prices[wallet.currency] || 0;
      return total + wallet.balance * price;
    }, 0);
  };

  return {
    wallets,
    loading,
    getWalletBalance,
    getTotalBalance,
    refetch: fetchWallets,
  };
}