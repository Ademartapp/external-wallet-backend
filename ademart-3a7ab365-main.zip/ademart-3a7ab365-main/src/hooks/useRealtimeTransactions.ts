import { useEffect, useState, useCallback } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface Transaction {
  id: string;
  user_id: string;
  type: string;
  amount: number;
  from_currency: string;
  to_currency: string | null;
  status: string;
  recipient_address: string | null;
  tx_hash: string | null;
  fee: number | null;
  created_at: string;
}

export function useRealtimeTransactions() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchTransactions = useCallback(async () => {
    if (!user) {
      setTransactions([]);
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('transactions')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setTransactions(data || []);
    } catch (error) {
      console.error('Error fetching transactions:', error);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    fetchTransactions();
  }, [fetchTransactions]);

  // Real-time subscription
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel('transactions-realtime')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'transactions',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          const newTx = payload.new as Transaction;
          setTransactions(prev => [newTx, ...prev].slice(0, 50));
          
          // Show notification for deposits
          if (newTx.type === 'deposit' && newTx.status === 'completed') {
            toast({
              title: '💰 Deposit Received!',
              description: `${newTx.amount} ${newTx.from_currency} has been credited`,
            });
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'transactions',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          const updatedTx = payload.new as Transaction;
          setTransactions(prev =>
            prev.map(tx => tx.id === updatedTx.id ? updatedTx : tx)
          );
          
          // Notify on status change
          if (updatedTx.status === 'completed') {
            toast({
              title: '✅ Transaction Completed',
              description: `${updatedTx.type} of ${updatedTx.amount} ${updatedTx.from_currency}`,
            });
          } else if (updatedTx.status === 'failed') {
            toast({
              title: '❌ Transaction Failed',
              description: `${updatedTx.type} of ${updatedTx.amount} ${updatedTx.from_currency}`,
              variant: 'destructive',
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, toast]);

  const getDeposits = () => transactions.filter(t => t.type === 'deposit' || t.type === 'receive');
  const getWithdrawals = () => transactions.filter(t => t.type === 'send' || t.type === 'withdrawal');
  const getSwaps = () => transactions.filter(t => t.type === 'swap');
  const getPendingTransactions = () => transactions.filter(t => t.status === 'pending');
  const getRecentTransactions = (limit: number = 10) => transactions.slice(0, limit);

  return {
    transactions,
    loading,
    refetch: fetchTransactions,
    getDeposits,
    getWithdrawals,
    getSwaps,
    getPendingTransactions,
    getRecentTransactions,
  };
}
