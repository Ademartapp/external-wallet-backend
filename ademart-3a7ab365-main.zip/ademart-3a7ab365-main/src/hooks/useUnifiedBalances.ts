import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useWallet, supportedAssets } from '@/hooks/useWallet';
import { useRealtimeWallets } from '@/hooks/useRealtimeWallets';
import { useQuery } from '@tanstack/react-query';

export type BalanceSource = 'internal' | 'onchain';

export interface UnifiedBalance {
  symbol: string;
  name: string;
  chain: string;
  internal: number;      // From wallets table (synced on-chain)
  total: number;         // Combined total
  primarySource: BalanceSource;
  address?: string;
}

export interface FeeEstimate {
  fee: string;
  feeSymbol: string;
  speed: string;
}

const assetNames: Record<string, string> = {
  BTC: 'Bitcoin',
  ETH: 'Ethereum',
  LTC: 'Litecoin',
  TRX: 'TRON',
  BNB: 'BNB',
  MATIC: 'Polygon',
  DOGE: 'Dogecoin',
  USDT: 'Tether',
  USDC: 'USD Coin',
};

// Chain name mapping from new format to display
const chainDisplayMap: Record<string, string> = {
  bitcoin: 'BTC',
  ethereum: 'ETH',
  litecoin: 'LTC',
  dogecoin: 'DOGE',
  bsc: 'BSC',
  polygon: 'MATIC',
  tron: 'TRX',
};

export function useUnifiedBalances() {
  const { user } = useAuth();
  const { balances: walletBalances, balancesLoading } = useWallet();
  const { wallets } = useRealtimeWallets();
  const [feeEstimates, setFeeEstimates] = useState<Record<string, FeeEstimate>>({});

  // Fetch wallet addresses
  const { data: walletAddresses } = useQuery({
    queryKey: ['wallet_addresses', user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data } = await supabase
        .from('wallet_addresses')
        .select('*')
        .eq('user_id', user.id);
      return data || [];
    },
    enabled: !!user?.id,
    staleTime: 60000,
  });

  // Build unified balances from wallet system
  const unifiedBalances: UnifiedBalance[] = supportedAssets.map(asset => {
    // Internal balance from wallets table
    const internalWallet = wallets.find(w => w.currency === asset.symbol);
    const internal = internalWallet?.balance || 0;

    // Also check wallet balances from unified wallet
    const unifiedBal = walletBalances?.find(
      (b: { coin: string }) => b.coin === asset.symbol
    );
    const unifiedBalance = parseFloat(unifiedBal?.walletBalance || '0');

    // Get address
    const addr = walletAddresses?.find(
      wa => wa.symbol === asset.symbol && wa.chain === asset.chain
    );

    const total = Math.max(internal, unifiedBalance);

    return {
      symbol: asset.symbol,
      name: assetNames[asset.symbol] || asset.symbol,
      chain: chainDisplayMap[asset.chain] || asset.chain.toUpperCase(),
      internal: total,
      total,
      primarySource: 'onchain' as BalanceSource,
      address: addr?.address,
    };
  });

  // Fetch fee estimate for a chain
  const getFeeEstimate = useCallback(async (chain: string, symbol: string): Promise<FeeEstimate> => {
    const cacheKey = `${chain}_${symbol}`;
    if (feeEstimates[cacheKey]) {
      return feeEstimates[cacheKey];
    }

    // Return default estimates based on chain
    const defaults: Record<string, FeeEstimate> = {
      TRX: { fee: '15-30', feeSymbol: 'TRX', speed: '~3 sec' },
      tron: { fee: '15-30', feeSymbol: 'TRX', speed: '~3 sec' },
      ETH: { fee: '0.001-0.01', feeSymbol: 'ETH', speed: '~15 sec' },
      ethereum: { fee: '0.001-0.01', feeSymbol: 'ETH', speed: '~15 sec' },
      BSC: { fee: '0.0005-0.001', feeSymbol: 'BNB', speed: '~3 sec' },
      bsc: { fee: '0.0005-0.001', feeSymbol: 'BNB', speed: '~3 sec' },
      MATIC: { fee: '0.001-0.01', feeSymbol: 'MATIC', speed: '~2 sec' },
      polygon: { fee: '0.001-0.01', feeSymbol: 'MATIC', speed: '~2 sec' },
      BTC: { fee: '0.00005-0.0005', feeSymbol: 'BTC', speed: '~10 min' },
      bitcoin: { fee: '0.00005-0.0005', feeSymbol: 'BTC', speed: '~10 min' },
      LTC: { fee: '0.0001-0.001', feeSymbol: 'LTC', speed: '~2.5 min' },
      litecoin: { fee: '0.0001-0.001', feeSymbol: 'LTC', speed: '~2.5 min' },
      DOGE: { fee: '1-5', feeSymbol: 'DOGE', speed: '~1 min' },
      dogecoin: { fee: '1-5', feeSymbol: 'DOGE', speed: '~1 min' },
    };
    
    const estimate = defaults[chain] || { fee: 'Unknown', feeSymbol: chain, speed: 'Unknown' };
    setFeeEstimates(prev => ({ ...prev, [cacheKey]: estimate }));
    return estimate;
  }, [feeEstimates]);

  // Send on-chain transaction using unified wallet
  const sendOnchain = useCallback(async (
    to: string,
    amount: string,
    symbol: string,
    chain: string
  ): Promise<{ success: boolean; txHash?: string; explorerUrl?: string; error?: string }> => {
    try {
      // Map chain display name back to actual chain
      const chainMap: Record<string, string> = {
        BTC: 'bitcoin',
        ETH: 'ethereum',
        LTC: 'litecoin',
        DOGE: 'dogecoin',
        BSC: 'bsc',
        MATIC: 'polygon',
        TRX: 'tron',
      };
      const actualChain = chainMap[chain] || chain.toLowerCase();

      const { data, error } = await supabase.functions.invoke('unified-wallet', {
        body: {
          action: 'send',
          userId: user?.id,
          symbol,
          chain: actualChain,
          toAddress: to,
          amount,
        },
      });

      if (error) {
        // Show actual backend error instead of generic message
        const errorMsg = error.message?.includes('non-2xx')
          ? 'Transaction service unavailable. Check Diagnostics page.'
          : error.message;
        return { success: false, error: errorMsg };
      }

      if (!data?.success) {
        return { success: false, error: data?.error || 'Transaction failed' };
      }

      // Generate explorer URL
      const explorerUrls: Record<string, string> = {
        bitcoin: 'https://blockchair.com/bitcoin/transaction/',
        ethereum: 'https://etherscan.io/tx/',
        polygon: 'https://polygonscan.com/tx/',
        bsc: 'https://bscscan.com/tx/',
        tron: 'https://tronscan.org/#/transaction/',
        litecoin: 'https://blockchair.com/litecoin/transaction/',
        dogecoin: 'https://blockchair.com/dogecoin/transaction/',
      };

      return {
        success: true,
        txHash: data.txHash,
        explorerUrl: data.txHash ? `${explorerUrls[actualChain] || ''}${data.txHash}` : undefined,
      };
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      return { success: false, error: errorMessage };
    }
  }, [user?.id]);

  // All chains are now supported for on-chain sending
  const isOnchainSendSupported = useCallback((chain: string): boolean => {
    const supportedChains = ['TRX', 'ETH', 'BSC', 'MATIC', 'BTC', 'LTC', 'DOGE', 
                            'tron', 'ethereum', 'bsc', 'polygon', 'bitcoin', 'litecoin', 'dogecoin'];
    return supportedChains.includes(chain);
  }, []);

  // Get best sending method - always onchain
  const getBestSendMethod = useCallback((balance: UnifiedBalance): 'onchain' | 'none' => {
    if (balance.internal > 0 && isOnchainSendSupported(balance.chain)) {
      return 'onchain';
    }
    return 'none';
  }, [isOnchainSendSupported]);

  return {
    balances: unifiedBalances,
    loading: balancesLoading,
    walletAddresses,
    getFeeEstimate,
    sendOnchain,
    isOnchainSendSupported,
    getBestSendMethod,
  };
}
