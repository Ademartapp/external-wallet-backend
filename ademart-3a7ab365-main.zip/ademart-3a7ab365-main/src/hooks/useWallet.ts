import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

export interface WalletBalance {
  symbol: string;
  chain: string;
  balance: string;
  address?: string;
}

export interface DepositAddress {
  address: string;
  chain: string;
  symbol: string;
}

// Supported assets with chain and provider info
export const supportedAssets = [
  { symbol: 'BTC', name: 'Bitcoin', chain: 'bitcoin', provider: 'cryptoapis' },
  { symbol: 'ETH', name: 'Ethereum', chain: 'ethereum', provider: 'alchemy' },
  { symbol: 'LTC', name: 'Litecoin', chain: 'litecoin', provider: 'cryptoapis' },
  { symbol: 'DOGE', name: 'Dogecoin', chain: 'dogecoin', provider: 'cryptoapis' },
  { symbol: 'BNB', name: 'BNB Smart Chain', chain: 'bsc', provider: 'alchemy' },
  { symbol: 'MATIC', name: 'Polygon', chain: 'polygon', provider: 'alchemy' },
  { symbol: 'TRX', name: 'TRON', chain: 'tron', provider: 'alchemy' },
  { symbol: 'USDT', name: 'Tether (TRC-20)', chain: 'tron', provider: 'alchemy' },
  { symbol: 'USDC', name: 'USD Coin (ERC-20)', chain: 'ethereum', provider: 'alchemy' },
];

async function callUnifiedWallet(action: string, params: Record<string, unknown> = {}) {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) throw new Error('Not authenticated');

  const { data, error } = await supabase.functions.invoke('unified-wallet', {
    body: { action, userId: session.user.id, ...params },
  });

  // Show actual backend error message instead of generic "non-2xx"
  if (error) {
    const errorMsg = error.message?.includes('non-2xx') 
      ? 'Backend service unavailable. Check Diagnostics for details.'
      : error.message;
    throw new Error(errorMsg);
  }
  
  if (!data?.success) {
    throw new Error(data?.error || 'Wallet operation failed');
  }
  
  return data;
}

export function useWallet() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get deposit address for a symbol
  const getDepositAddressMutation = useMutation({
    mutationFn: async ({ symbol, chainType }: { symbol: string; chainType?: string }) => {
      const asset = supportedAssets.find(a => a.symbol === symbol);
      const chain = chainType || asset?.chain;
      
      const result = await callUnifiedWallet('get_deposit_address', { symbol, chain });
      return {
        address: result.address,
        chain: result.chain,
        symbol: result.symbol
      } as DepositAddress;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['wallet_addresses'] });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to get deposit address',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Get all balances from unified wallet
  const { data: balances, isLoading: balancesLoading, refetch: refetchBalances } = useQuery({
    queryKey: ['unified_balances', user?.id],
    queryFn: async () => {
      const result = await callUnifiedWallet('get_all_balances');
      return result.balances.map((b: { symbol: string; chain: string; balance: string }) => ({
        coin: b.symbol,
        walletBalance: b.balance,
        transferBalance: b.balance,
        availableToWithdraw: b.balance
      }));
    },
    enabled: !!user?.id,
    staleTime: 30000,
  });

  // Get single coin balance
  const getCoinBalance = async (symbol: string) => {
    const asset = supportedAssets.find(a => a.symbol === symbol);
    const result = await callUnifiedWallet('get_balance', { symbol, chain: asset?.chain });
    return {
      coin: symbol,
      walletBalance: result.balance,
      transferBalance: result.balance,
      availableToWithdraw: result.balance
    };
  };

  // Send funds using unified wallet
  const sendMutation = useMutation({
    mutationFn: async ({ 
      symbol, 
      amount, 
      address, 
      chainType
    }: { 
      symbol: string; 
      amount: string; 
      address: string; 
      chainType?: string;
    }) => {
      const asset = supportedAssets.find(a => a.symbol === symbol);
      const chain = chainType || asset?.chain;
      
      const result = await callUnifiedWallet('send', { 
        symbol, 
        chain,
        toAddress: address, 
        amount 
      });
      
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      queryClient.invalidateQueries({ queryKey: ['unified_balances'] });
      queryClient.invalidateQueries({ queryKey: ['wallets'] });
      toast({
        title: 'Transaction initiated',
        description: 'Your transaction is being processed on-chain',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Transaction failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Validate address
  const validateAddress = async (address: string, symbol: string) => {
    const asset = supportedAssets.find(a => a.symbol === symbol);
    const result = await callUnifiedWallet('validate_address', { 
      toAddress: address, 
      symbol,
      chain: asset?.chain
    });
    return result.isValid;
  };

  // Sync transactions (refresh balances)
  const syncMutation = useMutation({
    mutationFn: async () => {
      await refetchBalances();
      return { success: true };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      toast({
        title: 'Balances refreshed',
        description: 'Your wallet balances have been updated',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Sync failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  return {
    // Deposit address
    getDepositAddress: getDepositAddressMutation.mutateAsync,
    isGettingAddress: getDepositAddressMutation.isPending,
    
    // Balances
    balances,
    balancesLoading,
    refetchBalances,
    getCoinBalance,
    
    // Sends
    send: sendMutation.mutateAsync,
    isSending: sendMutation.isPending,
    
    // Legacy aliases for compatibility
    withdraw: sendMutation.mutateAsync,
    isWithdrawing: sendMutation.isPending,
    
    // Address validation
    validateAddress,
    
    // Sync
    syncTransactions: syncMutation.mutate,
    isSyncing: syncMutation.isPending,
    
    // Supported assets
    supportedAssets,
  };
}

// No legacy Bybit exports - using unified wallet only
