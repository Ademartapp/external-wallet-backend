import { useEffect, useRef, useState, useCallback } from 'react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

interface PriceData {
  symbol: string;
  price: number;
  timestamp: number;
}

interface PriceChange {
  symbol: string;
  currentPrice: number;
  previousPrice: number;
  changePercent: number;
  direction: 'up' | 'down';
}

const PRICE_THRESHOLD_PERCENT = 3; // Alert when price moves 3%+
const CHECK_INTERVAL = 60000; // Check every minute
const PRICE_HISTORY_DURATION = 15 * 60 * 1000; // 15 minutes of history

const COINS_TO_MONITOR = [
  { symbol: 'BTC', id: 'bitcoin' },
  { symbol: 'ETH', id: 'ethereum' },
  { symbol: 'SOL', id: 'solana' },
  { symbol: 'BNB', id: 'binancecoin' },
  { symbol: 'XRP', id: 'ripple' },
];

export function usePriceMovementAlerts() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isMonitoring, setIsMonitoring] = useState(false);
  const [recentAlerts, setRecentAlerts] = useState<PriceChange[]>([]);
  const priceHistory = useRef<Map<string, PriceData[]>>(new Map());
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const fetchPrices = useCallback(async () => {
    try {
      const ids = COINS_TO_MONITOR.map(c => c.id).join(',');
      const response = await fetch(
        `https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=usd`
      );
      
      if (!response.ok) return null;
      
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Failed to fetch prices for monitoring:', error);
      return null;
    }
  }, []);

  const checkPriceMovements = useCallback(async () => {
    const prices = await fetchPrices();
    if (!prices) return;

    const now = Date.now();
    const alerts: PriceChange[] = [];

    for (const coin of COINS_TO_MONITOR) {
      const currentPrice = prices[coin.id]?.usd;
      if (!currentPrice) continue;

      // Get or initialize history for this coin
      let history = priceHistory.current.get(coin.symbol) || [];
      
      // Add current price to history
      history.push({ symbol: coin.symbol, price: currentPrice, timestamp: now });
      
      // Remove old entries
      history = history.filter(p => now - p.timestamp < PRICE_HISTORY_DURATION);
      priceHistory.current.set(coin.symbol, history);

      // Need at least 2 data points to compare
      if (history.length < 2) continue;

      // Compare with oldest price in our window
      const oldestPrice = history[0].price;
      const changePercent = ((currentPrice - oldestPrice) / oldestPrice) * 100;

      if (Math.abs(changePercent) >= PRICE_THRESHOLD_PERCENT) {
        const direction = changePercent > 0 ? 'up' : 'down';
        
        alerts.push({
          symbol: coin.symbol,
          currentPrice,
          previousPrice: oldestPrice,
          changePercent,
          direction,
        });

        // Show toast notification
        toast({
          title: `${direction === 'up' ? '📈' : '📉'} ${coin.symbol} Price Alert`,
          description: `${coin.symbol} moved ${changePercent > 0 ? '+' : ''}${changePercent.toFixed(2)}% in the last 15 minutes ($${currentPrice.toLocaleString()})`,
          duration: 8000,
        });

        // Reset history after alert to avoid repeated alerts
        priceHistory.current.set(coin.symbol, [{ symbol: coin.symbol, price: currentPrice, timestamp: now }]);
      }
    }

    if (alerts.length > 0) {
      setRecentAlerts(prev => [...alerts, ...prev].slice(0, 10));
    }
  }, [fetchPrices, toast]);

  const startMonitoring = useCallback(() => {
    if (intervalRef.current) return;
    
    setIsMonitoring(true);
    // Initial check
    checkPriceMovements();
    
    // Set up interval
    intervalRef.current = setInterval(checkPriceMovements, CHECK_INTERVAL);
  }, [checkPriceMovements]);

  const stopMonitoring = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setIsMonitoring(false);
  }, []);

  // Start monitoring when user is logged in
  useEffect(() => {
    if (user) {
      startMonitoring();
    } else {
      stopMonitoring();
    }

    return () => stopMonitoring();
  }, [user, startMonitoring, stopMonitoring]);

  return {
    isMonitoring,
    recentAlerts,
    startMonitoring,
    stopMonitoring,
  };
}
