import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { useEmailNotifications } from '@/hooks/useEmailNotifications';
import { useEffect } from 'react';

export interface WalletAddress {
  id: string;
  user_id: string;
  chain: string;
  symbol: string;
  address: string;
  xpub: string | null;
  is_primary: boolean;
  created_at: string;
  updated_at: string;
}

// Supported assets - now using unified wallet backend
export const supportedAssets = [
  { symbol: 'BTC', name: 'Bitcoin', chain: 'bitcoin', provider: 'cryptoapis' },
  { symbol: 'ETH', name: 'Ethereum', chain: 'ethereum', provider: 'alchemy' },
  { symbol: 'LTC', name: 'Litecoin', chain: 'litecoin', provider: 'cryptoapis' },
  { symbol: 'DOGE', name: 'Dogecoin', chain: 'dogecoin', provider: 'cryptoapis' },
  { symbol: 'BNB', name: 'BNB Smart Chain', chain: 'bsc', provider: 'alchemy' },
  { symbol: 'MATIC', name: 'Polygon', chain: 'polygon', provider: 'alchemy' },
  { symbol: 'TRX', name: 'TRON', chain: 'tron', provider: 'alchemy' },
  { symbol: 'USDT', name: 'Tether (TRC-20)', chain: 'tron', provider: 'alchemy' },
  { symbol: 'USDC', name: 'USD Coin (ERC-20)', chain: 'ethereum', provider: 'alchemy' },
];

// Local storage cache key - includes user ID for per-user caching
const WALLET_CACHE_KEY = 'wallet_addresses_cache_v3';

// Get cached wallets from localStorage (per-user, 24-hour validity)
function getCachedWallets(userId: string): WalletAddress[] {
  if (!userId) return [];
  try {
    const cached = localStorage.getItem(`${WALLET_CACHE_KEY}_${userId}`);
    if (cached) {
      const parsed = JSON.parse(cached);
      if (parsed.timestamp && Date.now() - parsed.timestamp < 86400000 && parsed.userId === userId) {
        console.log(`Loaded ${parsed.wallets?.length || 0} wallets from cache for user ${userId.slice(0, 8)}...`);
        return parsed.wallets || [];
      }
    }
  } catch (e) {
    console.error('Failed to read wallet cache:', e);
  }
  return [];
}

// Save wallets to localStorage cache (per-user)
function setCachedWallets(userId: string, wallets: WalletAddress[]) {
  if (!userId || !wallets.length) return;
  try {
    localStorage.setItem(`${WALLET_CACHE_KEY}_${userId}`, JSON.stringify({
      wallets,
      userId,
      timestamp: Date.now(),
    }));
    console.log(`Cached ${wallets.length} wallets for user ${userId.slice(0, 8)}...`);
  } catch (e) {
    console.error('Failed to save wallet cache:', e);
  }
}

// Clear wallet cache on logout
export function clearWalletCache(userId?: string) {
  try {
    if (userId) {
      localStorage.removeItem(`${WALLET_CACHE_KEY}_${userId}`);
    }
    const keys = Object.keys(localStorage);
    keys.forEach(key => {
      if (key.startsWith('wallet_addresses_cache')) {
        localStorage.removeItem(key);
      }
    });
  } catch (e) {
    console.error('Failed to clear wallet cache:', e);
  }
}

export function useWalletAddresses() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { sendWalletCreatedEmail } = useEmailNotifications();

  const { data: wallets = [], isLoading, refetch } = useQuery({
    queryKey: ['wallet_addresses', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const { data, error } = await supabase
        .from('wallet_addresses')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      
      if (error) {
        console.error('Failed to fetch wallet addresses:', error);
        throw error;
      }
      
      if (data && data.length > 0) {
        setCachedWallets(user.id, data as WalletAddress[]);
      }
      
      return data as WalletAddress[];
    },
    enabled: !!user?.id,
    initialData: () => user?.id ? getCachedWallets(user.id) : [],
    staleTime: 10000,
    refetchOnMount: true,
    refetchOnWindowFocus: true,
  });

  useEffect(() => {
    if (user?.id && wallets.length > 0) {
      setCachedWallets(user.id, wallets);
    }
  }, [user?.id, wallets]);

  const createWalletMutation = useMutation({
    mutationFn: async ({ symbol, chain }: { symbol: string; chain: string }) => {
      const asset = supportedAssets.find((a) => a.symbol === symbol && a.chain === chain);
      if (!asset) throw new Error(`Unsupported asset: ${symbol} on ${chain}`);

      // Use the new unified wallet backend
      const { data, error } = await supabase.functions.invoke('unified-wallet', {
        body: { 
          action: 'create_wallet', 
          userId: user?.id,
          symbol: asset.symbol, 
          chain: asset.chain 
        },
      });

      if (error) throw new Error(error.message);
      if (!data?.success) throw new Error(data?.error || 'Failed to generate wallet');

      const address = data.address as string | undefined;
      if (!address) throw new Error('Failed to generate address');

      // Send email notification for new wallets
      sendWalletCreatedEmail(asset.chain, asset.symbol, address);

      return { symbol: asset.symbol, chain: asset.chain, address };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['wallet_addresses'] });
      toast({
        title: 'Deposit Address Ready',
        description: `${data.symbol} (${data.chain}) address created successfully`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Creation Failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Create all wallets at once
  const createAllWalletsMutation = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase.functions.invoke('unified-wallet', {
        body: { 
          action: 'create_all_wallets', 
          userId: user?.id 
        },
      });

      if (error) throw new Error(error.message);
      if (!data?.success) throw new Error(data?.error || 'Failed to create wallets');

      return data.wallets;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['wallet_addresses'] });
      toast({
        title: 'All Wallets Created',
        description: 'Your deposit addresses are ready for all supported assets',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Creation Failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Legacy function for backward compatibility
  const createWallet = async (symbol: string) => {
    const asset = supportedAssets.find((a) => a.symbol === symbol);
    if (!asset) throw new Error(`Unsupported asset: ${symbol}`);
    return createWalletMutation.mutateAsync({ symbol, chain: asset.chain });
  };

  // New function that accepts both symbol and chain
  const createWalletWithChain = async (symbol: string, chain: string) => {
    return createWalletMutation.mutateAsync({ symbol, chain });
  };

  const deleteWalletMutation = useMutation({
    mutationFn: async (walletId: string) => {
      const { error } = await supabase
        .from('wallet_addresses')
        .delete()
        .eq('id', walletId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['wallet_addresses'] });
      toast({ title: 'Wallet Deleted' });
    },
    onError: (error: Error) => {
      toast({ 
        title: 'Delete Failed', 
        description: error.message,
        variant: 'destructive'
      });
    },
  });

  const setPrimaryMutation = useMutation({
    mutationFn: async ({ walletId, symbol }: { walletId: string; symbol: string }) => {
      await supabase
        .from('wallet_addresses')
        .update({ is_primary: false })
        .eq('user_id', user?.id)
        .eq('symbol', symbol);

      const { error } = await supabase
        .from('wallet_addresses')
        .update({ is_primary: true })
        .eq('id', walletId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['wallet_addresses'] });
      toast({ title: 'Primary Wallet Updated' });
    },
  });

  // Get wallets by symbol (all chains)
  const getWalletsBySymbol = (symbol: string) => wallets.filter(w => w.symbol === symbol);
  
  // Get primary wallet for symbol
  const getPrimaryWallet = (symbol: string) => wallets.find(w => w.symbol === symbol && w.is_primary);
  
  // Get wallet by symbol AND chain (more specific)
  const getWalletBySymbolAndChain = (symbol: string, chain: string) => 
    wallets.find(w => w.symbol === symbol && w.chain === chain);

  // Get deposit address (creates if doesn't exist)
  const getDepositAddress = async (symbol: string, chain?: string) => {
    const resolvedChain = chain || supportedAssets.find(a => a.symbol === symbol)?.chain;
    if (!resolvedChain) throw new Error(`Unknown asset: ${symbol}`);

    const { data, error } = await supabase.functions.invoke('unified-wallet', {
      body: { 
        action: 'get_deposit_address', 
        userId: user?.id,
        symbol,
        chain: resolvedChain
      },
    });

    if (error) throw new Error(error.message);
    if (!data?.success) throw new Error(data?.error || 'Failed to get address');

    // Refresh wallet list
    refetch();

    return data.address;
  };

  return {
    wallets,
    isLoading,
    refetch,
    supportedAssets,
    createWallet,
    createWalletWithChain,
    createAllWallets: createAllWalletsMutation.mutateAsync,
    isCreating: createWalletMutation.isPending || createAllWalletsMutation.isPending,
    deleteWallet: deleteWalletMutation.mutate,
    setPrimary: setPrimaryMutation.mutate,
    getWalletsBySymbol,
    getPrimaryWallet,
    getWalletBySymbolAndChain,
    getDepositAddress,
  };
}
