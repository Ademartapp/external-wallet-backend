import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface AdminSetting {
  id: string;
  key: string;
  value: Record<string, any>;
  created_at: string;
  updated_at: string;
}

interface FeeCollection {
  id: string;
  user_id: string;
  transaction_id: string | null;
  fee_type: string;
  currency: string;
  fee_amount: number;
  original_amount: number;
  created_at: string;
}

interface BalanceAdjustment {
  id: string;
  admin_id: string;
  wallet_id: string;
  old_balance: number;
  new_balance: number;
  reason: string;
  created_at: string;
}

export function useAdminSettings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: settings = [], isLoading: settingsLoading } = useQuery({
    queryKey: ['admin_settings'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('admin_settings')
        .select('*')
        .order('key');
      
      if (error) throw error;
      return data as AdminSetting[];
    },
  });

  const { data: feeCollections = [], isLoading: feesLoading } = useQuery({
    queryKey: ['fee_collections'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('fee_collections')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);
      
      if (error) throw error;
      return data as FeeCollection[];
    },
  });

  const { data: balanceAdjustments = [], isLoading: adjustmentsLoading } = useQuery({
    queryKey: ['balance_adjustments'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('admin_balance_adjustments')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);
      
      if (error) throw error;
      return data as BalanceAdjustment[];
    },
  });

  const updateSettingMutation = useMutation({
    mutationFn: async ({ key, value }: { key: string; value: Record<string, any> }) => {
      const { error } = await supabase
        .from('admin_settings')
        .update({ value })
        .eq('key', key);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin_settings'] });
      toast({ title: 'Setting Updated', description: 'Fee configuration saved' });
    },
    onError: (error: Error) => {
      toast({ title: 'Update Failed', description: error.message, variant: 'destructive' });
    },
  });

  const getSetting = (key: string) => {
    const setting = settings.find(s => s.key === key);
    return setting?.value;
  };

  // Calculate total profits
  const totalProfits = feeCollections.reduce((acc, fee) => {
    const currency = fee.currency;
    if (!acc[currency]) acc[currency] = 0;
    acc[currency] += fee.fee_amount;
    return acc;
  }, {} as Record<string, number>);

  return {
    settings,
    settingsLoading,
    feeCollections,
    feesLoading,
    balanceAdjustments,
    adjustmentsLoading,
    getSetting,
    updateSetting: updateSettingMutation.mutate,
    isUpdating: updateSettingMutation.isPending,
    totalProfits,
  };
}