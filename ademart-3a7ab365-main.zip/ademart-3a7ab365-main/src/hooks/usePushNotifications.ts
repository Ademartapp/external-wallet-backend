import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/contexts/AuthContext';

export function usePushNotifications() {
  const { user } = useAuth();
  const [permission, setPermission] = useState<NotificationPermission>('default');
  const [isSupported, setIsSupported] = useState(false);

  useEffect(() => {
    setIsSupported('Notification' in window);
    if ('Notification' in window) {
      setPermission(Notification.permission);
    }
  }, []);

  const requestPermission = useCallback(async () => {
    if (!isSupported) return false;

    try {
      const result = await Notification.requestPermission();
      setPermission(result);
      return result === 'granted';
    } catch {
      return false;
    }
  }, [isSupported]);

  const sendNotification = useCallback(
    (title: string, options?: NotificationOptions) => {
      if (!isSupported || permission !== 'granted' || !user) return;

      try {
        const notification = new Notification(title, {
          icon: '/favicon.ico',
          badge: '/favicon.ico',
          ...options,
        });

        notification.onclick = () => {
          window.focus();
          notification.close();
        };

        return notification;
      } catch (error) {
        console.error('Failed to send notification:', error);
      }
    },
    [isSupported, permission, user]
  );

  const sendTransactionNotification = useCallback(
    (type: 'sent' | 'received', amount: string, currency: string) => {
      const title = type === 'sent' ? 'Transaction Sent' : 'Crypto Received';
      const body =
        type === 'sent'
          ? `You sent ${amount} ${currency}`
          : `You received ${amount} ${currency}`;

      sendNotification(title, { body, tag: 'transaction' });
    },
    [sendNotification]
  );

  const sendBalanceUpdateNotification = useCallback(
    (currency: string, newBalance: string) => {
      sendNotification('Balance Updated', {
        body: `Your ${currency} balance is now ${newBalance}`,
        tag: 'balance',
      });
    },
    [sendNotification]
  );

  return {
    isSupported,
    permission,
    requestPermission,
    sendNotification,
    sendTransactionNotification,
    sendBalanceUpdateNotification,
  };
}