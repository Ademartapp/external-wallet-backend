import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { lazy, Suspense } from "react";

const Index = lazy(() => import("./pages/Index"));
const Auth = lazy(() => import("./pages/Auth"));
const Send = lazy(() => import("./pages/Send"));
const Receive = lazy(() => import("./pages/Receive"));
const Swap = lazy(() => import("./pages/Swap"));
const Sell = lazy(() => import("./pages/Sell"));
const SellOrders = lazy(() => import("./pages/SellOrders"));
const Buy = lazy(() => import("./pages/Buy"));
const BuyOrders = lazy(() => import("./pages/BuyOrders"));
const Markets = lazy(() => import("./pages/Markets"));
const TransactionHistory = lazy(() => import("./pages/TransactionHistory"));
const DepositHistory = lazy(() => import("./pages/DepositHistory"));
const WithdrawalHistory = lazy(() => import("./pages/WithdrawalHistory"));
const KYC = lazy(() => import("./pages/KYC"));
const Profile = lazy(() => import("./pages/Profile"));
const WalletManagement = lazy(() => import("./pages/WalletManagement"));
const Admin = lazy(() => import("./pages/Admin"));
const Settings = lazy(() => import("./pages/Settings"));
const NotFound = lazy(() => import("./pages/NotFound"));
const ServiceStatus = lazy(() => import("./pages/ServiceStatus"));
const Diagnostics = lazy(() => import("./pages/Diagnostics"));
const Health = lazy(() => import("./pages/Health"));

const queryClient = new QueryClient();

const PageLoader = () => (
  <div className="min-h-screen bg-background flex items-center justify-center">
    <div className="animate-pulse text-muted-foreground">Loading...</div>
  </div>
);

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter
          future={{
            v7_startTransition: true,
            v7_relativeSplatPath: true,
          }}
        >
          <Suspense fallback={<PageLoader />}>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/auth" element={<Auth />} />
              <Route path="/send" element={<Send />} />
              <Route path="/receive" element={<Receive />} />
              <Route path="/swap" element={<Swap />} />
              <Route path="/sell" element={<Sell />} />
              <Route path="/sell-orders" element={<SellOrders />} />
              <Route path="/buy" element={<Buy />} />
              <Route path="/buy-orders" element={<BuyOrders />} />
              <Route path="/markets" element={<Markets />} />
              <Route path="/transactions" element={<TransactionHistory />} />
              <Route path="/deposits" element={<DepositHistory />} />
              <Route path="/withdrawals" element={<WithdrawalHistory />} />
              <Route path="/kyc" element={<KYC />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/wallets" element={<WalletManagement />} />
              <Route path="/admin" element={<Admin />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/status" element={<ServiceStatus />} />
              <Route path="/diagnostics" element={<Diagnostics />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </Suspense>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;