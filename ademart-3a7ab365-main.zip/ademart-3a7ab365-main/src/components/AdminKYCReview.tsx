import { useState, useEffect } from 'react';
import { Check, X, Eye, FileText, User, Calendar, MapPin, CreditCard, Loader2, Shield, ShieldAlert } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { useAllKYC, useKYC, KYCSubmission } from '@/hooks/useKYC';
import { formatDistanceToNow, format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';

interface SecureDocUrls {
  idDocumentUrl: string | null;
  selfieUrl: string | null;
}

export function AdminKYCReview() {
  const { submissions, isLoading, getSecureDocumentUrls } = useAllKYC();
  const { updateKYCStatus, isUpdatingStatus } = useKYC();
  const { toast } = useToast();
  
  const [viewingSubmission, setViewingSubmission] = useState<KYCSubmission | null>(null);
  const [rejectingSubmission, setRejectingSubmission] = useState<KYCSubmission | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [secureUrls, setSecureUrls] = useState<SecureDocUrls | null>(null);
  const [loadingUrls, setLoadingUrls] = useState(false);

  // Load secure URLs when viewing a submission
  useEffect(() => {
    if (viewingSubmission) {
      setLoadingUrls(true);
      setSecureUrls(null);
      getSecureDocumentUrls(viewingSubmission)
        .then(setSecureUrls)
        .finally(() => setLoadingUrls(false));
    } else {
      setSecureUrls(null);
    }
  }, [viewingSubmission, getSecureDocumentUrls]);

  const handleApprove = (submission: KYCSubmission) => {
    updateKYCStatus({
      submissionId: submission.id,
      status: 'approved',
    });
  };

  const handleReject = () => {
    if (!rejectingSubmission || !rejectionReason.trim()) {
      toast({
        title: 'Rejection reason required',
        description: 'Please provide a reason for rejecting this KYC submission.',
        variant: 'destructive',
      });
      return;
    }

    updateKYCStatus({
      submissionId: rejectingSubmission.id,
      status: 'rejected',
      rejectionReason: rejectionReason.trim().slice(0, 500),
    });

    setRejectingSubmission(null);
    setRejectionReason('');
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <span className="px-2 py-1 rounded-full text-xs bg-green-500/20 text-green-500">Approved</span>;
      case 'rejected':
        return <span className="px-2 py-1 rounded-full text-xs bg-red-500/20 text-red-500">Rejected</span>;
      default:
        return <span className="px-2 py-1 rounded-full text-xs bg-yellow-500/20 text-yellow-500">Pending</span>;
    }
  };

  // Mask sensitive data for display
  const maskBVN = (bvn: string) => {
    if (!bvn) return '***********';
    return bvn.slice(0, 3) + '****' + bvn.slice(-4);
  };

  const maskIdNumber = (idNumber: string) => {
    if (!idNumber) return '********';
    if (idNumber.length <= 4) return '****';
    return idNumber.slice(0, 2) + '*'.repeat(idNumber.length - 4) + idNumber.slice(-2);
  };

  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const pendingCount = submissions.filter(s => s.status === 'pending').length;

  return (
    <div className="space-y-4">
      <div className="glass-card p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Shield className="w-6 h-6 text-primary" />
            <div>
              <h2 className="text-lg font-semibold">KYC Submissions</h2>
              {pendingCount > 0 && (
                <p className="text-sm text-yellow-500">{pendingCount} pending review</p>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <ShieldAlert className="w-4 h-4" />
            <span>Documents use secure signed URLs</span>
          </div>
        </div>
      </div>

      <div className="rounded-lg border border-border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>ID Type</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Submitted</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {submissions.map((submission) => (
              <TableRow key={submission.id}>
                <TableCell>
                  <div>
                    <p className="font-medium">{submission.full_name}</p>
                    <p className="text-xs text-muted-foreground font-mono">
                      {submission.user_id.slice(0, 8)}...
                    </p>
                  </div>
                </TableCell>
                <TableCell className="capitalize">{submission.id_type.replace('_', ' ')}</TableCell>
                <TableCell>{getStatusBadge(submission.status)}</TableCell>
                <TableCell className="text-sm text-muted-foreground">
                  {formatDistanceToNow(new Date(submission.created_at), { addSuffix: true })}
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setViewingSubmission(submission)}
                    >
                      <Eye className="w-4 h-4" />
                    </Button>
                    {submission.status === 'pending' && (
                      <>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-green-500 hover:text-green-600"
                          onClick={() => handleApprove(submission)}
                          disabled={isUpdatingStatus}
                        >
                          <Check className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-red-500 hover:text-red-600"
                          onClick={() => setRejectingSubmission(submission)}
                          disabled={isUpdatingStatus}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
            {submissions.length === 0 && (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                  No KYC submissions yet
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {/* View KYC Details Dialog */}
      <Dialog open={!!viewingSubmission} onOpenChange={() => setViewingSubmission(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-primary" />
              KYC Submission Details
            </DialogTitle>
          </DialogHeader>
          {viewingSubmission && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <Label className="text-muted-foreground text-xs">Full Name</Label>
                  <p className="font-medium flex items-center gap-2">
                    <User className="w-4 h-4" />
                    {viewingSubmission.full_name}
                  </p>
                </div>
                <div className="space-y-1">
                  <Label className="text-muted-foreground text-xs">Date of Birth</Label>
                  <p className="font-medium flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    {format(new Date(viewingSubmission.date_of_birth), 'PPP')}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <Label className="text-muted-foreground text-xs">BVN (Masked)</Label>
                  <p className="font-mono text-sm">{maskBVN(viewingSubmission.bvn)}</p>
                </div>
                <div className="space-y-1">
                  <Label className="text-muted-foreground text-xs">ID Number (Masked)</Label>
                  <p className="font-mono text-sm">{maskIdNumber(viewingSubmission.id_number)}</p>
                </div>
              </div>

              <div className="space-y-1">
                <Label className="text-muted-foreground text-xs">ID Type</Label>
                <p className="capitalize flex items-center gap-2">
                  <CreditCard className="w-4 h-4" />
                  {viewingSubmission.id_type.replace('_', ' ')}
                </p>
              </div>

              <div className="space-y-1">
                <Label className="text-muted-foreground text-xs">Address</Label>
                <p className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  {viewingSubmission.address}, {viewingSubmission.city}, {viewingSubmission.state}
                </p>
              </div>

              {/* Secure Document Access */}
              <div className="grid grid-cols-2 gap-4">
                {loadingUrls ? (
                  <div className="col-span-2 flex items-center justify-center py-4">
                    <Loader2 className="w-5 h-5 animate-spin mr-2" />
                    <span className="text-sm text-muted-foreground">Loading secure documents...</span>
                  </div>
                ) : (
                  <>
                    {viewingSubmission.id_document_url && (
                      <div className="space-y-2">
                        <Label className="text-muted-foreground text-xs flex items-center gap-1">
                          <Shield className="w-3 h-3" />
                          ID Document (Secure Link)
                        </Label>
                        {secureUrls?.idDocumentUrl ? (
                          <a
                            href={secureUrls.idDocumentUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="block p-4 bg-secondary/50 rounded-lg text-center hover:bg-secondary transition-colors"
                          >
                            <FileText className="w-8 h-8 mx-auto mb-2 text-primary" />
                            <span className="text-sm">View Document</span>
                            <p className="text-xs text-muted-foreground mt-1">Link expires in 5 min</p>
                          </a>
                        ) : (
                          <div className="p-4 bg-secondary/50 rounded-lg text-center text-muted-foreground">
                            <FileText className="w-8 h-8 mx-auto mb-2 opacity-50" />
                            <span className="text-sm">Unable to load</span>
                          </div>
                        )}
                      </div>
                    )}
                    {viewingSubmission.selfie_url && (
                      <div className="space-y-2">
                        <Label className="text-muted-foreground text-xs flex items-center gap-1">
                          <Shield className="w-3 h-3" />
                          Selfie (Secure Link)
                        </Label>
                        {secureUrls?.selfieUrl ? (
                          <a
                            href={secureUrls.selfieUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="block p-4 bg-secondary/50 rounded-lg text-center hover:bg-secondary transition-colors"
                          >
                            <User className="w-8 h-8 mx-auto mb-2 text-primary" />
                            <span className="text-sm">View Selfie</span>
                            <p className="text-xs text-muted-foreground mt-1">Link expires in 5 min</p>
                          </a>
                        ) : (
                          <div className="p-4 bg-secondary/50 rounded-lg text-center text-muted-foreground">
                            <User className="w-8 h-8 mx-auto mb-2 opacity-50" />
                            <span className="text-sm">Unable to load</span>
                          </div>
                        )}
                      </div>
                    )}
                  </>
                )}
              </div>

              <div className="pt-4 border-t border-border">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-muted-foreground text-xs">Status</Label>
                    <div className="mt-1">{getStatusBadge(viewingSubmission.status)}</div>
                  </div>
                  {viewingSubmission.rejection_reason && (
                    <div className="text-right">
                      <Label className="text-muted-foreground text-xs">Rejection Reason</Label>
                      <p className="text-sm text-red-500">{viewingSubmission.rejection_reason}</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            {viewingSubmission?.status === 'pending' && (
              <>
                <Button
                  variant="destructive"
                  onClick={() => {
                    setRejectingSubmission(viewingSubmission);
                    setViewingSubmission(null);
                  }}
                >
                  Reject
                </Button>
                <Button
                  onClick={() => {
                    handleApprove(viewingSubmission);
                    setViewingSubmission(null);
                  }}
                  disabled={isUpdatingStatus}
                >
                  Approve
                </Button>
              </>
            )}
            {viewingSubmission?.status !== 'pending' && (
              <Button variant="outline" onClick={() => setViewingSubmission(null)}>Close</Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reject Dialog */}
      <Dialog open={!!rejectingSubmission} onOpenChange={() => setRejectingSubmission(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject KYC Submission</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              You are about to reject the KYC submission for <strong>{rejectingSubmission?.full_name}</strong>.
              Please provide a reason for the rejection.
            </p>
            <div className="space-y-2">
              <Label htmlFor="rejectionReason">Rejection Reason</Label>
              <Input
                id="rejectionReason"
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value.slice(0, 500))}
                placeholder="e.g., ID document is blurry, information mismatch..."
                maxLength={500}
              />
              <p className="text-xs text-muted-foreground">{rejectionReason.length}/500</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRejectingSubmission(null)}>Cancel</Button>
            <Button
              variant="destructive"
              onClick={handleReject}
              disabled={isUpdatingStatus || !rejectionReason.trim()}
            >
              Reject
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}