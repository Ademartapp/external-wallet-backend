import { useState } from 'react';
import { Globe, TrendingUp, ChevronDown, ChevronUp } from 'lucide-react';
import { useUnifiedBalances } from '@/hooks/useUnifiedBalances';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';

export function BalanceBreakdown() {
  const { balances, loading } = useUnifiedBalances();
  const [expanded, setExpanded] = useState(false);

  // Calculate totals
  const totalInternal = balances.reduce((sum, b) => sum + b.internal, 0);
  const totalCombined = balances.reduce((sum, b) => sum + b.total, 0);

  // Get assets with balances
  const assetsWithBalance = balances.filter(b => b.total > 0);

  if (loading) {
    return (
      <div className="glass-card p-4 space-y-3">
        <Skeleton className="h-5 w-32" />
        <div className="grid grid-cols-1 gap-3">
          <Skeleton className="h-16 w-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="glass-card p-4 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-primary" />
          Balance Breakdown
        </h3>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setExpanded(!expanded)}
          className="text-xs"
        >
          {expanded ? (
            <>
              <ChevronUp className="w-4 h-4 mr-1" />
              Less
            </>
          ) : (
            <>
              <ChevronDown className="w-4 h-4 mr-1" />
              Details
            </>
          )}
        </Button>
      </div>

      {/* Summary Card */}
      <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500/10 to-emerald-600/5 border border-emerald-500/20">
        <div className="flex items-center gap-2 mb-1">
          <Globe className="w-4 h-4 text-emerald-500" />
          <span className="text-xs text-muted-foreground">On-Chain Wallets</span>
        </div>
        <p className="text-lg font-bold text-emerald-500">
          {assetsWithBalance.filter(b => b.internal > 0).length} assets
        </p>
        <p className="text-xs text-muted-foreground">
          Direct wallet balances
        </p>
      </div>

      {/* Expanded Details */}
      {expanded && assetsWithBalance.length > 0 && (
        <div className="space-y-2 pt-2 border-t border-border/50">
          <p className="text-xs text-muted-foreground font-medium mb-2">Asset Details</p>
          {assetsWithBalance.map((balance) => (
            <div
              key={`${balance.symbol}-${balance.chain}`}
              className="flex items-center justify-between p-2 rounded-lg bg-secondary/30"
            >
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center">
                  <span className="text-xs font-bold">{balance.symbol.slice(0, 2)}</span>
                </div>
                <div>
                  <p className="font-medium text-sm">{balance.symbol}</p>
                  <p className="text-xs text-muted-foreground">{balance.chain}</p>
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-2 text-xs">
                  {balance.internal > 0 && (
                    <span className="flex items-center gap-1 text-emerald-500">
                      <Globe className="w-3 h-3" />
                      {balance.internal.toFixed(4)}
                    </span>
                  )}
                </div>
                <p className="text-sm font-semibold mt-0.5">
                  {balance.total.toFixed(4)} total
                </p>
              </div>
            </div>
          ))}
        </div>
      )}

      {expanded && assetsWithBalance.length === 0 && (
        <div className="text-center py-4 text-muted-foreground text-sm">
          No balances found. Deposit crypto to get started.
        </div>
      )}
    </div>
  );
}
