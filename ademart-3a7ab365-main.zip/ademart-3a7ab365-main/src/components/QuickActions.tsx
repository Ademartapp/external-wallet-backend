import { ArrowDownLeft, ArrowUpRight, RefreshCw, Banknote, ShoppingCart, History, Wallet, Shield, Activity } from "lucide-react";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";

interface QuickActionsProps {
  onAction: (action: string) => void;
}

export const QuickActions = ({ onAction }: QuickActionsProps) => {
  const actions = [
    { id: 'receive', label: 'Receive', icon: ArrowDownLeft, color: 'bg-green-500/20 text-green-500' },
    { id: 'send', label: 'Send', icon: ArrowUpRight, color: 'bg-orange-500/20 text-orange-500' },
    { id: 'buy', label: 'Buy', icon: ShoppingCart, color: 'bg-primary/20 text-primary' },
    { id: 'sell', label: 'Sell', icon: Banknote, color: 'bg-amber-500/20 text-amber-500' },
    { id: 'swap', label: 'Swap', icon: RefreshCw, color: 'bg-blue-500/20 text-blue-500' },
    { id: 'history', label: 'History', icon: History, color: 'bg-secondary text-foreground' },
    { id: 'wallets', label: 'Wallets', icon: Wallet, color: 'bg-cyan-500/20 text-cyan-500' },
    { id: 'kyc', label: 'KYC', icon: Shield, color: 'bg-purple-500/20 text-purple-500' },
    { id: 'health', label: 'Health', icon: Activity, color: 'bg-secondary text-foreground' },
  ];


  return (
    <ScrollArea className="w-full animate-fade-in" style={{ animationDelay: '0.1s' }}>
      <div className="flex gap-3 pb-2">
        {actions.map((action) => (
          <button
            key={action.id}
            onClick={() => onAction(action.id)}
            className="action-button group flex flex-col items-center flex-shrink-0"
          >
            <div className={`p-3.5 rounded-xl ${action.color.split(' ')[0]} group-hover:scale-105 transition-transform`}>
              <action.icon className={`w-5 h-5 ${action.color.split(' ')[1]}`} />
            </div>
            <span className="text-xs font-medium text-muted-foreground group-hover:text-foreground transition-colors mt-1.5">
              {action.label}
            </span>
          </button>
        ))}
      </div>
      <ScrollBar orientation="horizontal" className="invisible" />
    </ScrollArea>
  );
};
