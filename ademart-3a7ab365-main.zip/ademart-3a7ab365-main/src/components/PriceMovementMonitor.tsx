import { Activity, TrendingUp, TrendingDown } from 'lucide-react';
import { usePriceMovementAlerts } from '@/hooks/usePriceMovementAlerts';

export function PriceMovementMonitor() {
  const { isMonitoring, recentAlerts } = usePriceMovementAlerts();

  return (
    <div className="rounded-xl bg-card border border-border p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Activity className={`w-4 h-4 ${isMonitoring ? 'text-green-500' : 'text-muted-foreground'}`} />
          <span className="text-sm font-medium">Price Monitor</span>
        </div>
        <div className={`w-2 h-2 rounded-full ${isMonitoring ? 'bg-green-500 animate-pulse' : 'bg-muted'}`} />
      </div>

      {recentAlerts.length === 0 ? (
        <p className="text-xs text-muted-foreground">
          Monitoring BTC, ETH, SOL, BNB, XRP for 3%+ moves
        </p>
      ) : (
        <div className="space-y-2 max-h-32 overflow-y-auto">
          {recentAlerts.slice(0, 3).map((alert, idx) => (
            <div
              key={`${alert.symbol}-${idx}`}
              className={`flex items-center justify-between p-2 rounded-lg text-xs ${
                alert.direction === 'up' ? 'bg-green-500/10' : 'bg-red-500/10'
              }`}
            >
              <div className="flex items-center gap-2">
                {alert.direction === 'up' ? (
                  <TrendingUp className="w-3 h-3 text-green-500" />
                ) : (
                  <TrendingDown className="w-3 h-3 text-red-500" />
                )}
                <span className="font-medium">{alert.symbol}</span>
              </div>
              <span className={alert.direction === 'up' ? 'text-green-500' : 'text-red-500'}>
                {alert.changePercent > 0 ? '+' : ''}{alert.changePercent.toFixed(2)}%
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
