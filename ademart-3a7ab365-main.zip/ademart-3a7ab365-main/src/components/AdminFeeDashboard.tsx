import { useState, useMemo } from 'react';
import { DollarSign, Download, Filter, TrendingUp, Calendar, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { useAdminSettings } from '@/hooks/useAdminSettings';
import { formatDistanceToNow, format, subDays, isAfter, isBefore } from 'date-fns';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const COLORS = ['hsl(var(--primary))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))', 'hsl(var(--chart-5))'];

export function AdminFeeDashboard() {
  const { feeCollections, feesLoading, totalProfits } = useAdminSettings();
  
  // Filters
  const [dateRange, setDateRange] = useState<'7d' | '30d' | '90d' | 'all'>('30d');
  const [currencyFilter, setCurrencyFilter] = useState<string>('all');
  const [feeTypeFilter, setFeeTypeFilter] = useState<string>('all');

  // Get unique currencies and fee types
  const currencies = useMemo(() => {
    const uniqueCurrencies = new Set(feeCollections.map(f => f.currency));
    return ['all', ...Array.from(uniqueCurrencies)];
  }, [feeCollections]);

  const feeTypes = useMemo(() => {
    const uniqueTypes = new Set(feeCollections.map(f => f.fee_type));
    return ['all', ...Array.from(uniqueTypes)];
  }, [feeCollections]);

  // Filter data
  const filteredFees = useMemo(() => {
    let filtered = [...feeCollections];
    
    // Date filter
    if (dateRange !== 'all') {
      const daysMap = { '7d': 7, '30d': 30, '90d': 90 };
      const cutoffDate = subDays(new Date(), daysMap[dateRange]);
      filtered = filtered.filter(f => isAfter(new Date(f.created_at), cutoffDate));
    }
    
    // Currency filter
    if (currencyFilter !== 'all') {
      filtered = filtered.filter(f => f.currency === currencyFilter);
    }
    
    // Fee type filter
    if (feeTypeFilter !== 'all') {
      filtered = filtered.filter(f => f.fee_type === feeTypeFilter);
    }
    
    return filtered;
  }, [feeCollections, dateRange, currencyFilter, feeTypeFilter]);

  // Calculate totals for filtered data
  const filteredTotals = useMemo(() => {
    const totals: Record<string, number> = {};
    filteredFees.forEach(fee => {
      totals[fee.currency] = (totals[fee.currency] || 0) + fee.fee_amount;
    });
    return totals;
  }, [filteredFees]);

  // Chart data - fees over time
  const chartData = useMemo(() => {
    const dateMap = new Map<string, number>();
    
    filteredFees.forEach(fee => {
      const date = format(new Date(fee.created_at), 'MMM dd');
      dateMap.set(date, (dateMap.get(date) || 0) + fee.fee_amount);
    });
    
    return Array.from(dateMap.entries())
      .map(([date, amount]) => ({ date, amount }))
      .slice(-14); // Last 14 data points
  }, [filteredFees]);

  // Pie chart data - by currency
  const pieData = useMemo(() => {
    return Object.entries(filteredTotals).map(([currency, amount]) => ({
      name: currency,
      value: amount,
    }));
  }, [filteredTotals]);

  // Export to CSV
  const exportToCSV = () => {
    const headers = ['Date', 'Type', 'Currency', 'Fee Amount', 'Original Amount', 'User ID'];
    const rows = filteredFees.map(fee => [
      format(new Date(fee.created_at), 'yyyy-MM-dd HH:mm:ss'),
      fee.fee_type,
      fee.currency,
      fee.fee_amount.toFixed(8),
      fee.original_amount.toFixed(8),
      fee.user_id,
    ]);
    
    const csvContent = [headers, ...rows].map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `fee-report-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (feesLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <RefreshCw className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {Object.entries(totalProfits).length > 0 ? (
          Object.entries(totalProfits).map(([currency, amount]) => (
            <Card key={currency} className="bg-gradient-to-br from-primary/10 to-primary/5">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-2xl font-bold text-primary">{amount.toFixed(6)}</p>
                    <p className="text-sm text-muted-foreground">{currency} Total</p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-primary/50" />
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          <Card className="col-span-full">
            <CardContent className="py-8 text-center text-muted-foreground">
              <DollarSign className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p>No fees collected yet</p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Filters */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Filter className="w-5 h-5" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>Date Range</Label>
              <Select value={dateRange} onValueChange={(v: any) => setDateRange(v)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7d">Last 7 days</SelectItem>
                  <SelectItem value="30d">Last 30 days</SelectItem>
                  <SelectItem value="90d">Last 90 days</SelectItem>
                  <SelectItem value="all">All time</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Currency</Label>
              <Select value={currencyFilter} onValueChange={setCurrencyFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {currencies.map(c => (
                    <SelectItem key={c} value={c}>
                      {c === 'all' ? 'All Currencies' : c}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Fee Type</Label>
              <Select value={feeTypeFilter} onValueChange={setFeeTypeFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {feeTypes.map(t => (
                    <SelectItem key={t} value={t}>
                      {t === 'all' ? 'All Types' : t.charAt(0).toUpperCase() + t.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>&nbsp;</Label>
              <Button variant="outline" onClick={exportToCSV} className="w-full">
                <Download className="w-4 h-4 mr-2" />
                Export CSV
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Charts */}
      {chartData.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Fees Over Time</CardTitle>
              <CardDescription>Daily fee collection trend</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={200}>
                <AreaChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="date" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                  <YAxis tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                    }} 
                  />
                  <Area 
                    type="monotone" 
                    dataKey="amount" 
                    stroke="hsl(var(--primary))" 
                    fill="hsl(var(--primary) / 0.2)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">By Currency</CardTitle>
              <CardDescription>Fee distribution by cryptocurrency</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={40}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {pieData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Filtered Totals */}
      {Object.keys(filteredTotals).length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Filtered Period Totals</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4">
              {Object.entries(filteredTotals).map(([currency, amount]) => (
                <Badge key={currency} variant="secondary" className="px-4 py-2 text-lg">
                  {amount.toFixed(8)} {currency}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Transactions Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Recent Fee Collections</span>
            <Badge variant="outline">{filteredFees.length} records</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-lg border border-border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Type</TableHead>
                  <TableHead>Currency</TableHead>
                  <TableHead>Fee Amount</TableHead>
                  <TableHead>Original</TableHead>
                  <TableHead>%</TableHead>
                  <TableHead>Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredFees.slice(0, 50).map((fee) => (
                  <TableRow key={fee.id}>
                    <TableCell>
                      <Badge variant="outline" className="capitalize">
                        {fee.fee_type}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-medium">{fee.currency}</TableCell>
                    <TableCell className="text-primary font-medium">
                      +{fee.fee_amount.toFixed(8)}
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {fee.original_amount.toFixed(6)}
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {((fee.fee_amount / fee.original_amount) * 100).toFixed(2)}%
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {formatDistanceToNow(new Date(fee.created_at), { addSuffix: true })}
                    </TableCell>
                  </TableRow>
                ))}
                {filteredFees.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                      No fee collections match your filters
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          {filteredFees.length > 50 && (
            <p className="text-sm text-muted-foreground text-center mt-4">
              Showing 50 of {filteredFees.length} records. Export CSV for full data.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}