import { useState } from 'react';
import { Download, Loader2, AlertTriangle, Check, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useQueryClient } from '@tanstack/react-query';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

export function WalletImport() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isOpen, setIsOpen] = useState(false);
  const [mnemonic, setMnemonic] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showPhrase, setShowPhrase] = useState(false);
  const [importSuccess, setImportSuccess] = useState(false);

  const handleImport = async () => {
    if (!mnemonic.trim()) {
      toast({
        title: 'Error',
        description: 'Please enter your recovery phrase',
        variant: 'destructive',
      });
      return;
    }

    // Basic validation - check word count
    const words = mnemonic.trim().split(/\s+/);
    if (words.length !== 12 && words.length !== 24) {
      toast({
        title: 'Invalid Recovery Phrase',
        description: 'Recovery phrase must be 12 or 24 words',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('hd-wallet', {
        body: { action: 'import_wallet', mnemonic: mnemonic.trim() },
      });

      if (error) throw new Error(error.message);
      if (!data?.success) throw new Error(data?.error || 'Failed to import wallet');

      setImportSuccess(true);
      queryClient.invalidateQueries({ queryKey: ['wallet_addresses'] });
      queryClient.invalidateQueries({ queryKey: ['wallets'] });

      toast({
        title: 'Wallet Imported',
        description: `Successfully imported ${data.data.walletCount} wallet addresses`,
      });

      // Close dialog after short delay
      setTimeout(() => {
        handleClose();
      }, 2000);
    } catch (err: any) {
      toast({
        title: 'Import Failed',
        description: err.message || 'Failed to import wallet',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    setIsOpen(false);
    setMnemonic('');
    setShowPhrase(false);
    setImportSuccess(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => {
      if (!open) handleClose();
      else setIsOpen(true);
    }}>
      <DialogTrigger asChild>
        <Button variant="outline" className="w-full gap-2">
          <Download className="w-4 h-4" />
          Import Existing Wallet
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Download className="w-5 h-5 text-primary" />
            Import Wallet
          </DialogTitle>
          <DialogDescription>
            Enter your 12 or 24-word recovery phrase to restore your wallet.
          </DialogDescription>
        </DialogHeader>

        {importSuccess ? (
          <div className="py-8 text-center space-y-4">
            <div className="w-16 h-16 mx-auto rounded-full bg-green-500/20 flex items-center justify-center">
              <Check className="w-8 h-8 text-green-500" />
            </div>
            <p className="text-lg font-medium">Wallet Imported Successfully!</p>
            <p className="text-sm text-muted-foreground">
              Your wallet addresses have been restored.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-destructive/10 border border-destructive/20">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-destructive mt-0.5" />
                <div className="space-y-1 text-sm">
                  <p className="font-medium text-destructive">Security Warning</p>
                  <p className="text-muted-foreground">
                    Only import on trusted devices. Never share your phrase with anyone.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">Recovery Phrase</label>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowPhrase(!showPhrase)}
                  className="h-8 px-2"
                >
                  {showPhrase ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </Button>
              </div>
              <Textarea
                placeholder="Enter your 12 or 24 word recovery phrase, separated by spaces..."
                value={mnemonic}
                onChange={(e) => setMnemonic(e.target.value)}
                className={`min-h-[120px] font-mono text-sm ${!showPhrase ? 'text-security' : ''}`}
                style={!showPhrase ? { 
                  WebkitTextSecurity: 'disc',
                  textSecurity: 'disc'
                } as any : undefined}
              />
              <p className="text-xs text-muted-foreground">
                Words: {mnemonic.trim() ? mnemonic.trim().split(/\s+/).length : 0}
              </p>
            </div>

            <Button
              onClick={handleImport}
              disabled={isLoading || !mnemonic.trim()}
              className="w-full"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Importing...
                </>
              ) : (
                'Import Wallet'
              )}
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
