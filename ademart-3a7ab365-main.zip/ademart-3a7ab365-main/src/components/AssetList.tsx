import { useState } from "react";
import { useCryptoPrices } from "@/hooks/useCryptoData";
import { TrendingUp, TrendingDown } from "lucide-react";

interface Asset {
  id: string;
  name: string;
  symbol: string;
  balance: number;
  valueUSD: number;
  flag?: string;
  change24h?: number;
}

interface AssetListProps {
  assets: Asset[];
}

// Map symbols to CoinGecko IDs
const symbolToId: Record<string, string> = {
  BTC: 'bitcoin',
  ETH: 'ethereum',
  LTC: 'litecoin',
  USDT: 'tether',
  BNB: 'binancecoin',
  SOL: 'solana',
  XRP: 'ripple',
  DOGE: 'dogecoin',
};

export const AssetList = ({ assets }: AssetListProps) => {
  const [activeTab, setActiveTab] = useState<'balance' | 'market'>('balance');
  
  const cryptoAssets = assets.filter(a => symbolToId[a.symbol]);
  const coinIds = cryptoAssets.map(a => symbolToId[a.symbol]);
  
  const { data: prices } = useCryptoPrices(coinIds, 'usd');

  const formatCurrency = (value: number, symbol: string) => {
    const prefix = symbol === 'NGN' ? '₦' : symbol === 'USD' ? '$' : '';
    return `${prefix}${value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const getFlag = (symbol: string) => {
    switch (symbol) {
      case 'USD': return '🇺🇸';
      case 'NGN': return '🇳🇬';
      case 'BTC': return '₿';
      case 'ETH': return 'Ξ';
      case 'USDT': return '₮';
      case 'LTC': return 'Ł';
      case 'BNB': return '⬡';
      case 'SOL': return '◎';
      default: return '💰';
    }
  };

  const getPrice = (symbol: string): number | null => {
    const id = symbolToId[symbol];
    if (id && prices?.[id]) {
      return prices[id]['usd'] ?? null;
    }
    return null;
  };

  const getChange = (symbol: string): number | null => {
    const id = symbolToId[symbol];
    if (id && prices?.[id]) {
      return prices[id]['usd_24h_change'] ?? null;
    }
    return null;
  };

  return (
    <div className="space-y-4 animate-fade-in" style={{ animationDelay: '0.3s' }}>
      <div className="flex bg-secondary/50 p-1 rounded-xl">
        <button
          onClick={() => setActiveTab('balance')}
          className={`flex-1 py-2.5 px-4 rounded-lg text-sm font-medium transition-all ${
            activeTab === 'balance'
              ? 'bg-card text-foreground shadow-sm'
              : 'text-muted-foreground hover:text-foreground'
          }`}
        >
          Wallet balance
        </button>
        <button
          onClick={() => setActiveTab('market')}
          className={`flex-1 py-2.5 px-4 rounded-lg text-sm font-medium transition-all ${
            activeTab === 'market'
              ? 'bg-card text-foreground shadow-sm'
              : 'text-muted-foreground hover:text-foreground'
          }`}
        >
          Market price
        </button>
      </div>

      <div className="space-y-2">
        {assets.map((asset) => {
          const price = getPrice(asset.symbol);
          const change = getChange(asset.symbol);
          const valueUSD = price ? asset.balance * price : asset.valueUSD;

          return (
            <div
              key={asset.id}
              className="flex items-center justify-between p-4 rounded-xl bg-secondary/30 hover:bg-secondary/50 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-xl">
                  {getFlag(asset.symbol)}
                </div>
                <div>
                  <p className="font-medium">{asset.symbol}</p>
                  <p className="text-sm text-muted-foreground">{asset.name}</p>
                </div>
              </div>
              <div className="text-right">
                {activeTab === 'balance' ? (
                  <>
                    <p className="font-semibold">
                      {asset.balance.toLocaleString('en-US', { maximumFractionDigits: 8 })} {asset.symbol}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      ${valueUSD.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </p>
                  </>
                ) : (
                  <>
                    <p className="font-semibold">
                      {price ? `$${price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : formatCurrency(asset.valueUSD / asset.balance || 0, 'USD')}
                    </p>
                    {change !== null && (
                      <p className={`text-sm flex items-center justify-end gap-1 ${change >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                        {change >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                        {Math.abs(change).toFixed(2)}%
                      </p>
                    )}
                  </>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
