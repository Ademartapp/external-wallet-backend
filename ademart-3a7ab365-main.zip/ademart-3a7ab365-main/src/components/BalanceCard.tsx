import { ChevronDown, Eye, EyeOff } from "lucide-react";
import { useState } from "react";

interface BalanceCardProps {
  balance: number;
  currency: string;
  cryptoTag?: string | null;
  onCurrencyChange?: () => void;
}

export const BalanceCard = ({ balance, currency, cryptoTag, onCurrencyChange }: BalanceCardProps) => {
  const [showBalance, setShowBalance] = useState(true);

  const formatBalance = (amount: number) => {
    if (!showBalance) return "••••••";
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(amount);
  };

  const getCurrencySymbol = (curr: string) => {
    switch (curr) {
      case 'NGN': return '₦';
      case 'USD': return '$';
      default: return '$';
    }
  };

  return (
    <div className="glass-card p-6 glow-accent animate-fade-in">
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={onCurrencyChange}
          className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-secondary/60 hover:bg-secondary transition-colors"
        >
          <span className="text-sm font-medium">{currency}</span>
          <ChevronDown className="w-4 h-4 text-muted-foreground" />
        </button>
        <button
          onClick={() => setShowBalance(!showBalance)}
          className="p-2 rounded-full hover:bg-secondary/60 transition-colors"
        >
          {showBalance ? (
            <Eye className="w-5 h-5 text-muted-foreground" />
          ) : (
            <EyeOff className="w-5 h-5 text-muted-foreground" />
          )}
        </button>
      </div>

      <div className="space-y-1">
        <p className="balance-text">
          <span className="text-muted-foreground">{getCurrencySymbol(currency)}</span>
          {formatBalance(balance)}
        </p>
        <p className="text-muted-foreground text-sm">Total balance</p>
      </div>

      <div className="flex items-center justify-between mt-4 pt-4 border-t border-border/30">
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">Crypto Tag</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-primary font-medium">
            {cryptoTag ? `@${cryptoTag}` : 'Not set'}
          </span>
        </div>
      </div>
    </div>
  );
};
