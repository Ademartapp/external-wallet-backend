import { useState } from 'react';
import { Shield, Eye, EyeOff, Copy, AlertTriangle, Check, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

export function WalletBackup() {
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [showWarning, setShowWarning] = useState(true);
  const [words, setWords] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [revealed, setRevealed] = useState(false);
  const [copied, setCopied] = useState(false);

  const fetchRecoveryPhrase = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('hd-wallet', {
        body: { action: 'get_recovery_phrase' },
      });

      if (error) throw new Error(error.message);
      if (!data?.success) throw new Error(data?.error || 'Failed to get recovery phrase');

      setWords(data.data.words);
      setShowWarning(false);
    } catch (err: any) {
      toast({
        title: 'Error',
        description: err.message || 'Failed to get recovery phrase',
        variant: 'destructive',
      });
      setIsOpen(false);
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(words.join(' '));
    setCopied(true);
    toast({ title: 'Copied', description: 'Recovery phrase copied to clipboard' });
    setTimeout(() => setCopied(false), 2000);
  };

  const handleClose = () => {
    setIsOpen(false);
    setWords([]);
    setShowWarning(true);
    setRevealed(false);
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={(open) => {
        if (!open) handleClose();
        else setIsOpen(true);
      }}>
        <DialogTrigger asChild>
          <Button variant="outline" className="w-full gap-2">
            <Shield className="w-4 h-4" />
            Backup Recovery Phrase
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-primary" />
              Recovery Phrase Backup
            </DialogTitle>
            <DialogDescription>
              Your 24-word recovery phrase is the only way to restore your wallets.
            </DialogDescription>
          </DialogHeader>

          {showWarning ? (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-destructive/10 border border-destructive/20">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-destructive mt-0.5" />
                  <div className="space-y-2 text-sm">
                    <p className="font-medium text-destructive">Security Warning</p>
                    <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                      <li>Never share your recovery phrase with anyone</li>
                      <li>Never enter it on any website</li>
                      <li>Write it down and store it safely offline</li>
                      <li>Anyone with this phrase can access your funds</li>
                    </ul>
                  </div>
                </div>
              </div>

              <Button
                onClick={fetchRecoveryPhrase}
                disabled={isLoading}
                className="w-full"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Loading...
                  </>
                ) : (
                  'I Understand, Show Phrase'
                )}
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="relative">
                <div className={`grid grid-cols-3 gap-2 p-4 rounded-xl bg-secondary/50 ${!revealed ? 'blur-md select-none' : ''}`}>
                  {words.map((word, index) => (
                    <div
                      key={index}
                      className="flex items-center gap-2 p-2 rounded-lg bg-background/50"
                    >
                      <span className="text-xs text-muted-foreground w-5">{index + 1}.</span>
                      <span className="text-sm font-mono">{word}</span>
                    </div>
                  ))}
                </div>

                {!revealed && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Button
                      variant="secondary"
                      onClick={() => setRevealed(true)}
                      className="gap-2"
                    >
                      <Eye className="w-4 h-4" />
                      Reveal Phrase
                    </Button>
                  </div>
                )}
              </div>

              {revealed && (
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => setRevealed(false)}
                    className="flex-1 gap-2"
                  >
                    <EyeOff className="w-4 h-4" />
                    Hide
                  </Button>
                  <Button
                    variant="outline"
                    onClick={copyToClipboard}
                    className="flex-1 gap-2"
                  >
                    {copied ? (
                      <>
                        <Check className="w-4 h-4" />
                        Copied
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                        Copy
                      </>
                    )}
                  </Button>
                </div>
              )}

              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20">
                <p className="text-xs text-amber-600 dark:text-amber-400 text-center">
                  Write these words down in order and store them safely offline.
                </p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
