import { Bell, TrendingUp, TrendingDown } from 'lucide-react';
import { usePriceAlerts } from '@/hooks/usePriceAlerts';
import { formatDistanceToNow } from 'date-fns';

export function AlertHistory() {
  const { alerts, isLoading } = usePriceAlerts();

  // Get triggered alerts only
  const triggeredAlerts = alerts.filter(alert => alert.triggered_at);

  if (isLoading) {
    return (
      <div className="glass-card p-4">
        <div className="flex items-center gap-2 mb-3">
          <Bell className="w-4 h-4 text-primary" />
          <h3 className="font-medium text-sm">Alert History</h3>
        </div>
        <div className="animate-pulse space-y-2">
          <div className="h-12 bg-secondary/50 rounded-lg" />
          <div className="h-12 bg-secondary/50 rounded-lg" />
        </div>
      </div>
    );
  }

  if (triggeredAlerts.length === 0) {
    return null; // Don't show if no triggered alerts
  }

  return (
    <div className="glass-card p-4">
      <div className="flex items-center gap-2 mb-3">
        <Bell className="w-4 h-4 text-primary" />
        <h3 className="font-medium text-sm">Recent Alerts</h3>
      </div>

      <div className="space-y-2 max-h-48 overflow-y-auto">
        {triggeredAlerts.slice(0, 5).map((alert) => (
          <div
            key={alert.id}
            className="flex items-center justify-between p-3 rounded-lg bg-secondary/30"
          >
            <div className="flex items-center gap-3">
              <div className={`p-1.5 rounded-full ${
                alert.condition === 'above' 
                  ? 'bg-green-500/20 text-green-500' 
                  : 'bg-red-500/20 text-red-500'
              }`}>
                {alert.condition === 'above' ? (
                  <TrendingUp className="w-3 h-3" />
                ) : (
                  <TrendingDown className="w-3 h-3" />
                )}
              </div>
              <div>
                <p className="text-sm font-medium">
                  {alert.symbol} {alert.condition === 'above' ? '↑' : '↓'} ${alert.target_price.toLocaleString()}
                </p>
                <p className="text-xs text-muted-foreground">
                  {alert.triggered_at && formatDistanceToNow(new Date(alert.triggered_at), { addSuffix: true })}
                </p>
              </div>
            </div>
            <span className="text-xs px-2 py-1 rounded-full bg-green-500/20 text-green-500">
              Triggered
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
