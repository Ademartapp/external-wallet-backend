import { format } from 'date-fns';
import { ArrowUpRight, ArrowDownLeft, RefreshCw, Copy, ExternalLink, CheckCircle, Clock, XCircle } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface Transaction {
  id: string;
  amount: number;
  from_currency: string;
  to_currency?: string | null;
  status: string;
  tx_hash: string | null;
  created_at: string;
  fee: number | null;
  type: string;
  recipient_address?: string | null;
}

interface TransactionDetailsModalProps {
  transaction: Transaction | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const statusConfig = {
  pending: { icon: Clock, color: 'text-yellow-500', bg: 'bg-yellow-500/20' },
  completed: { icon: CheckCircle, color: 'text-green-500', bg: 'bg-green-500/20' },
  failed: { icon: XCircle, color: 'text-red-500', bg: 'bg-red-500/20' },
};

const typeConfig = {
  deposit: { icon: ArrowDownLeft, color: 'text-green-500', bg: 'bg-green-500/20', label: 'Deposit' },
  send: { icon: ArrowUpRight, color: 'text-orange-500', bg: 'bg-orange-500/20', label: 'Withdrawal' },
  swap: { icon: RefreshCw, color: 'text-blue-500', bg: 'bg-blue-500/20', label: 'Swap' },
  receive: { icon: ArrowDownLeft, color: 'text-green-500', bg: 'bg-green-500/20', label: 'Received' },
};

export function TransactionDetailsModal({ transaction, open, onOpenChange }: TransactionDetailsModalProps) {
  const { toast } = useToast();

  if (!transaction) return null;

  const status = statusConfig[transaction.status as keyof typeof statusConfig] || statusConfig.pending;
  const type = typeConfig[transaction.type as keyof typeof typeConfig] || typeConfig.deposit;
  const StatusIcon = status.icon;
  const TypeIcon = type.icon;

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: 'Copied', description: `${label} copied to clipboard` });
  };

  const getExplorerUrl = (txHash: string, currency: string) => {
    const explorers: Record<string, string> = {
      BTC: `https://mempool.space/tx/${txHash}`,
      ETH: `https://etherscan.io/tx/${txHash}`,
      USDT: `https://etherscan.io/tx/${txHash}`,
      TRX: `https://tronscan.org/#/transaction/${txHash}`,
      SOL: `https://solscan.io/tx/${txHash}`,
      LTC: `https://blockchair.com/litecoin/transaction/${txHash}`,
    };
    return explorers[currency] || null;
  };

  const explorerUrl = transaction.tx_hash ? getExplorerUrl(transaction.tx_hash, transaction.from_currency) : null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <div className={`p-2 rounded-full ${type.bg}`}>
              <TypeIcon className={`w-5 h-5 ${type.color}`} />
            </div>
            {type.label} Details
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Amount */}
          <div className="text-center py-4">
            <p className={`text-3xl font-bold ${transaction.type === 'send' ? 'text-orange-500' : 'text-green-500'}`}>
              {transaction.type === 'send' ? '-' : '+'}
              {transaction.amount} {transaction.from_currency}
            </p>
            {transaction.to_currency && (
              <p className="text-muted-foreground text-sm mt-1">
                Swapped to {transaction.to_currency}
              </p>
            )}
          </div>

          {/* Status */}
          <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/30">
            <span className="text-muted-foreground">Status</span>
            <span className={`flex items-center gap-1.5 px-2 py-1 rounded-full text-sm font-medium ${status.bg} ${status.color}`}>
              <StatusIcon className="w-4 h-4" />
              {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
            </span>
          </div>

          {/* Details Grid */}
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/30">
              <span className="text-muted-foreground">Date</span>
              <span className="font-medium">
                {format(new Date(transaction.created_at), 'MMM dd, yyyy HH:mm')}
              </span>
            </div>

            {transaction.fee !== null && transaction.fee > 0 && (
              <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/30">
                <span className="text-muted-foreground">Fee</span>
                <span className="font-medium">
                  {transaction.fee} {transaction.from_currency}
                </span>
              </div>
            )}

            {transaction.recipient_address && (
              <div className="p-3 rounded-lg bg-secondary/30">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-muted-foreground">To Address</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6"
                    onClick={() => copyToClipboard(transaction.recipient_address!, 'Address')}
                  >
                    <Copy className="w-3 h-3" />
                  </Button>
                </div>
                <p className="font-mono text-xs break-all">{transaction.recipient_address}</p>
              </div>
            )}

            {transaction.tx_hash && (
              <div className="p-3 rounded-lg bg-secondary/30">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-muted-foreground">Transaction Hash</span>
                  <div className="flex items-center gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      onClick={() => copyToClipboard(transaction.tx_hash!, 'TX Hash')}
                    >
                      <Copy className="w-3 h-3" />
                    </Button>
                    {explorerUrl && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        asChild
                      >
                        <a href={explorerUrl} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </Button>
                    )}
                  </div>
                </div>
                <p className="font-mono text-xs break-all">{transaction.tx_hash}</p>
              </div>
            )}

            <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/30">
              <span className="text-muted-foreground">Transaction ID</span>
              <Button
                variant="ghost"
                size="sm"
                className="h-6 px-2 text-xs font-mono"
                onClick={() => copyToClipboard(transaction.id, 'Transaction ID')}
              >
                {transaction.id.slice(0, 8)}...
                <Copy className="w-3 h-3 ml-1" />
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}