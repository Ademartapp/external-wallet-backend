import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Globe, AlertTriangle, ArrowRight, Percent, Gift } from "lucide-react";
import { FeeEstimate } from "@/hooks/useUnifiedBalances";

interface SendConfirmationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: () => void;
  recipient: string;
  amount: string;
  symbol: string;
  chain: string;
  sendMethod: 'onchain';
  feeEstimate?: FeeEstimate | null;
  isLoading?: boolean;
  appFee?: number;
  recipientAmount?: number;
}

const APP_FEE_PERCENTAGE = 2; // 2%

export function SendConfirmationDialog({
  open,
  onOpenChange,
  onConfirm,
  recipient,
  amount,
  symbol,
  chain,
  feeEstimate,
  isLoading,
  appFee,
  recipientAmount,
}: SendConfirmationDialogProps) {
  const truncatedAddress = recipient.length > 20 
    ? `${recipient.slice(0, 12)}...${recipient.slice(-8)}`
    : recipient;

  const numAmount = parseFloat(amount) || 0;
  const calculatedAppFee = appFee ?? numAmount * 0.02;
  const calculatedRecipientAmount = recipientAmount ?? numAmount - calculatedAppFee;

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="max-w-md">
        <AlertDialogHeader>
          <AlertDialogTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-yellow-500" />
            Confirm Transaction
          </AlertDialogTitle>
          <AlertDialogDescription className="space-y-4 text-left">
            <p>Please review the transaction details carefully. This action cannot be undone.</p>
            
            <div className="bg-secondary/50 rounded-lg p-4 space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground text-sm">Sending</span>
                <span className="font-semibold text-foreground text-lg">
                  {amount} {symbol}
                </span>
              </div>
              
              <div className="flex items-center justify-center py-2">
                <ArrowRight className="w-5 h-5 text-muted-foreground" />
              </div>
              
              <div className="flex justify-between items-start">
                <span className="text-muted-foreground text-sm">To</span>
                <span className="font-mono text-sm text-foreground break-all max-w-[60%] text-right">
                  {truncatedAddress}
                </span>
              </div>
              
              <div className="border-t border-border/50 pt-3 space-y-2">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground">Method</span>
                  <span className="flex items-center gap-1 text-foreground">
                    <Globe className="w-3 h-3" /> On-Chain
                  </span>
                </div>
                
                <div className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground">Network</span>
                  <span className="text-foreground">{chain}</span>
                </div>
                
                {/* App Fee (2%) */}
                <div className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground flex items-center gap-1">
                    <Percent className="w-3 h-3" />
                    App Fee ({APP_FEE_PERCENTAGE}%)
                  </span>
                  <span className="text-amber-500 font-medium">
                    {calculatedAppFee.toFixed(8)} {symbol}
                  </span>
                </div>
                
                {/* Recipient Gets */}
                <div className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground flex items-center gap-1">
                    <Gift className="w-3 h-3" />
                    Recipient Gets
                  </span>
                  <span className="text-green-500 font-medium">
                    {calculatedRecipientAmount.toFixed(8)} {symbol}
                  </span>
                </div>
                
                {/* Network Fee */}
                <div className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground">Network Fee</span>
                  <span className="text-foreground">
                    {feeEstimate 
                      ? `~${feeEstimate.fee} ${feeEstimate.feeSymbol}`
                      : 'Calculating...'}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-3">
              <p className="text-sm text-blue-600 dark:text-blue-400">
                💡 A {APP_FEE_PERCENTAGE}% app fee is deducted from your send amount. The recipient receives the remaining amount.
              </p>
            </div>
            
            <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-3">
              <p className="text-sm text-yellow-600 dark:text-yellow-400">
                ⚠️ Double-check the recipient address. Transactions to wrong addresses cannot be reversed.
              </p>
            </div>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="gap-2 sm:gap-0">
          <AlertDialogCancel disabled={isLoading}>Cancel</AlertDialogCancel>
          <AlertDialogAction
            onClick={(e) => {
              e.preventDefault();
              onConfirm();
            }}
            disabled={isLoading}
            className="bg-primary hover:bg-primary/90"
          >
            {isLoading ? 'Processing...' : 'Confirm & Send'}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}