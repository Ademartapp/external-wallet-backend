import { QRCodeSVG } from 'qrcode.react';
import { Copy, Check, Download } from 'lucide-react';
import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface QRCodeDisplayProps {
  value: string;
  symbol: string;
  size?: number;
  showCopyButton?: boolean;
  showDownloadButton?: boolean;
}

export function QRCodeDisplay({ 
  value, 
  symbol, 
  size = 200,
  showCopyButton = true,
  showDownloadButton = true,
}: QRCodeDisplayProps) {
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();
  const qrRef = useRef<HTMLDivElement>(null);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      toast({
        title: 'Address Copied',
        description: 'Wallet address copied to clipboard',
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast({
        title: 'Copy Failed',
        description: 'Could not copy to clipboard',
        variant: 'destructive',
      });
    }
  };

  const handleDownload = () => {
    const svg = qrRef.current?.querySelector('svg');
    if (!svg) return;

    const svgData = new XMLSerializer().serializeToString(svg);
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();

    img.onload = () => {
      canvas.width = size;
      canvas.height = size;
      ctx?.drawImage(img, 0, 0);
      
      const pngFile = canvas.toDataURL('image/png');
      const downloadLink = document.createElement('a');
      downloadLink.download = `${symbol}-wallet-qr.png`;
      downloadLink.href = pngFile;
      downloadLink.click();

      toast({
        title: 'QR Code Downloaded',
        description: `${symbol} wallet QR code saved`,
      });
    };

    img.src = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgData)));
  };

  return (
    <div className="flex flex-col items-center space-y-4">
      <div 
        ref={qrRef}
        className="bg-white p-4 rounded-2xl shadow-lg"
      >
        <QRCodeSVG
          value={value}
          size={size}
          level="H"
          includeMargin={false}
          bgColor="#ffffff"
          fgColor="#000000"
        />
      </div>

      <div className="w-full max-w-xs space-y-2">
        <p className="text-xs text-muted-foreground text-center">Wallet Address</p>
        <div className="flex items-center gap-2 p-3 rounded-xl bg-secondary/50">
          <p className="flex-1 text-sm font-mono truncate">{value}</p>
          {showCopyButton && (
            <button
              onClick={handleCopy}
              className="p-2 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors"
            >
              {copied ? (
                <Check className="w-4 h-4 text-primary" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </button>
          )}
        </div>
      </div>

      <div className="flex gap-2">
        {showCopyButton && (
          <Button 
            variant="secondary" 
            size="sm" 
            onClick={handleCopy}
            className="gap-2"
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            {copied ? 'Copied!' : 'Copy'}
          </Button>
        )}
        {showDownloadButton && (
          <Button 
            variant="secondary" 
            size="sm" 
            onClick={handleDownload}
            className="gap-2"
          >
            <Download className="w-4 h-4" />
            Download QR
          </Button>
        )}
      </div>
    </div>
  );
}
