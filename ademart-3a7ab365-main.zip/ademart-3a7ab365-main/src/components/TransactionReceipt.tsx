import { useRef } from 'react';
import { format } from 'date-fns';
import { Download, Copy, CheckCircle, Clock, XCircle, Printer, Share2, AlertTriangle, RefreshCw } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface TransactionReceiptProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  transaction: {
    id: string;
    type: 'buy' | 'sell' | 'send' | 'receive' | 'swap';
    amount: number;
    currency: string;
    ngnAmount?: number;
    status: string;
    createdAt: string;
    paymentMethod?: string;
    payoutDetails?: string;
    txHash?: string;
    recipientAddress?: string;
    fee?: number;
    errorDetails?: string;
    canRetry?: boolean;
  };
}

export function TransactionReceipt({ open, onOpenChange, transaction }: TransactionReceiptProps) {
  const { toast } = useToast();
  const receiptRef = useRef<HTMLDivElement>(null);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-8 h-8 text-green-500" />;
      case 'pending':
        return <Clock className="w-8 h-8 text-amber-500" />;
      default:
        return <XCircle className="w-8 h-8 text-red-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'text-green-500';
      case 'pending':
        return 'text-amber-500';
      default:
        return 'text-red-500';
    }
  };

  const getTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      buy: 'Buy Order',
      sell: 'Sell Order',
      send: 'Withdrawal',
      receive: 'Deposit',
      swap: 'Swap',
    };
    return labels[type] || type;
  };

  const copyToClipboard = async (text: string) => {
    await navigator.clipboard.writeText(text);
    toast({
      title: 'Copied',
      description: 'Copied to clipboard',
    });
  };

  const handlePrint = () => {
    const printContent = receiptRef.current?.innerHTML;
    if (!printContent) return;

    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Transaction Receipt</title>
          <style>
            body { font-family: system-ui, -apple-system, sans-serif; padding: 40px; max-width: 400px; margin: 0 auto; }
            .receipt { background: #f9fafb; border-radius: 12px; padding: 24px; }
            .header { text-align: center; margin-bottom: 24px; }
            .logo { font-size: 24px; font-weight: bold; color: #6366f1; }
            .row { display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid #e5e7eb; }
            .row:last-child { border-bottom: none; }
            .label { color: #6b7280; }
            .value { font-weight: 500; text-align: right; }
            .amount { font-size: 24px; font-weight: bold; text-align: center; margin: 20px 0; }
            .status { text-align: center; margin: 16px 0; }
            .footer { text-align: center; margin-top: 24px; font-size: 12px; color: #9ca3af; }
          </style>
        </head>
        <body>
          ${printContent}
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

  const handleShare = async () => {
    const receiptText = `
Transaction Receipt
-------------------
Type: ${getTypeLabel(transaction.type)}
Amount: ${transaction.amount} ${transaction.currency}
${transaction.ngnAmount ? `NGN Amount: ₦${transaction.ngnAmount.toLocaleString()}` : ''}
Status: ${transaction.status.toUpperCase()}
Date: ${format(new Date(transaction.createdAt), 'PPpp')}
Transaction ID: ${transaction.id}
    `.trim();

    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Transaction Receipt',
          text: receiptText,
        });
      } catch (err) {
        if ((err as Error).name !== 'AbortError') {
          copyToClipboard(receiptText);
        }
      }
    } else {
      copyToClipboard(receiptText);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center">Transaction Receipt</DialogTitle>
        </DialogHeader>

        <div ref={receiptRef} className="receipt space-y-6">
          {/* Header */}
          <div className="header text-center">
            <p className="logo text-2xl font-bold text-primary">CryptoWallet</p>
            <p className="text-sm text-muted-foreground mt-1">
              {format(new Date(transaction.createdAt), 'PPpp')}
            </p>
          </div>

          {/* Status */}
          <div className="status flex flex-col items-center gap-2">
            {getStatusIcon(transaction.status)}
            <span className={`text-lg font-semibold capitalize ${getStatusColor(transaction.status)}`}>
              {transaction.status}
            </span>
          </div>

          {/* Amount */}
          <div className="amount text-center py-4 bg-secondary/30 rounded-xl">
            <p className="text-3xl font-bold">
              {transaction.type === 'buy' || transaction.type === 'receive' ? '+' : '-'}
              {transaction.amount.toFixed(8)} {transaction.currency}
            </p>
            {transaction.ngnAmount && (
              <p className="text-lg text-muted-foreground mt-1">
                ₦{transaction.ngnAmount.toLocaleString()}
              </p>
            )}
          </div>

          {/* Details */}
          <div className="space-y-0 divide-y divide-border/50">
            <div className="row flex justify-between py-3">
              <span className="label text-muted-foreground">Type</span>
              <span className="value font-medium">{getTypeLabel(transaction.type)}</span>
            </div>

            {transaction.paymentMethod && (
              <div className="row flex justify-between py-3">
                <span className="label text-muted-foreground">Payment Method</span>
                <span className="value font-medium capitalize">
                  {transaction.paymentMethod.replace('_', ' ')}
                </span>
              </div>
            )}

            {transaction.payoutDetails && (
              <div className="row flex justify-between py-3">
                <span className="label text-muted-foreground">Payout To</span>
                <span className="value font-medium text-right max-w-[200px] truncate">
                  {transaction.payoutDetails}
                </span>
              </div>
            )}

            {transaction.recipientAddress && (
              <div className="row py-3">
                <span className="label text-muted-foreground block mb-1">Recipient</span>
                <span className="value font-mono text-xs break-all">
                  {transaction.recipientAddress}
                </span>
              </div>
            )}

            {transaction.txHash && (
              <div className="row py-3">
                <span className="label text-muted-foreground block mb-1">TX Hash</span>
                <span className="value font-mono text-xs break-all">
                  {transaction.txHash}
                </span>
              </div>
            )}

            {transaction.fee && transaction.fee > 0 && (
              <div className="row flex justify-between py-3">
                <span className="label text-muted-foreground">Network Fee</span>
                <span className="value font-medium">
                  {transaction.fee} {transaction.currency}
                </span>
              </div>
            )}

            {transaction.errorDetails && (
              <div className="row py-3">
                <span className="label text-muted-foreground flex items-center gap-1 mb-1">
                  <AlertTriangle className="w-3 h-3 text-destructive" />
                  Error Details
                </span>
                <p className="text-sm text-destructive break-words">{transaction.errorDetails}</p>
                {transaction.canRetry && (
                  <p className="text-xs text-muted-foreground mt-2 flex items-center gap-1">
                    <RefreshCw className="w-3 h-3" />
                    This transaction can be retried from the Diagnostics page
                  </p>
                )}
              </div>
            )}
            <div className="row flex justify-between py-3">
              <span className="label text-muted-foreground">Transaction ID</span>
              <button 
                onClick={() => copyToClipboard(transaction.id)}
                className="value font-mono text-xs flex items-center gap-1 hover:text-primary"
              >
                {transaction.id.slice(0, 8)}...
                <Copy className="w-3 h-3" />
              </button>
            </div>
          </div>

          {/* Footer */}
          <div className="footer text-center text-xs text-muted-foreground pt-4 border-t border-border/50">
            <p>Thank you for using CryptoWallet</p>
            <p className="mt-1">This is an electronic receipt</p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-2 pt-4">
          <Button variant="outline" className="flex-1" onClick={handlePrint}>
            <Printer className="w-4 h-4 mr-2" />
            Print
          </Button>
          <Button variant="outline" className="flex-1" onClick={handleShare}>
            <Share2 className="w-4 h-4 mr-2" />
            Share
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
