import { useNavigate } from "react-router-dom";

interface CryptoAssetCardProps {
  name: string;
  symbol: string;
  color: string;
  icon?: string;
}

export const CryptoAssetCard = ({ name, symbol, color }: CryptoAssetCardProps) => {
  const navigate = useNavigate();
  
  const gradients: Record<string, string> = {
    green: 'from-emerald-600 to-emerald-800',
    orange: 'from-orange-500 to-orange-700',
    blue: 'from-blue-500 to-blue-700',
    purple: 'from-purple-500 to-purple-700',
    yellow: 'from-yellow-500 to-yellow-700',
  };

  const handleClick = () => {
    navigate(`/receive?asset=${symbol}`);
  };

  return (
    <button
      onClick={handleClick}
      className={`crypto-card bg-gradient-to-br ${gradients[color] || gradients.green} min-h-[100px] cursor-pointer hover:scale-105 transition-transform active:scale-95`}
    >
      <div className="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full -translate-y-8 translate-x-8" />
      <div className="relative z-10 text-left">
        <h3 className="font-semibold text-white">{name}</h3>
        <p className="text-white/70 text-sm">{symbol}</p>
      </div>
    </button>
  );
};
