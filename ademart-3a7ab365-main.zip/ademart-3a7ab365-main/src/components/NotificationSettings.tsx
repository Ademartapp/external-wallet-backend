import { Bell, BellOff, Loader2, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { useWebPushNotifications } from '@/hooks/useWebPushNotifications';
import { useNotificationPreferences } from '@/hooks/useNotificationPreferences';

export function NotificationSettings() {
  const { isSupported, permission, isSubscribed, requestPermission } = useWebPushNotifications();
  const { preferences, isLoading, updatePreferences, isUpdating } = useNotificationPreferences();

  const isEnabled = permission === 'granted';

  return (
    <div className="space-y-4">
      {/* Push Notifications */}
      <div className="p-4 rounded-xl bg-secondary/30 border border-border">
        {!isSupported ? (
          <div className="flex items-center gap-3">
            <BellOff className="w-5 h-5 text-muted-foreground" />
            <div>
              <p className="font-medium">Push Notifications</p>
              <p className="text-sm text-muted-foreground">Not supported in this browser</p>
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-full ${isEnabled ? 'bg-green-500/20' : 'bg-muted'}`}>
                <Bell className={`w-5 h-5 ${isEnabled ? 'text-green-500' : 'text-muted-foreground'}`} />
              </div>
              <div>
                <p className="font-medium">Push Notifications</p>
                <p className="text-sm text-muted-foreground">
                  {isEnabled 
                    ? isSubscribed ? 'Active - Listening for updates' : 'Enabled'
                    : permission === 'denied'
                      ? 'Blocked - Enable in browser settings'
                      : 'Get instant alerts on your device'}
                </p>
              </div>
            </div>
            
            {permission === 'default' ? (
              <Button variant="outline" size="sm" onClick={requestPermission}>
                Enable
              </Button>
            ) : (
              <div className="flex items-center gap-2">
                {isSubscribed && <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />}
                <Switch
                  checked={isEnabled}
                  disabled={permission === 'denied'}
                  onCheckedChange={() => { if (!isEnabled) requestPermission(); }}
                />
              </div>
            )}
          </div>
        )}
      </div>

      {/* Email Notifications */}
      <div className="p-4 rounded-xl bg-secondary/30 border border-border">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 rounded-full bg-primary/20">
            <Mail className="w-5 h-5 text-primary" />
          </div>
          <div>
            <p className="font-medium">Email Notifications</p>
            <p className="text-sm text-muted-foreground">Choose which emails you receive</p>
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-4">
            <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center justify-between py-2">
              <div>
                <p className="text-sm font-medium">Deposits</p>
                <p className="text-xs text-muted-foreground">When you receive funds</p>
              </div>
              <Switch
                checked={preferences.email_deposits}
                disabled={isUpdating}
                onCheckedChange={(checked) => updatePreferences({ email_deposits: checked })}
              />
            </div>

            <div className="flex items-center justify-between py-2">
              <div>
                <p className="text-sm font-medium">Withdrawals</p>
                <p className="text-xs text-muted-foreground">When you send funds</p>
              </div>
              <Switch
                checked={preferences.email_withdrawals}
                disabled={isUpdating}
                onCheckedChange={(checked) => updatePreferences({ email_withdrawals: checked })}
              />
            </div>

            <div className="flex items-center justify-between py-2">
              <div>
                <p className="text-sm font-medium">Transactions</p>
                <p className="text-xs text-muted-foreground">Transaction status updates</p>
              </div>
              <Switch
                checked={preferences.email_transactions}
                disabled={isUpdating}
                onCheckedChange={(checked) => updatePreferences({ email_transactions: checked })}
              />
            </div>

            <div className="flex items-center justify-between py-2">
              <div>
                <p className="text-sm font-medium">Wallet Created</p>
                <p className="text-xs text-muted-foreground">When new wallets are set up</p>
              </div>
              <Switch
                checked={preferences.email_wallet_created}
                disabled={isUpdating}
                onCheckedChange={(checked) => updatePreferences({ email_wallet_created: checked })}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}