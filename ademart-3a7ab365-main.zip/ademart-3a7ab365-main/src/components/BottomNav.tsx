import { Home, LineChart, RefreshCw, Settings, User } from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";

export const BottomNav = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const navItems = [
    { id: 'home', icon: Home, label: 'Home', path: '/' },
    { id: 'markets', icon: LineChart, label: 'Markets', path: '/markets' },
    { id: 'swap', icon: RefreshCw, label: 'Swap', path: '/swap' },
    { id: 'settings', icon: Settings, label: 'Settings', path: '/settings' },
    { id: 'profile', icon: User, label: 'Profile', path: '/profile' },
  ];

  const isActive = (path: string, id: string) => {
    if (id === 'home' && location.pathname === '/') return true;
    if (id === 'markets' && location.pathname === '/markets') return true;
    if (id === 'swap' && location.pathname === '/swap') return true;
    if (id === 'settings' && location.pathname === '/settings') return true;
    if (id === 'profile' && location.pathname === '/profile') return true;
    return false;
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 glass border-t border-border/30 px-4 py-2 safe-area-inset-bottom">
      <div className="max-w-md mx-auto flex items-center justify-around">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => navigate(item.path)}
            className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-all ${
              isActive(item.path, item.id)
                ? 'text-primary'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            {item.id === 'swap' ? (
              <div className={`p-3 rounded-full ${isActive(item.path, item.id) ? 'bg-primary text-primary-foreground' : 'bg-secondary'}`}>
                <item.icon className="w-5 h-5" />
              </div>
            ) : (
              <>
                <item.icon className="w-5 h-5" />
                <span className="text-xs font-medium">{item.label}</span>
              </>
            )}
          </button>
        ))}
      </div>
    </nav>
  );
};
