import { useState } from 'react';
import { Bell, Plus, Trash2, TrendingUp, TrendingDown, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { usePriceAlerts } from '@/hooks/usePriceAlerts';
import { useCryptoMarkets } from '@/hooks/useCryptoData';

const SUPPORTED_CRYPTOS = [
  { symbol: 'BTC', name: 'Bitcoin', id: 'bitcoin' },
  { symbol: 'ETH', name: 'Ethereum', id: 'ethereum' },
  { symbol: 'USDT', name: 'Tether', id: 'tether' },
  { symbol: 'SOL', name: 'Solana', id: 'solana' },
  { symbol: 'BNB', name: 'BNB', id: 'binancecoin' },
  { symbol: 'XRP', name: 'XRP', id: 'ripple' },
];

export function PriceAlerts() {
  const { alerts, isLoading, createAlert, deleteAlert, toggleAlert, isCreating } = usePriceAlerts();
  const { data: marketData } = useCryptoMarkets('usd', 20);
  const [isOpen, setIsOpen] = useState(false);
  const [symbol, setSymbol] = useState('BTC');
  const [targetPrice, setTargetPrice] = useState('');
  const [condition, setCondition] = useState<'above' | 'below'>('above');

  const selectedCrypto = SUPPORTED_CRYPTOS.find(c => c.symbol === symbol);
  const currentPrice = marketData?.find(m => m.id === selectedCrypto?.id)?.current_price || 0;

  const handleCreate = () => {
    if (!targetPrice || parseFloat(targetPrice) <= 0) return;

    createAlert({
      symbol,
      targetPrice: parseFloat(targetPrice),
      condition,
    });

    setTargetPrice('');
    setIsOpen(false);
  };

  const formatPrice = (price: number) => {
    if (price >= 1000) {
      return `$${price.toLocaleString(undefined, { maximumFractionDigits: 2 })}`;
    }
    return `$${price.toFixed(4)}`;
  };

  return (
    <div className="glass-card p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Bell className="w-5 h-5 text-primary" />
          <h3 className="font-semibold">Price Alerts</h3>
        </div>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm">
              <Plus className="w-4 h-4 mr-1" />
              Add Alert
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Price Alert</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label>Cryptocurrency</Label>
                <Select value={symbol} onValueChange={setSymbol}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {SUPPORTED_CRYPTOS.map((crypto) => (
                      <SelectItem key={crypto.symbol} value={crypto.symbol}>
                        {crypto.symbol} - {crypto.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {currentPrice > 0 && (
                  <p className="text-xs text-muted-foreground">
                    Current price: {formatPrice(currentPrice)}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label>Alert Condition</Label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setCondition('above')}
                    className={`p-3 rounded-xl border flex items-center justify-center gap-2 transition-all ${
                      condition === 'above'
                        ? 'border-green-500 bg-green-500/10 text-green-500'
                        : 'border-border/50 bg-secondary/50'
                    }`}
                  >
                    <TrendingUp className="w-4 h-4" />
                    <span>Above</span>
                  </button>
                  <button
                    onClick={() => setCondition('below')}
                    className={`p-3 rounded-xl border flex items-center justify-center gap-2 transition-all ${
                      condition === 'below'
                        ? 'border-red-500 bg-red-500/10 text-red-500'
                        : 'border-border/50 bg-secondary/50'
                    }`}
                  >
                    <TrendingDown className="w-4 h-4" />
                    <span>Below</span>
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Target Price (USD)</Label>
                <Input
                  type="number"
                  placeholder="Enter target price"
                  value={targetPrice}
                  onChange={(e) => setTargetPrice(e.target.value)}
                  className="bg-secondary/50"
                />
              </div>

              <Button
                onClick={handleCreate}
                disabled={isCreating || !targetPrice || parseFloat(targetPrice) <= 0}
                className="w-full"
              >
                {isCreating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Creating...
                  </>
                ) : (
                  'Create Alert'
                )}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin text-primary" />
        </div>
      ) : alerts.length === 0 ? (
        <div className="text-center py-6 text-muted-foreground">
          <Bell className="w-8 h-8 mx-auto mb-2 opacity-50" />
          <p className="text-sm">No price alerts set</p>
          <p className="text-xs">Get notified when prices hit your targets</p>
        </div>
      ) : (
        <div className="space-y-2 max-h-64 overflow-y-auto">
          {alerts.map((alert) => (
            <div
              key={alert.id}
              className={`flex items-center justify-between p-3 rounded-xl transition-all ${
                alert.is_active
                  ? 'bg-secondary/50'
                  : 'bg-secondary/20 opacity-60'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${
                  alert.condition === 'above'
                    ? 'bg-green-500/10 text-green-500'
                    : 'bg-red-500/10 text-red-500'
                }`}>
                  {alert.condition === 'above' ? (
                    <TrendingUp className="w-4 h-4" />
                  ) : (
                    <TrendingDown className="w-4 h-4" />
                  )}
                </div>
                <div>
                  <p className="font-medium text-sm">
                    {alert.symbol} {alert.condition} {formatPrice(alert.target_price)}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {alert.triggered_at ? 'Triggered' : 'Active'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Switch
                  checked={alert.is_active}
                  onCheckedChange={(checked) =>
                    toggleAlert({ alertId: alert.id, isActive: checked })
                  }
                />
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-muted-foreground hover:text-destructive"
                  onClick={() => deleteAlert(alert.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
