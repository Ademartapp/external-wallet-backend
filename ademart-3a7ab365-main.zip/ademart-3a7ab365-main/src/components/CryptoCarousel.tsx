import { CryptoAssetCard } from "./CryptoAssetCard";

const cryptoAssets = [
  { name: 'Ethereum', symbol: 'ETH', color: 'blue' },
  { name: 'Bitcoin', symbol: 'BTC', color: 'orange' },
  { name: 'Tether', symbol: 'USDT', color: 'green' },
  { name: 'Solana', symbol: 'SOL', color: 'purple' },
];

export const CryptoCarousel = () => {
  return (
    <div className="animate-fade-in" style={{ animationDelay: '0.2s' }}>
      <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide -mx-4 px-4">
        {cryptoAssets.map((asset) => (
          <CryptoAssetCard
            key={asset.symbol}
            name={asset.name}
            symbol={asset.symbol}
            color={asset.color}
          />
        ))}
      </div>
    </div>
  );
};
