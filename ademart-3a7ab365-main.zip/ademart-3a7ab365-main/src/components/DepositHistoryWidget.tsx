import { useNavigate } from 'react-router-dom';
import { ArrowDownLeft, ChevronRight, Clock, CheckCircle2, XCircle, Loader2, ExternalLink } from 'lucide-react';
import { useRealtimeTransactions } from '@/hooks/useRealtimeTransactions';
import { formatDistanceToNow } from 'date-fns';

// Chain explorer URLs for transaction hashes
const EXPLORERS: Record<string, string> = {
  TRX: 'https://tronscan.org/#/transaction/',
  ETH: 'https://etherscan.io/tx/',
  BSC: 'https://bscscan.com/tx/',
  BTC: 'https://mempool.space/tx/',
  LTC: 'https://blockchair.com/litecoin/transaction/',
  DOGE: 'https://blockchair.com/dogecoin/transaction/',
  MATIC: 'https://polygonscan.com/tx/',
};

function getExplorerUrl(txHash: string | null, currency: string): string | null {
  if (!txHash || txHash.startsWith('onchain_sync') || txHash.startsWith('auto_sync')) return null;
  
  // Try to detect chain from currency or address patterns
  const chain = currency === 'USDT' || currency === 'USDC' ? 'TRX' : 
                currency === 'ETH' ? 'ETH' : 
                currency === 'BNB' ? 'BSC' :
                currency === 'BTC' ? 'BTC' :
                currency === 'LTC' ? 'LTC' :
                currency === 'DOGE' ? 'DOGE' :
                currency === 'TRX' ? 'TRX' :
                currency === 'MATIC' ? 'MATIC' : null;
                
  if (!chain || !EXPLORERS[chain]) return null;
  return EXPLORERS[chain] + txHash;
}

export function DepositHistoryWidget() {
  const navigate = useNavigate();
  const { transactions, loading } = useRealtimeTransactions();

  // Filter only deposit/receive transactions and take last 5
  const deposits = transactions
    .filter(tx => tx.type === 'deposit' || tx.type === 'receive')
    .slice(0, 5);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-3.5 h-3.5 text-green-500" />;
      case 'pending':
        return <Loader2 className="w-3.5 h-3.5 text-amber-500 animate-spin" />;
      case 'failed':
        return <XCircle className="w-3.5 h-3.5 text-destructive" />;
      default:
        return <Clock className="w-3.5 h-3.5 text-muted-foreground" />;
    }
  };

  if (loading) {
    return (
      <div className="rounded-xl bg-card border border-border p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold flex items-center gap-2">
            <ArrowDownLeft className="w-4 h-4 text-green-500" />
            Recent Deposits
          </h3>
        </div>
        <div className="flex items-center justify-center py-6">
          <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-xl bg-card border border-border p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold flex items-center gap-2">
          <ArrowDownLeft className="w-4 h-4 text-green-500" />
          Recent Deposits
        </h3>
        <button
          onClick={() => navigate('/deposits')}
          className="text-xs text-primary hover:underline flex items-center gap-0.5"
        >
          View All
          <ChevronRight className="w-3 h-3" />
        </button>
      </div>

      {deposits.length === 0 ? (
        <div className="text-center py-6 text-muted-foreground text-sm">
          <p>No deposits yet</p>
          <button
            onClick={() => navigate('/receive')}
            className="text-primary hover:underline mt-1"
          >
            Make your first deposit
          </button>
        </div>
      ) : (
        <div className="space-y-2">
          {deposits.map((tx) => {
            const explorerUrl = getExplorerUrl(tx.tx_hash, tx.from_currency);
            return (
              <div
                key={tx.id}
                className="flex items-center justify-between p-2.5 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center">
                    <ArrowDownLeft className="w-4 h-4 text-green-500" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">
                      +{tx.amount} {tx.from_currency}
                    </p>
                    <div className="flex items-center gap-1.5">
                      <p className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(tx.created_at), { addSuffix: true })}
                      </p>
                      {explorerUrl && (
                        <a
                          href={explorerUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-primary hover:text-primary/80"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  {getStatusIcon(tx.status)}
                  <span className={`text-xs capitalize ${
                    tx.status === 'completed' ? 'text-green-500' :
                    tx.status === 'pending' ? 'text-amber-500' :
                    tx.status === 'failed' ? 'text-destructive' :
                    'text-muted-foreground'
                  }`}>
                    {tx.status}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
