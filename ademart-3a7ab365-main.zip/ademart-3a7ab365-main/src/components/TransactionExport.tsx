import { useState } from 'react';
import { Download, FileText, FileSpreadsheet } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';

interface Transaction {
  id: string;
  type: string;
  amount: number;
  from_currency: string;
  to_currency?: string | null;
  status: string;
  created_at: string;
  tx_hash?: string | null;
  recipient_address?: string | null;
  fee?: number | null;
}

interface TransactionExportProps {
  transactions: Transaction[];
}

export const TransactionExport = ({ transactions }: TransactionExportProps) => {
  const { toast } = useToast();
  const [exporting, setExporting] = useState(false);

  const exportToCSV = () => {
    if (!transactions || transactions.length === 0) {
      toast({
        title: 'No transactions',
        description: 'There are no transactions to export',
        variant: 'destructive',
      });
      return;
    }

    setExporting(true);
    try {
      const headers = ['Date', 'Type', 'Amount', 'Currency', 'To Currency', 'Status', 'Fee', 'TX Hash', 'Recipient'];
      
      const csvRows = [
        headers.join(','),
        ...transactions.map(tx => [
          format(new Date(tx.created_at), 'yyyy-MM-dd HH:mm:ss'),
          tx.type,
          tx.amount,
          tx.from_currency,
          tx.to_currency || '',
          tx.status,
          tx.fee || 0,
          tx.tx_hash || '',
          tx.recipient_address?.includes(':') ? '' : (tx.recipient_address || ''),
        ].map(field => `"${String(field).replace(/"/g, '""')}"`).join(','))
      ];

      const csvContent = csvRows.join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = `transactions_${format(new Date(), 'yyyy-MM-dd')}.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast({
        title: 'Export complete',
        description: `Exported ${transactions.length} transactions to CSV`,
      });
    } catch (error) {
      console.error('CSV export error:', error);
      toast({
        title: 'Export failed',
        description: 'Failed to export transactions',
        variant: 'destructive',
      });
    } finally {
      setExporting(false);
    }
  };

  const exportToPDF = () => {
    if (!transactions || transactions.length === 0) {
      toast({
        title: 'No transactions',
        description: 'There are no transactions to export',
        variant: 'destructive',
      });
      return;
    }

    setExporting(true);
    try {
      // Create a printable HTML document
      const printContent = `
        <!DOCTYPE html>
        <html>
        <head>
          <title>Transaction History</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            h1 { color: #333; margin-bottom: 20px; }
            table { width: 100%; border-collapse: collapse; margin-top: 10px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; font-size: 12px; }
            th { background-color: #f4f4f4; font-weight: bold; }
            tr:nth-child(even) { background-color: #f9f9f9; }
            .header { display: flex; justify-content: space-between; margin-bottom: 20px; }
            .date { color: #666; }
            .completed { color: green; }
            .pending { color: orange; }
            .failed { color: red; }
            .amount-positive { color: green; }
            .amount-negative { color: #333; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>Transaction History</h1>
            <p class="date">Generated: ${format(new Date(), 'PPpp')}</p>
          </div>
          <p>Total Transactions: ${transactions.length}</p>
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Type</th>
                <th>Amount</th>
                <th>Currency</th>
                <th>Status</th>
                <th>Fee</th>
                <th>TX Hash</th>
              </tr>
            </thead>
            <tbody>
              ${transactions.map(tx => `
                <tr>
                  <td>${format(new Date(tx.created_at), 'yyyy-MM-dd HH:mm')}</td>
                  <td>${tx.type.charAt(0).toUpperCase() + tx.type.slice(1)}</td>
                  <td class="${tx.type === 'receive' || tx.type === 'buy' ? 'amount-positive' : 'amount-negative'}">
                    ${tx.type === 'receive' || tx.type === 'buy' ? '+' : '-'}${tx.amount}
                  </td>
                  <td>${tx.from_currency}${tx.to_currency ? ' → ' + tx.to_currency : ''}</td>
                  <td class="${tx.status}">${tx.status}</td>
                  <td>${tx.fee || '-'}</td>
                  <td style="max-width: 120px; overflow: hidden; text-overflow: ellipsis;">
                    ${tx.tx_hash ? tx.tx_hash.slice(0, 12) + '...' : '-'}
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </body>
        </html>
      `;

      // Open print dialog
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(printContent);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
          printWindow.print();
          printWindow.close();
        }, 250);
      }

      toast({
        title: 'Export ready',
        description: 'Print dialog opened for PDF export',
      });
    } catch (error) {
      console.error('PDF export error:', error);
      toast({
        title: 'Export failed',
        description: 'Failed to generate PDF',
        variant: 'destructive',
      });
    } finally {
      setExporting(false);
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" disabled={exporting}>
          <Download className="w-4 h-4 mr-2" />
          Export
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={exportToCSV}>
          <FileSpreadsheet className="w-4 h-4 mr-2" />
          Export to CSV
        </DropdownMenuItem>
        <DropdownMenuItem onClick={exportToPDF}>
          <FileText className="w-4 h-4 mr-2" />
          Export to PDF
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
