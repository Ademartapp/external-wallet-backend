import { Bell, BellOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useWebPushNotifications } from '@/hooks/useWebPushNotifications';
import { useToast } from '@/hooks/use-toast';

export function PushNotificationToggle() {
  const { isSupported, permission, isSubscribed, requestPermission } = useWebPushNotifications();
  const { toast } = useToast();

  const handleToggle = async () => {
    if (permission === 'granted') {
      toast({
        title: 'Already Enabled',
        description: 'Push notifications are active. Disable in browser settings if needed.',
      });
      return;
    }

    const granted = await requestPermission();
    if (granted) {
      toast({
        title: 'Notifications Enabled',
        description: 'You will now receive push notifications for deposits and transactions.',
      });
    }
  };

  if (!isSupported) {
    return (
      <div className="flex items-center justify-between opacity-50">
        <div className="flex items-center gap-3">
          <BellOff className="w-5 h-5 text-muted-foreground" />
          <div>
            <Label>Push Notifications</Label>
            <p className="text-xs text-muted-foreground">Not supported in this browser</p>
          </div>
        </div>
        <Switch disabled checked={false} />
      </div>
    );
  }

  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-3">
        <Bell className={`w-5 h-5 ${permission === 'granted' ? 'text-primary' : 'text-muted-foreground'}`} />
        <div>
          <Label>Push Notifications</Label>
          <p className="text-xs text-muted-foreground">
            {permission === 'granted' 
              ? isSubscribed 
                ? 'Active - receiving notifications' 
                : 'Enabled - waiting for events'
              : permission === 'denied'
              ? 'Blocked - enable in browser settings'
              : 'Click to enable browser notifications'}
          </p>
        </div>
      </div>
      <Switch
        checked={permission === 'granted'}
        onCheckedChange={handleToggle}
        disabled={permission === 'denied'}
      />
    </div>
  );
}