import { useState } from 'react';
import { Play, CheckCircle, XCircle, AlertTriangle, Loader2, Wallet, Database, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { supportedAssets } from '@/hooks/useWallet';

interface ChainTestResult {
  symbol: string;
  chain: string;
  status: 'pending' | 'testing' | 'passed' | 'failed';
  address?: string;
  balance?: string;
  error?: string;
  latency?: number;
}

export function WalletSanityTest() {
  const { toast } = useToast();
  const [isRunning, setIsRunning] = useState(false);
  const [results, setResults] = useState<ChainTestResult[]>([]);
  const [overallStatus, setOverallStatus] = useState<'idle' | 'running' | 'passed' | 'failed'>('idle');

  const runTest = async () => {
    setIsRunning(true);
    setOverallStatus('running');
    
    // Initialize results for all chains
    const initialResults: ChainTestResult[] = supportedAssets
      .filter(a => ['ETH', 'BNB', 'MATIC', 'TRX'].includes(a.symbol)) // Only test EVM/TRON for hd-wallet
      .map(asset => ({
        symbol: asset.symbol,
        chain: asset.chain,
        status: 'pending' as const,
      }));
    
    setResults(initialResults);
    
    let allPassed = true;
    const updatedResults = [...initialResults];
    
    for (let i = 0; i < updatedResults.length; i++) {
      const asset = updatedResults[i];
      updatedResults[i] = { ...asset, status: 'testing' };
      setResults([...updatedResults]);
      
      const startTime = Date.now();
      
      try {
        // Test 1: Create/Get wallet
        const { data: walletData, error: walletError } = await supabase.functions.invoke('unified-wallet', {
          body: { action: 'create_wallet', symbol: asset.symbol, chain: asset.chain },
        });
        
        if (walletError) {
          throw new Error(walletError.message || 'Wallet creation failed');
        }
        
        if (!walletData?.success) {
          throw new Error(walletData?.error || 'Wallet creation returned failure');
        }
        
        // Test 2: Get balance
        const { data: balanceData, error: balanceError } = await supabase.functions.invoke('unified-wallet', {
          body: { action: 'get_balance', symbol: asset.symbol, chain: asset.chain },
        });
        
        if (balanceError) {
          throw new Error(balanceError.message || 'Balance fetch failed');
        }
        
        const latency = Date.now() - startTime;
        
        updatedResults[i] = {
          ...asset,
          status: 'passed',
          address: walletData.address,
          balance: balanceData?.balance || '0',
          latency,
        };
      } catch (err: any) {
        const latency = Date.now() - startTime;
        allPassed = false;
        updatedResults[i] = {
          ...asset,
          status: 'failed',
          error: err.message || 'Unknown error',
          latency,
        };
      }
      
      setResults([...updatedResults]);
      
      // Small delay between tests to avoid rate limiting
      await new Promise(r => setTimeout(r, 500));
    }
    
    setIsRunning(false);
    setOverallStatus(allPassed ? 'passed' : 'failed');
    
    toast({
      title: allPassed ? 'All Tests Passed!' : 'Some Tests Failed',
      description: allPassed 
        ? 'All wallet operations are working correctly.'
        : 'Check the results for details on failed tests.',
      variant: allPassed ? 'default' : 'destructive',
    });
  };

  const getStatusIcon = (status: ChainTestResult['status']) => {
    switch (status) {
      case 'pending':
        return <div className="w-4 h-4 rounded-full bg-muted" />;
      case 'testing':
        return <Loader2 className="w-4 h-4 animate-spin text-primary" />;
      case 'passed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-500" />;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Wallet className="w-5 h-5" />
          Wallet Sanity Test
        </CardTitle>
        <CardDescription>
          Test wallet creation and balance fetching for each supported chain
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Overall Status */}
        {overallStatus !== 'idle' && (
          <div className={`p-4 rounded-lg border ${
            overallStatus === 'running' ? 'border-primary/50 bg-primary/10' :
            overallStatus === 'passed' ? 'border-green-500/50 bg-green-500/10' :
            'border-red-500/50 bg-red-500/10'
          }`}>
            <div className="flex items-center gap-2">
              {overallStatus === 'running' ? (
                <Loader2 className="w-5 h-5 animate-spin text-primary" />
              ) : overallStatus === 'passed' ? (
                <CheckCircle className="w-5 h-5 text-green-500" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-red-500" />
              )}
              <span className="font-medium">
                {overallStatus === 'running' ? 'Running tests...' :
                 overallStatus === 'passed' ? 'All tests passed!' :
                 'Some tests failed'}
              </span>
            </div>
          </div>
        )}

        {/* Results */}
        {results.length > 0 && (
          <div className="space-y-2">
            {results.map((result, index) => (
              <div
                key={`${result.symbol}-${result.chain}`}
                className={`p-3 rounded-lg border ${
                  result.status === 'failed' ? 'border-red-500/30 bg-red-500/5' :
                  result.status === 'passed' ? 'border-green-500/30 bg-green-500/5' :
                  'border-border bg-secondary/30'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(result.status)}
                    <div>
                      <span className="font-medium">{result.symbol}</span>
                      <span className="text-muted-foreground text-sm ml-2">({result.chain})</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {result.latency && (
                      <Badge variant="outline" className="text-xs">
                        {result.latency}ms
                      </Badge>
                    )}
                    <Badge variant={result.status === 'passed' ? 'secondary' : result.status === 'failed' ? 'destructive' : 'outline'}>
                      {result.status}
                    </Badge>
                  </div>
                </div>
                
                {result.status === 'passed' && (
                  <div className="mt-2 text-sm text-muted-foreground">
                    <p>Address: {result.address?.slice(0, 20)}...</p>
                    <p>Balance: {result.balance} {result.symbol}</p>
                  </div>
                )}
                
                {result.status === 'failed' && result.error && (
                  <div className="mt-2 text-sm text-red-500">
                    Error: {result.error}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Run Button */}
        <Button
          onClick={runTest}
          disabled={isRunning}
          className="w-full"
        >
          {isRunning ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Running Tests...
            </>
          ) : (
            <>
              <Play className="w-4 h-4 mr-2" />
              Run Wallet Sanity Test
            </>
          )}
        </Button>
        
        <p className="text-xs text-muted-foreground text-center">
          Tests wallet creation and balance fetching for ETH, BNB, MATIC, and TRX chains.
          UTXO chains (BTC, LTC, DOGE) use CryptoAPIs separately.
        </p>
      </CardContent>
    </Card>
  );
}