import { useEffect, useRef, useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { X, Camera } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface QRScannerProps {
  onScan: (result: string) => void;
  onClose: () => void;
}

export const QRScanner = ({ onScan, onClose }: QRScannerProps) => {
  const [error, setError] = useState<string | null>(null);
  const [isStarting, setIsStarting] = useState(true);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const startScanner = async () => {
      try {
        const scanner = new Html5Qrcode('qr-reader');
        scannerRef.current = scanner;

        await scanner.start(
          { facingMode: 'environment' },
          {
            fps: 10,
            qrbox: { width: 250, height: 250 },
          },
          (decodedText) => {
            onScan(decodedText);
            scanner.stop();
            onClose();
          },
          () => {} // Ignore errors during scanning
        );
        setIsStarting(false);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to start camera');
        setIsStarting(false);
      }
    };

    startScanner();

    return () => {
      if (scannerRef.current?.isScanning) {
        scannerRef.current.stop().catch(console.error);
      }
    };
  }, [onScan, onClose]);

  return (
    <div className="fixed inset-0 z-50 bg-background/95 backdrop-blur-sm">
      <div className="flex flex-col h-full">
        <header className="flex items-center justify-between p-4 border-b border-border/50">
          <h2 className="text-lg font-semibold">Scan QR Code</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </header>

        <div className="flex-1 flex flex-col items-center justify-center p-4">
          {error ? (
            <div className="text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mx-auto">
                <Camera className="w-8 h-8 text-destructive" />
              </div>
              <p className="text-destructive">{error}</p>
              <p className="text-sm text-muted-foreground">
                Please allow camera access to scan QR codes
              </p>
              <Button onClick={onClose} variant="outline">
                Close
              </Button>
            </div>
          ) : (
            <>
              <div 
                ref={containerRef}
                id="qr-reader" 
                className="w-full max-w-sm rounded-xl overflow-hidden"
              />
              {isStarting && (
                <p className="mt-4 text-muted-foreground animate-pulse">
                  Starting camera...
                </p>
              )}
              <p className="mt-4 text-sm text-muted-foreground text-center">
                Point your camera at a wallet QR code
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
