import { useState, useEffect } from 'react';
import { CheckCircle2, Clock, XCircle, ExternalLink, Loader2, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface Transaction {
  id: string;
  type: string;
  amount: number;
  from_currency: string;
  status: string;
  tx_hash: string | null;
  recipient_address: string | null;
  created_at: string;
}

interface TransactionStatusTrackerProps {
  limit?: number;
  showOnlyPending?: boolean;
}

const EXPLORER_URLS: Record<string, string> = {
  BTC: 'https://blockchair.com/bitcoin/transaction/',
  ETH: 'https://etherscan.io/tx/',
  TRX: 'https://tronscan.org/#/transaction/',
  LTC: 'https://blockchair.com/litecoin/transaction/',
  BNB: 'https://bscscan.com/tx/',
  BSC: 'https://bscscan.com/tx/',
  MATIC: 'https://polygonscan.com/tx/',
  DOGE: 'https://blockchair.com/dogecoin/transaction/',
};

export function TransactionStatusTracker({ limit = 5, showOnlyPending = false }: TransactionStatusTrackerProps) {
  const { user } = useAuth();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchTransactions = async () => {
    if (!user) return;
    
    try {
      let query = supabase
        .from('transactions')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(limit);
      
      if (showOnlyPending) {
        query = query.eq('status', 'pending');
      }
      
      const { data, error } = await query;
      
      if (error) throw error;
      setTransactions(data || []);
    } catch (error) {
      console.error('Error fetching transactions:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Subscribe to realtime updates
  useEffect(() => {
    if (!user) return;
    
    fetchTransactions();
    
    const channel = supabase
      .channel('transaction-status-updates')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'transactions',
          filter: `user_id=eq.${user.id}`,
        },
        () => {
          fetchTransactions();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, limit, showOnlyPending]);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchTransactions();
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-4 h-4 text-green-500" />;
      case 'pending':
        return <Clock className="w-4 h-4 text-yellow-500 animate-pulse" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-500" />;
      default:
        return <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge variant="secondary" className="bg-green-500/20 text-green-600 border-green-500/30">Completed</Badge>;
      case 'pending':
        return <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-600 border-yellow-500/30">Pending</Badge>;
      case 'failed':
        return <Badge variant="destructive">Failed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getExplorerUrl = (tx: Transaction) => {
    if (!tx.tx_hash) return null;
    const baseUrl = EXPLORER_URLS[tx.from_currency] || EXPLORER_URLS.ETH;
    return `${baseUrl}${tx.tx_hash}`;
  };

  const formatTime = (date: string) => {
    const d = new Date(date);
    const now = new Date();
    const diffMs = now.getTime() - d.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return d.toLocaleDateString();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-6">
        <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (transactions.length === 0) {
    return (
      <div className="text-center py-6 text-muted-foreground text-sm">
        {showOnlyPending ? 'No pending transactions' : 'No recent transactions'}
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-muted-foreground">
          {showOnlyPending ? 'Pending Transactions' : 'Recent Activity'}
        </h3>
        <Button
          variant="ghost"
          size="sm"
          onClick={handleRefresh}
          disabled={refreshing}
          className="h-7 px-2"
        >
          <RefreshCw className={`w-3 h-3 ${refreshing ? 'animate-spin' : ''}`} />
        </Button>
      </div>
      
      <div className="space-y-2">
        {transactions.map((tx) => (
          <div
            key={tx.id}
            className="flex items-center justify-between p-3 rounded-lg bg-secondary/30 border border-border/30"
          >
            <div className="flex items-center gap-3">
              {getStatusIcon(tx.status)}
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-medium text-sm capitalize">{tx.type}</span>
                  <span className="text-sm text-muted-foreground">
                    {tx.amount} {tx.from_currency}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">
                  {formatTime(tx.created_at)}
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              {getStatusBadge(tx.status)}
              {tx.tx_hash && getExplorerUrl(tx) && (
                <a
                  href={getExplorerUrl(tx)!}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:text-primary/80"
                >
                  <ExternalLink className="w-4 h-4" />
                </a>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}