import { RefreshCw, CheckCircle2, Clock } from 'lucide-react';
import { useAutoSync } from '@/hooks/useAutoSync';
import { formatDistanceToNow } from 'date-fns';

export function TokenBalanceMonitor() {
  const { syncing, lastSync, syncNow } = useAutoSync();

  return (
    <div className="rounded-xl bg-card border border-border p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
            syncing ? 'bg-primary/20' : 'bg-green-500/20'
          }`}>
            {syncing ? (
              <RefreshCw className="w-5 h-5 text-primary animate-spin" />
            ) : (
              <CheckCircle2 className="w-5 h-5 text-green-500" />
            )}
          </div>
          <div>
            <p className="text-sm font-medium">
              {syncing ? 'Syncing balances...' : 'Auto-sync Active'}
            </p>
            <p className="text-xs text-muted-foreground flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {lastSync 
                ? `Last sync ${formatDistanceToNow(new Date(lastSync), { addSuffix: true })}`
                : 'Waiting for first sync...'
              }
            </p>
          </div>
        </div>
        <button
          onClick={syncNow}
          disabled={syncing}
          className="px-3 py-1.5 text-xs font-medium rounded-lg bg-primary/10 text-primary hover:bg-primary/20 transition-colors disabled:opacity-50"
        >
          {syncing ? 'Syncing...' : 'Sync Now'}
        </button>
      </div>
    </div>
  );
}
