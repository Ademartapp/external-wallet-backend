import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";
import { logAppError } from "@/lib/errorLogger";

// If the app was updated while a user still has an older HTML cached,
// React Router lazy-loaded chunks can fail to load. Auto-reload once.
const CHUNK_RELOAD_KEY = "__lovable_chunk_reload__";
function shouldReloadForChunkError(message: string) {
  return (
    message.includes("Failed to fetch dynamically imported module") ||
    message.includes("Importing a module script failed") ||
    message.includes("Loading chunk")
  );
}

function reloadOnce() {
  if (sessionStorage.getItem(CHUNK_RELOAD_KEY) === "1") return;
  sessionStorage.setItem(CHUNK_RELOAD_KEY, "1");
  window.location.reload();
}

window.addEventListener("error", (event) => {
  const errEvent = event as ErrorEvent;
  const msg = errEvent.message || "Unknown error";

  logAppError({
    message: msg,
    stack: errEvent.error?.stack,
    route: window.location.pathname,
    context: "window.error",
    extra: {
      filename: errEvent.filename,
      lineno: errEvent.lineno,
      colno: errEvent.colno,
    },
  });

  if (shouldReloadForChunkError(msg)) reloadOnce();
});

window.addEventListener("unhandledrejection", (event) => {
  const reason = (event as PromiseRejectionEvent).reason;
  const msg = reason instanceof Error ? reason.message : String(reason || "Unknown rejection");

  logAppError({
    message: msg,
    stack: reason instanceof Error ? reason.stack : undefined,
    route: window.location.pathname,
    context: "unhandledrejection",
  });

  if (shouldReloadForChunkError(msg)) reloadOnce();
});

createRoot(document.getElementById("root")!).render(<App />);
