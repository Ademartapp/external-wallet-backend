const COINGECKO_API = 'https://api.coingecko.com/api/v3';

export interface CoinPrice {
  id: string;
  symbol: string;
  name: string;
  current_price: number;
  price_change_percentage_24h: number;
  market_cap: number;
  total_volume: number;
  image: string;
}

export interface CoinPriceSimple {
  [key: string]: {
    [currency: string]: number;
    usd_24h_change?: number;
  };
}

// Cache for prices to reduce API calls
const priceCache: { data: CoinPriceSimple | null; timestamp: number } = {
  data: null,
  timestamp: 0,
};

const CACHE_DURATION = 30000; // 30 seconds

// Retry with exponential backoff
async function fetchWithRetry(url: string, retries = 3, delay = 1000): Promise<Response> {
  let lastError: Error | null = null;
  
  for (let i = 0; i < retries; i++) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout
      
      const response = await fetch(url, { signal: controller.signal });
      clearTimeout(timeoutId);
      
      if (response.ok) {
        return response;
      }
      
      // Rate limited - wait longer
      if (response.status === 429) {
        await new Promise(resolve => setTimeout(resolve, delay * (i + 2)));
        continue;
      }
      
      throw new Error(`HTTP ${response.status}`);
    } catch (error) {
      lastError = error as Error;
      
      // Don't retry on abort (timeout)
      if ((error as Error).name === 'AbortError') {
        throw new Error('Request timeout');
      }
      
      // Wait before retry
      if (i < retries - 1) {
        await new Promise(resolve => setTimeout(resolve, delay * (i + 1)));
      }
    }
  }
  
  throw lastError || new Error('Failed to fetch');
}

export const fetchTopCoins = async (currency = 'usd', limit = 20): Promise<CoinPrice[]> => {
  try {
    const response = await fetchWithRetry(
      `${COINGECKO_API}/coins/markets?vs_currency=${currency}&order=market_cap_desc&per_page=${limit}&page=1&sparkline=false&price_change_percentage=24h`
    );
    return response.json();
  } catch (error) {
    console.error('Error fetching top coins:', error);
    throw error;
  }
};

export const fetchCoinPrices = async (
  coinIds: string[],
  currency = 'usd'
): Promise<CoinPriceSimple> => {
  // Check cache first
  const now = Date.now();
  if (priceCache.data && now - priceCache.timestamp < CACHE_DURATION) {
    return priceCache.data;
  }

  try {
    const response = await fetchWithRetry(
      `${COINGECKO_API}/simple/price?ids=${coinIds.join(',')}&vs_currencies=${currency}&include_24hr_change=true`
    );
    const data = await response.json();
    
    // Update cache
    priceCache.data = data;
    priceCache.timestamp = now;
    
    return data;
  } catch (error) {
    console.error('Error fetching coin prices:', error);
    
    // Return cached data if available, even if stale
    if (priceCache.data) {
      console.log('Using stale cached prices due to fetch error');
      return priceCache.data;
    }
    
    // Return fallback prices if no cache
    return getFallbackPrices(coinIds);
  }
};

// Fallback prices when API fails
function getFallbackPrices(coinIds: string[]): CoinPriceSimple {
  const fallbacks: Record<string, { usd: number; usd_24h_change: number }> = {
    bitcoin: { usd: 87000, usd_24h_change: 0 },
    ethereum: { usd: 2900, usd_24h_change: 0 },
    litecoin: { usd: 77, usd_24h_change: 0 },
    tron: { usd: 0.28, usd_24h_change: 0 },
    binancecoin: { usd: 830, usd_24h_change: 0 },
    'polygon-ecosystem-token': { usd: 0.35, usd_24h_change: 0 },
    dogecoin: { usd: 0.12, usd_24h_change: 0 },
    tether: { usd: 1, usd_24h_change: 0 },
    'usd-coin': { usd: 1, usd_24h_change: 0 },
  };

  const result: CoinPriceSimple = {};
  for (const id of coinIds) {
    if (fallbacks[id]) {
      result[id] = fallbacks[id];
    }
  }
  return result;
}

export const fetchCoinDetails = async (coinId: string) => {
  try {
    const response = await fetchWithRetry(
      `${COINGECKO_API}/coins/${coinId}?localization=false&tickers=false&community_data=false&developer_data=false`
    );
    return response.json();
  } catch (error) {
    console.error('Error fetching coin details:', error);
    throw error;
  }
};