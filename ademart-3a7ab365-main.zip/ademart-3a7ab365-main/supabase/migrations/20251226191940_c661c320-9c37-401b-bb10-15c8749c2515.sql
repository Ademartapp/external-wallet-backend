-- Move pg_net extension from public to extensions schema
-- First drop from public
DROP EXTENSION IF EXISTS pg_net;

-- Create in extensions schema (Supabase's recommended location)
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;