-- Enable realtime for wallet_addresses table
ALTER PUBLICATION supabase_realtime ADD TABLE public.wallet_addresses;