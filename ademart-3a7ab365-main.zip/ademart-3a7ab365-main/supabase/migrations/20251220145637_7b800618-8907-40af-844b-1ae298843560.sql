-- =====================================================
-- IMMUTABILITY POLICIES - Prevent modifications to audit/financial records
-- =====================================================

-- Fee Collections: Make immutable (no UPDATE or DELETE)
CREATE POLICY "No updates to fee collections"
ON public.fee_collections
FOR UPDATE
USING (false);

CREATE POLICY "No deletion of fee collections"
ON public.fee_collections
FOR DELETE
USING (false);

-- Admin Balance Adjustments: Make immutable (no UPDATE or DELETE)
CREATE POLICY "No updates to balance adjustments"
ON public.admin_balance_adjustments
FOR UPDATE
USING (false);

CREATE POLICY "No deletion of balance adjustments"
ON public.admin_balance_adjustments
FOR DELETE
USING (false);

-- =====================================================
-- DELETION PROTECTION - Prevent accidental data loss
-- =====================================================

-- Wallets: Prevent deletion (balance records should be preserved)
CREATE POLICY "No deletion of wallets"
ON public.wallets
FOR DELETE
USING (false);

-- Profiles: Only admins can delete profiles
CREATE POLICY "No deletion of profiles"
ON public.profiles
FOR DELETE
USING (false);

-- =====================================================
-- ADMIN OVERSIGHT POLICIES - Allow admins to manage user data
-- =====================================================

-- Notifications: Admin oversight
CREATE POLICY "Admins can view all notifications"
ON public.notifications
FOR SELECT
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update all notifications"
ON public.notifications
FOR UPDATE
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete notifications"
ON public.notifications
FOR DELETE
USING (public.has_role(auth.uid(), 'admin'));

-- Wallet Addresses: Admin oversight
CREATE POLICY "Admins can insert wallet addresses"
ON public.wallet_addresses
FOR INSERT
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update wallet addresses"
ON public.wallet_addresses
FOR UPDATE
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete wallet addresses"
ON public.wallet_addresses
FOR DELETE
USING (public.has_role(auth.uid(), 'admin'));