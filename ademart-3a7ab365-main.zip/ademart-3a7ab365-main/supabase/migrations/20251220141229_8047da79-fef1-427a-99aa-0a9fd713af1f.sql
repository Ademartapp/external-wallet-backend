-- Fix fee_collections INSERT policy: Only allow service role (no user context)
DROP POLICY IF EXISTS "System can insert fee collections" ON public.fee_collections;
CREATE POLICY "System can insert fee collections"
ON public.fee_collections
FOR INSERT
WITH CHECK (auth.uid() IS NULL);

-- Fix notifications INSERT policy: Only allow service role (no user context)
DROP POLICY IF EXISTS "System can insert notifications" ON public.notifications;
CREATE POLICY "System can insert notifications"
ON public.notifications
FOR INSERT
WITH CHECK (auth.uid() IS NULL);

-- Create admin_balance_adjustments table for audit trail
CREATE TABLE IF NOT EXISTS public.admin_balance_adjustments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id UUID NOT NULL,
  wallet_id UUID NOT NULL REFERENCES public.wallets(id) ON DELETE CASCADE,
  old_balance NUMERIC NOT NULL,
  new_balance NUMERIC NOT NULL,
  reason TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.admin_balance_adjustments ENABLE ROW LEVEL SECURITY;

-- Only admins can view/manage adjustments
CREATE POLICY "Admins can view adjustments"
ON public.admin_balance_adjustments
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can insert adjustments"
ON public.admin_balance_adjustments
FOR INSERT
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));