
-- Revert the overly permissive policy and fix it properly
DROP POLICY IF EXISTS "Service role can manage wallet secrets" ON public.user_wallet_secrets;

-- Keep the restrictive policies - service role bypasses RLS anyway
-- The issue is in the edge function code, not the policies
