-- Add crypto_tag to profiles
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS crypto_tag TEXT UNIQUE;

-- Create wallet_addresses table
CREATE TABLE public.wallet_addresses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  chain TEXT NOT NULL,
  symbol TEXT NOT NULL,
  address TEXT NOT NULL,
  xpub TEXT,
  mnemonic_encrypted TEXT,
  is_primary BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, chain, address)
);

-- Enable RLS on wallet_addresses
ALTER TABLE public.wallet_addresses ENABLE ROW LEVEL SECURITY;

-- RLS policies for wallet_addresses
CREATE POLICY "Users can view their own wallet addresses"
ON public.wallet_addresses FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own wallet addresses"
ON public.wallet_addresses FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own wallet addresses"
ON public.wallet_addresses FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own wallet addresses"
ON public.wallet_addresses FOR DELETE
USING (auth.uid() = user_id);

-- Create notifications table
CREATE TABLE public.notifications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'info',
  is_read BOOLEAN DEFAULT false,
  data JSONB,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on notifications
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- RLS policies for notifications
CREATE POLICY "Users can view their own notifications"
ON public.notifications FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own notifications"
ON public.notifications FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own notifications"
ON public.notifications FOR DELETE
USING (auth.uid() = user_id);

-- Allow system to insert notifications (service role)
CREATE POLICY "System can insert notifications"
ON public.notifications FOR INSERT
WITH CHECK (true);

-- Enable realtime for notifications
ALTER TABLE public.notifications REPLICA IDENTITY FULL;

-- Add updated_at trigger for wallet_addresses
CREATE TRIGGER update_wallet_addresses_updated_at
BEFORE UPDATE ON public.wallet_addresses
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();