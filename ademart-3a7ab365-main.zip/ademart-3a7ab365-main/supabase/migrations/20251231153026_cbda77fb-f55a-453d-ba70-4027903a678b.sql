-- Add reserved_balance and error_details columns
ALTER TABLE public.wallets
ADD COLUMN IF NOT EXISTS reserved_balance numeric NOT NULL DEFAULT 0;

-- Add error details column for detailed error storage on transactions
ALTER TABLE public.transactions
ADD COLUMN IF NOT EXISTS error_details text NULL;

-- Add retry-related fields to transactions
ALTER TABLE public.transactions
ADD COLUMN IF NOT EXISTS retry_count integer NOT NULL DEFAULT 0,
ADD COLUMN IF NOT EXISTS last_error text NULL,
ADD COLUMN IF NOT EXISTS can_retry boolean NOT NULL DEFAULT false,
ADD COLUMN IF NOT EXISTS idempotency_key text NULL;

-- Add index for finding retryable transactions
CREATE INDEX IF NOT EXISTS idx_transactions_can_retry 
ON public.transactions (user_id, can_retry) 
WHERE can_retry = true;

-- Add unique constraint for idempotency (prevent duplicate sends)
CREATE UNIQUE INDEX IF NOT EXISTS idx_transactions_idempotency
ON public.transactions (user_id, idempotency_key)
WHERE idempotency_key IS NOT NULL;

-- Create function to reserve balance (move from available to reserved)
CREATE OR REPLACE FUNCTION public.reserve_wallet_balance(
  p_wallet_id uuid,
  p_amount numeric
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  UPDATE public.wallets
  SET 
    balance = balance - p_amount,
    reserved_balance = reserved_balance + p_amount,
    updated_at = now()
  WHERE id = p_wallet_id 
    AND balance >= p_amount;
    
  RETURN FOUND;
END;
$$;

-- Create function to confirm reserved balance (just remove from reserved)
CREATE OR REPLACE FUNCTION public.confirm_reserved_balance(
  p_wallet_id uuid,
  p_amount numeric
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  UPDATE public.wallets
  SET 
    reserved_balance = GREATEST(0, reserved_balance - p_amount),
    updated_at = now()
  WHERE id = p_wallet_id;
    
  RETURN FOUND;
END;
$$;

-- Create function to release reserved balance (move back to available on failure)
CREATE OR REPLACE FUNCTION public.release_reserved_balance(
  p_wallet_id uuid,
  p_amount numeric
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  UPDATE public.wallets
  SET 
    balance = balance + p_amount,
    reserved_balance = GREATEST(0, reserved_balance - p_amount),
    updated_at = now()
  WHERE id = p_wallet_id;
    
  RETURN FOUND;
END;
$$;