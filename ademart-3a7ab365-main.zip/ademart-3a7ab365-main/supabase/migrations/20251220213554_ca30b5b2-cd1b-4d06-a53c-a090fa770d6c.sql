
-- Fix RLS policy for user_wallet_secrets to allow service role inserts
-- Drop existing INSERT policy
DROP POLICY IF EXISTS "Users can insert their own wallet secret" ON public.user_wallet_secrets;

-- Create new INSERT policy that allows both:
-- 1. Authenticated users inserting their own record
-- 2. Service role (which bypasses RLS anyway, but this makes it explicit)
CREATE POLICY "Users can insert their own wallet secret"
ON public.user_wallet_secrets
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Also add a policy specifically for service role operations
-- Note: Service role already bypasses RLS, but let's ensure the INSERT works
-- The real fix is to verify the service client is correctly configured

-- Add a permissive policy for service role context (when auth.uid() is null but service key is used)
CREATE POLICY "Service role can manage wallet secrets"
ON public.user_wallet_secrets
FOR ALL
USING (true)
WITH CHECK (true);

-- Make sure the table RLS is enabled
ALTER TABLE public.user_wallet_secrets ENABLE ROW LEVEL SECURITY;
