-- Create secure table for storing encrypted mnemonics
-- Users can only INSERT, never SELECT/UPDATE/DELETE their own mnemonic
-- Only service role (edge functions) can read this table
CREATE TABLE public.user_wallet_secrets (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE,
  mnemonic_encrypted TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.user_wallet_secrets ENABLE ROW LEVEL SECURITY;

-- Users can only insert their own secret (first time setup)
CREATE POLICY "Users can insert their own wallet secret"
ON public.user_wallet_secrets
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- NO SELECT policy for users - only service role can read
-- This prevents exposure via RLS bypass attacks

-- Admins cannot read either - this is intentional for security
-- Only edge functions with service role can access mnemonics

-- Add trigger for updated_at
CREATE TRIGGER update_user_wallet_secrets_updated_at
BEFORE UPDATE ON public.user_wallet_secrets
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Migrate existing mnemonics from wallet_addresses to new secure table
INSERT INTO public.user_wallet_secrets (user_id, mnemonic_encrypted)
SELECT DISTINCT ON (user_id) user_id, mnemonic_encrypted
FROM public.wallet_addresses
WHERE mnemonic_encrypted IS NOT NULL
ON CONFLICT (user_id) DO NOTHING;

-- Remove mnemonic_encrypted column from wallet_addresses
-- This removes the security vulnerability
ALTER TABLE public.wallet_addresses DROP COLUMN IF EXISTS mnemonic_encrypted;