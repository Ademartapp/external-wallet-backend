-- Fix wallet persistence across tokens on the same chain (e.g. ETH + USDT ERC20 sharing same address)
-- Old constraint UNIQUE(user_id, chain, address) prevents storing per-token rows.

-- 1) De-duplicate any accidental duplicates per (user_id, symbol, chain)
WITH ranked AS (
  SELECT id,
         row_number() OVER (PARTITION BY user_id, symbol, chain ORDER BY created_at DESC, id DESC) AS rn
  FROM public.wallet_addresses
)
DELETE FROM public.wallet_addresses wa
USING ranked r
WHERE wa.id = r.id
  AND r.rn > 1;

-- 2) Drop the old uniqueness constraint (if present)
ALTER TABLE public.wallet_addresses
  DROP CONSTRAINT IF EXISTS wallet_addresses_user_id_chain_address_key;

-- 3) Add the correct uniqueness constraint
ALTER TABLE public.wallet_addresses
  ADD CONSTRAINT wallet_addresses_user_id_symbol_chain_key UNIQUE (user_id, symbol, chain);

-- 4) Helpful index for lookups
CREATE INDEX IF NOT EXISTS idx_wallet_addresses_user_symbol_chain
  ON public.wallet_addresses (user_id, symbol, chain);
