-- Enable realtime for transactions table to detect deposits
ALTER PUBLICATION supabase_realtime ADD TABLE public.transactions;