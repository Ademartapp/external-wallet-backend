-- Add explicit restrictive policies for user_wallet_secrets
-- Users should NEVER be able to SELECT their encrypted mnemonic directly
-- Only the service role (edge functions) can access this table

-- Block all SELECT access - only service role bypasses RLS
CREATE POLICY "No direct read access to wallet secrets"
ON public.user_wallet_secrets
FOR SELECT
USING (false);

-- Block all UPDATE access - secrets are immutable after creation
CREATE POLICY "No updates to wallet secrets"
ON public.user_wallet_secrets
FOR UPDATE
USING (false);

-- Block all DELETE access - secrets should never be deleted
CREATE POLICY "No deletion of wallet secrets"
ON public.user_wallet_secrets
FOR DELETE
USING (false);