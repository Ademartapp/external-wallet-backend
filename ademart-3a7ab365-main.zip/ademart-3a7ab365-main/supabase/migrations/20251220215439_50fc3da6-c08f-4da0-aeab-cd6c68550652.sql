-- Drop the restrictive INSERT policy
DROP POLICY IF EXISTS "Users can insert their own wallet secret" ON public.user_wallet_secrets;

-- Create a permissive policy for service role INSERT (and user INSERT)
CREATE POLICY "Service role can insert wallet secrets"
ON public.user_wallet_secrets
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

-- Also allow service role to SELECT for getOrCreateMnemonic
DROP POLICY IF EXISTS "No direct read access to wallet secrets" ON public.user_wallet_secrets;

CREATE POLICY "Service role can read wallet secrets"
ON public.user_wallet_secrets
FOR SELECT
USING (false); -- Still block direct user access, edge function uses service role which bypasses RLS

-- Clear the duplicate addresses again for fresh test
DELETE FROM wallet_addresses;
DELETE FROM wallets;