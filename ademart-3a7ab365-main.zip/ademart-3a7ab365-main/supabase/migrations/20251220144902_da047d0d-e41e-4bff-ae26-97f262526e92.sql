-- Prevent all deletions of transaction records for audit trail integrity
CREATE POLICY "No deletion of transactions"
ON public.transactions
FOR DELETE
USING (false);