-- Create KYC submissions table
CREATE TABLE public.kyc_submissions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  full_name TEXT NOT NULL,
  date_of_birth DATE NOT NULL,
  bvn TEXT NOT NULL,
  address TEXT NOT NULL,
  city TEXT NOT NULL,
  state TEXT NOT NULL,
  id_type TEXT NOT NULL,
  id_number TEXT NOT NULL,
  id_document_url TEXT,
  selfie_url TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  reviewed_by UUID,
  reviewed_at TIMESTAMP WITH TIME ZONE,
  rejection_reason TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT kyc_status_check CHECK (status IN ('pending', 'approved', 'rejected'))
);

-- Enable RLS
ALTER TABLE public.kyc_submissions ENABLE ROW LEVEL SECURITY;

-- Users can view their own KYC submissions
CREATE POLICY "Users can view their own KYC" 
ON public.kyc_submissions 
FOR SELECT 
USING (auth.uid() = user_id);

-- Users can insert their own KYC submissions
CREATE POLICY "Users can submit their own KYC" 
ON public.kyc_submissions 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Users can update their own pending KYC
CREATE POLICY "Users can update pending KYC" 
ON public.kyc_submissions 
FOR UPDATE 
USING (auth.uid() = user_id AND status = 'pending');

-- Admins can view all KYC submissions
CREATE POLICY "Admins can view all KYC" 
ON public.kyc_submissions 
FOR SELECT 
USING (has_role(auth.uid(), 'admin'::app_role));

-- Admins can update KYC status
CREATE POLICY "Admins can update KYC" 
ON public.kyc_submissions 
FOR UPDATE 
USING (has_role(auth.uid(), 'admin'::app_role));

-- No deletion of KYC records
CREATE POLICY "No deletion of KYC" 
ON public.kyc_submissions 
FOR DELETE 
USING (false);

-- Deny anonymous access
CREATE POLICY "Deny anonymous access to KYC" 
ON public.kyc_submissions 
FOR SELECT 
USING (false);

-- Add updated_at trigger
CREATE TRIGGER update_kyc_updated_at
BEFORE UPDATE ON public.kyc_submissions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create storage bucket for KYC documents
INSERT INTO storage.buckets (id, name, public) 
VALUES ('kyc-documents', 'kyc-documents', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for KYC documents
CREATE POLICY "Users can upload their own KYC documents" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'kyc-documents' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can view their own KYC documents" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'kyc-documents' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Admins can view all KYC documents" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'kyc-documents' AND has_role(auth.uid(), 'admin'::app_role));