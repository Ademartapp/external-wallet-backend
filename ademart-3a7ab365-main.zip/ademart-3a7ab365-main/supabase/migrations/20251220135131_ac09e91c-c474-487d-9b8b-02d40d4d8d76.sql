-- Create admin_settings table for fee configuration
CREATE TABLE public.admin_settings (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  key text NOT NULL UNIQUE,
  value jsonb NOT NULL DEFAULT '{}',
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.admin_settings ENABLE ROW LEVEL SECURITY;

-- Only admins can read/write settings
CREATE POLICY "Admins can manage settings"
ON public.admin_settings
FOR ALL
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Create trigger for updated_at
CREATE TRIGGER update_admin_settings_updated_at
BEFORE UPDATE ON public.admin_settings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default fee settings
INSERT INTO public.admin_settings (key, value) VALUES
  ('deposit_fee_percent', '{"value": 1.0}'::jsonb),
  ('withdrawal_fee_percent', '{"value": 1.5}'::jsonb),
  ('min_withdrawal_fee', '{"BTC": 0.0001, "ETH": 0.001, "USDT": 1}'::jsonb);

-- Create fee_collections table to track admin profits
CREATE TABLE public.fee_collections (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  transaction_id uuid REFERENCES public.transactions(id),
  fee_type text NOT NULL, -- 'deposit' or 'withdrawal'
  currency text NOT NULL,
  fee_amount numeric NOT NULL,
  original_amount numeric NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.fee_collections ENABLE ROW LEVEL SECURITY;

-- Only admins can read fee collections
CREATE POLICY "Admins can view all fee collections"
ON public.fee_collections
FOR SELECT
USING (public.has_role(auth.uid(), 'admin'));

-- System can insert fee collections (from edge functions)
CREATE POLICY "System can insert fee collections"
ON public.fee_collections
FOR INSERT
WITH CHECK (true);