import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// External wallet backend URL (set in Supabase secrets)
const WALLET_BACKEND_URL = Deno.env.get('WALLET_BACKEND_URL') || '';
const WALLET_BACKEND_TOKEN = Deno.env.get('WALLET_BACKEND_TOKEN') || '';

// Proxy request to external backend
async function proxyToBackend(endpoint: string, body: unknown): Promise<any> {
  if (!WALLET_BACKEND_URL) {
    throw new Error('WALLET_BACKEND_URL not configured - deploy external backend first');
  }

  const response = await fetch(`${WALLET_BACKEND_URL}${endpoint}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${WALLET_BACKEND_TOKEN}`
    },
    body: JSON.stringify(body)
  });

  const data = await response.json();
  
  if (!response.ok) {
    throw new Error(data.error || `Backend error: ${response.status}`);
  }

  return data;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Auth check
    const authHeader = req.headers.get('Authorization') ?? '';
    let userId: string | undefined;
    
    try {
      const supabaseAuth = createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        Deno.env.get('SUPABASE_ANON_KEY') ?? '',
        { global: { headers: { Authorization: authHeader } } }
      );
      const { data } = await supabaseAuth.auth.getUser();
      userId = data.user?.id;
    } catch {
      // Allow unauthenticated for some actions
    }

    const body = await req.json();
    const { action, symbol, chain, toAddress, amount, feeLevel } = body;

    console.log(`[Unified Wallet Proxy] Action: ${action}, User: ${userId?.substring(0, 8)}...`);

    switch (action) {
      case 'health_check': {
        const backendConfigured = !!WALLET_BACKEND_URL;
        return new Response(JSON.stringify({
          success: true,
          status: backendConfigured ? 'healthy' : 'backend_not_configured',
          backendUrl: backendConfigured ? WALLET_BACKEND_URL : null
        }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      }

      case 'create_wallet': {
        if (!userId || !symbol) {
          throw new Error('Missing userId or symbol');
        }

        // Check if wallet exists
        const { data: existing } = await supabaseClient
          .from('wallet_addresses')
          .select('address')
          .eq('user_id', userId)
          .eq('symbol', symbol.toUpperCase())
          .maybeSingle();

        if (existing) {
          return new Response(JSON.stringify({
            success: true,
            address: existing.address,
            existed: true
          }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
        }

        // Proxy to external backend
        const result = await proxyToBackend('/api/wallet/generate', {
          chain: chain || symbol,
          symbol,
          userId
        });

        // Store address in DB (encrypted key stays on backend)
        await supabaseClient.from('wallet_addresses').insert({
          user_id: userId,
          address: result.data.address,
          chain: result.data.chain.toLowerCase(),
          symbol: result.data.symbol,
          is_primary: true
        });

        // Create wallet balance record
        await supabaseClient.from('wallets').upsert({
          user_id: userId,
          currency: result.data.symbol,
          balance: 0
        }, { onConflict: 'user_id,currency' });

        return new Response(JSON.stringify({
          success: true,
          address: result.data.address,
          chain: result.data.chain,
          symbol: result.data.symbol
        }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      }

      case 'get_balance': {
        if (!userId || !symbol) throw new Error('Missing fields');

        const { data: wallet } = await supabaseClient
          .from('wallet_addresses')
          .select('address, chain')
          .eq('user_id', userId)
          .eq('symbol', symbol.toUpperCase())
          .maybeSingle();

        if (!wallet) {
          return new Response(JSON.stringify({
            success: true,
            balance: '0',
            address: null
          }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
        }

        // Proxy balance request to backend
        const result = await proxyToBackend('/api/transactions/balance', {
          chain: wallet.chain,
          address: wallet.address,
          symbol
        });

        return new Response(JSON.stringify({
          success: true,
          balance: result.balance,
          address: wallet.address
        }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      }

      case 'send': {
        if (!userId || !symbol || !toAddress || !amount) {
          throw new Error('Missing required fields for send');
        }

        const { data: wallet } = await supabaseClient
          .from('wallet_addresses')
          .select('address, chain')
          .eq('user_id', userId)
          .eq('symbol', symbol.toUpperCase())
          .maybeSingle();

        if (!wallet) throw new Error('Wallet not found');

        // Create pending transaction
        const { data: tx } = await supabaseClient
          .from('transactions')
          .insert({
            user_id: userId,
            type: 'send',
            from_currency: symbol.toUpperCase(),
            amount: parseFloat(amount),
            recipient_address: toAddress,
            status: 'pending'
          })
          .select()
          .single();

        // Proxy to backend for signing and broadcast
        const result = await proxyToBackend('/api/transactions/send', {
          chain: wallet.chain,
          symbol,
          toAddress,
          amount,
          feeLevel: feeLevel || 'standard',
          userId // Backend uses this to retrieve encrypted key
        });

        // Update transaction with hash
        if (result.success && result.txHash) {
          await supabaseClient
            .from('transactions')
            .update({ tx_hash: result.txHash })
            .eq('id', tx.id);
        } else {
          await supabaseClient
            .from('transactions')
            .update({ 
              status: 'failed',
              last_error: result.error,
              can_retry: result.retryable
            })
            .eq('id', tx.id);
        }

        return new Response(JSON.stringify({
          success: result.success,
          txHash: result.txHash,
          explorerUrl: result.explorerUrl,
          error: result.error,
          transactionId: tx.id
        }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      }

      case 'estimate_fee': {
        const result = await proxyToBackend('/api/transactions/estimate-fee', {
          chain: chain || symbol,
          from: body.from,
          to: toAddress,
          amount,
          symbol
        });
        return new Response(JSON.stringify(result), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      default:
        throw new Error(`Unknown action: ${action}`);
    }
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    console.error('[Unified Wallet Proxy] Error:', message);
    return new Response(JSON.stringify({ success: false, error: message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
