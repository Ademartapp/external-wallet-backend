import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface PriceAlert {
  id: string;
  user_id: string;
  symbol: string;
  target_price: number;
  condition: 'above' | 'below';
  is_active: boolean;
}

interface CryptoPrice {
  [key: string]: {
    usd: number;
  };
}

// Map symbols to CoinGecko IDs
const symbolToCoingeckoId: Record<string, string> = {
  'BTC': 'bitcoin',
  'ETH': 'ethereum',
  'USDT': 'tether',
  'BNB': 'binancecoin',
  'SOL': 'solana',
  'XRP': 'ripple',
  'USDC': 'usd-coin',
  'ADA': 'cardano',
  'DOGE': 'dogecoin',
  'TRX': 'tron',
  'LINK': 'chainlink',
  'DOT': 'polkadot',
  'MATIC': 'polygon-ecosystem-token',
  'LTC': 'litecoin',
  'AVAX': 'avalanche-2',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const resendApiKey = Deno.env.get('RESEND_API_KEY');

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    console.log('Fetching active price alerts...');

    // Get all active alerts
    const { data: alerts, error: alertsError } = await supabase
      .from('price_alerts')
      .select('*')
      .eq('is_active', true)
      .is('triggered_at', null);

    if (alertsError) {
      console.error('Error fetching alerts:', alertsError);
      throw alertsError;
    }

    if (!alerts || alerts.length === 0) {
      console.log('No active alerts to check');
      return new Response(JSON.stringify({ message: 'No active alerts' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log(`Found ${alerts.length} active alerts`);

    // Get unique symbols and convert to CoinGecko IDs
    const uniqueSymbols = [...new Set(alerts.map((a: PriceAlert) => a.symbol))];
    const coingeckoIds = uniqueSymbols
      .map(s => symbolToCoingeckoId[s])
      .filter(Boolean);

    if (coingeckoIds.length === 0) {
      console.log('No valid symbols to fetch prices for');
      return new Response(JSON.stringify({ message: 'No valid symbols' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Fetch current prices from CoinGecko
    console.log('Fetching prices for:', coingeckoIds.join(','));
    const priceResponse = await fetch(
      `https://api.coingecko.com/api/v3/simple/price?ids=${coingeckoIds.join(',')}&vs_currencies=usd`
    );

    if (!priceResponse.ok) {
      throw new Error(`CoinGecko API error: ${priceResponse.status}`);
    }

    const prices: CryptoPrice = await priceResponse.json();
    console.log('Fetched prices:', JSON.stringify(prices));

    // Create reverse lookup from coingecko ID to symbol
    const coingeckoIdToSymbol: Record<string, string> = {};
    for (const [symbol, id] of Object.entries(symbolToCoingeckoId)) {
      coingeckoIdToSymbol[id] = symbol;
    }

    // Check each alert
    const triggeredAlerts: string[] = [];
    const notificationsToSend: Array<{ userId: string; symbol: string; targetPrice: number; currentPrice: number; condition: string }> = [];

    for (const alert of alerts as PriceAlert[]) {
      const coingeckoId = symbolToCoingeckoId[alert.symbol];
      if (!coingeckoId || !prices[coingeckoId]) {
        console.log(`No price data for ${alert.symbol}`);
        continue;
      }

      const currentPrice = prices[coingeckoId].usd;
      let triggered = false;

      if (alert.condition === 'above' && currentPrice >= alert.target_price) {
        triggered = true;
      } else if (alert.condition === 'below' && currentPrice <= alert.target_price) {
        triggered = true;
      }

      if (triggered) {
        console.log(`Alert triggered: ${alert.symbol} ${alert.condition} ${alert.target_price} (current: ${currentPrice})`);
        triggeredAlerts.push(alert.id);
        notificationsToSend.push({
          userId: alert.user_id,
          symbol: alert.symbol,
          targetPrice: alert.target_price,
          currentPrice,
          condition: alert.condition,
        });
      }
    }

    // Mark alerts as triggered
    if (triggeredAlerts.length > 0) {
      const { error: updateError } = await supabase
        .from('price_alerts')
        .update({ triggered_at: new Date().toISOString(), is_active: false })
        .in('id', triggeredAlerts);

      if (updateError) {
        console.error('Error updating triggered alerts:', updateError);
      }

      // Create in-app notifications
      for (const notification of notificationsToSend) {
        const { error: notifError } = await supabase
          .from('notifications')
          .insert({
            user_id: notification.userId,
            title: 'Price Alert Triggered!',
            message: `${notification.symbol} is now ${notification.condition === 'above' ? 'above' : 'below'} $${notification.targetPrice}. Current price: $${notification.currentPrice.toFixed(2)}`,
            type: 'price_alert',
            data: {
              symbol: notification.symbol,
              target_price: notification.targetPrice,
              current_price: notification.currentPrice,
              condition: notification.condition,
            },
          });

        if (notifError) {
          console.error('Error creating notification:', notifError);
        }

        // Send email notification if RESEND_API_KEY is available
        if (resendApiKey) {
          try {
            // Get user email
            const { data: userData } = await supabase.auth.admin.getUserById(notification.userId);
            if (userData?.user?.email) {
              await fetch('https://api.resend.com/emails', {
                method: 'POST',
                headers: {
                  'Authorization': `Bearer ${resendApiKey}`,
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                  from: 'CryptoWallet <noreply@resend.dev>',
                  to: [userData.user.email],
                  subject: `🔔 Price Alert: ${notification.symbol} ${notification.condition === 'above' ? '↑' : '↓'} $${notification.targetPrice}`,
                  html: `
                    <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
                      <h2 style="color: #10b981;">Price Alert Triggered!</h2>
                      <p style="font-size: 18px;">
                        <strong>${notification.symbol}</strong> is now ${notification.condition === 'above' ? 'above' : 'below'} your target price.
                      </p>
                      <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
                        <p style="margin: 0;"><strong>Target Price:</strong> $${notification.targetPrice}</p>
                        <p style="margin: 10px 0 0;"><strong>Current Price:</strong> $${notification.currentPrice.toFixed(2)}</p>
                      </div>
                      <p style="color: #6b7280; font-size: 14px;">
                        This alert has been automatically deactivated. Create a new alert to continue monitoring.
                      </p>
                    </div>
                  `,
                }),
              });
              console.log(`Email sent to ${userData.user.email} for ${notification.symbol} alert`);
            }
          } catch (emailError) {
            console.error('Error sending email:', emailError);
          }
        }
      }
    }

    return new Response(
      JSON.stringify({
        message: 'Price alerts checked',
        checked: alerts.length,
        triggered: triggeredAlerts.length,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in check-price-alerts:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
