import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const QUIDAX_API_KEY = Deno.env.get('QUIDAX_API_KEY');
const QUIDAX_API_SECRET = Deno.env.get('QUIDAX_API_SECRET');
const QUIDAX_BASE_URL = 'https://www.quidax.com/api/v1';

// ---- Lightweight in-memory caching (warm instances only) ----
// Helps prevent swap/rate failures when upstream APIs briefly rate-limit.
type CachedRate = { price: number; ts: number; source: string };
const RATE_CACHE_MAX_AGE_MS = 10 * 60 * 1000; // 10 minutes
const rateCache = new Map<string, CachedRate>();

function getCachedRate(key: string, maxAgeMs = RATE_CACHE_MAX_AGE_MS): CachedRate | null {
  const v = rateCache.get(key);
  if (!v) return null;
  if (Date.now() - v.ts > maxAgeMs) return null;
  return v;
}

function getAnyCachedRate(key: string): CachedRate | null {
  return rateCache.get(key) ?? null;
}

function setCachedRate(key: string, price: number, source: string) {
  rateCache.set(key, { price, source, ts: Date.now() });
}

// Mobile money providers
const MOBILE_MONEY_PROVIDERS = [
  { code: 'opay', name: 'OPay', type: 'mobile_money' },
  { code: 'palmpay', name: 'PalmPay', type: 'mobile_money' },
  { code: 'kuda', name: 'Kuda MFB', type: 'mobile_money' },
  { code: 'moniepoint', name: 'Moniepoint', type: 'mobile_money' },
];

// CoinGecko ID mapping for fallback
function getCoinGeckoId(currency: string): string | null {
  const mapping: Record<string, string> = {
    btc: 'bitcoin',
    eth: 'ethereum',
    usdt: 'tether',
    usdc: 'usd-coin',
    sol: 'solana',
    bnb: 'binancecoin',
    matic: 'polygon-ecosystem-token',
    ltc: 'litecoin',
    doge: 'dogecoin',
    trx: 'tron',
  };
  return mapping[currency.toLowerCase()] || null;
}

// Bybit symbol mapping
function getBybitSymbol(currency: string): string {
  const mapping: Record<string, string> = {
    btc: 'BTCUSDT',
    eth: 'ETHUSDT',
    usdt: 'USDTUSDC', // USDT paired with USDC
    sol: 'SOLUSDT',
    bnb: 'BNBUSDT',
    matic: 'MATICUSDT',
    ltc: 'LTCUSDT',
    doge: 'DOGEUSDT',
    trx: 'TRXUSDT',
    usdc: 'USDCUSDT',
  };
  return mapping[currency.toLowerCase()] || `${currency.toUpperCase()}USDT`;
}

async function fetchCoinGeckoUsdRate(symbol: string): Promise<{ price: number; source: string } | null> {
  const cacheKey = `usd_${symbol.toLowerCase()}`;

  // Fast path: fresh cache
  const cached = getCachedRate(cacheKey);
  if (cached) return { price: cached.price, source: cached.source };

  const id = getCoinGeckoId(symbol);
  if (!id) {
    // If we don't know the mapping, last-chance stale cache (if any)
    const stale = getAnyCachedRate(cacheKey);
    return stale ? { price: stale.price, source: stale.source } : null;
  }

  // Stablecoins
  if (symbol.toLowerCase() === 'usdt' || symbol.toLowerCase() === 'usdc') {
    setCachedRate(cacheKey, 1, 'stable');
    return { price: 1, source: 'stable' };
  }

  try {
    const res = await fetch(
      `https://api.coingecko.com/api/v3/simple/price?ids=${encodeURIComponent(id)}&vs_currencies=usd`
    );

    if (res.ok) {
      const data = await res.json();
      const price = Number(data?.[id]?.usd);
      if (!price || Number.isNaN(price)) {
        const stale = getAnyCachedRate(cacheKey);
        return stale ? { price: stale.price, source: stale.source } : null;
      }
      setCachedRate(cacheKey, price, 'coingecko');
      return { price, source: 'coingecko' };
    }

    // Non-OK: fallback to any cached value
    const stale = getAnyCachedRate(cacheKey);
    return stale ? { price: stale.price, source: stale.source } : null;
  } catch (e) {
    console.log(`CoinGecko rate fetch failed for ${symbol}:`, e);
    const stale = getAnyCachedRate(cacheKey);
    return stale ? { price: stale.price, source: stale.source } : null;
  }
}

// Fetch rates from Bybit (primary) with CoinGecko + cache fallback
async function fetchBybitRate(symbol: string): Promise<{ price: number; source: string } | null> {
  const cacheKey = `usd_${symbol.toLowerCase()}`;

  // Stablecoins
  if (symbol.toLowerCase() === 'usdt' || symbol.toLowerCase() === 'usdc') {
    setCachedRate(cacheKey, 1, 'stable');
    return { price: 1, source: 'stable' };
  }

  // Prefer fresh cache before hitting upstream
  const cached = getCachedRate(cacheKey);
  if (cached) return { price: cached.price, source: cached.source };

  try {
    const bybitSymbol = getBybitSymbol(symbol);
    const response = await fetch(
      `https://api.bybit.com/v5/market/tickers?category=spot&symbol=${encodeURIComponent(bybitSymbol)}`,
      {
        headers: {
          Accept: 'application/json',
          'User-Agent': 'Mozilla/5.0 (compatible; Lovable/1.0)',
        },
      }
    );

    if (response.ok) {
      const data = await response.json();
      if (data.retCode === 0 && data.result?.list?.[0]?.lastPrice) {
        const price = parseFloat(data.result.list[0].lastPrice);
        if (!Number.isNaN(price) && price > 0) {
          setCachedRate(cacheKey, price, 'bybit');
          return { price, source: 'bybit' };
        }
      }

      console.log(`Bybit API returned no usable data for ${bybitSymbol}`);
    } else {
      console.log(`Bybit API returned ${response.status} for ${bybitSymbol}`);
    }

    const cg = await fetchCoinGeckoUsdRate(symbol);
    if (cg) {
      // fetchCoinGeckoUsdRate already caches
      return cg;
    }

    // Last chance: stale cache
    const stale = getAnyCachedRate(cacheKey);
    return stale ? { price: stale.price, source: stale.source } : null;
  } catch (error) {
    console.error(`Bybit rate fetch failed for ${symbol}:`, error);

    const cg = await fetchCoinGeckoUsdRate(symbol);
    if (cg) return cg;

    const stale = getAnyCachedRate(cacheKey);
    return stale ? { price: stale.price, source: stale.source } : null;
  }
}

// Fetch USD to NGN rate from multiple sources
async function fetchUsdNgnRate(): Promise<number> {
  const cacheKey = 'usd_ngn';

  const cached = getCachedRate(cacheKey);
  if (cached) return cached.price;

  // Try to get from CoinGecko (USDT to NGN)
  try {
    const response = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=tether&vs_currencies=ngn');
    if (response.ok) {
      const data = await response.json();
      if (data.tether?.ngn) {
        console.log('USD/NGN rate from CoinGecko:', data.tether.ngn);
        setCachedRate(cacheKey, data.tether.ngn, 'coingecko');
        return data.tether.ngn;
      }
    }
  } catch (error) {
    console.log('CoinGecko USD/NGN fetch failed:', error);
  }

  // Fallback to last known cached (even if stale)
  const stale = getAnyCachedRate(cacheKey);
  if (stale) return stale.price;

  // Final fallback
  console.log('Using fallback USD/NGN rate: 1600');
  setCachedRate(cacheKey, 1600, 'fallback');
  return 1600;
}

async function quidaxRequest(endpoint: string, method = 'GET', body?: any, retries = 3) {
  const url = `${QUIDAX_BASE_URL}${endpoint}`;
  
  if (!QUIDAX_API_SECRET) {
    console.error('Quidax API secret not configured');
    throw new Error('Exchange API not configured');
  }
  
  const headers: Record<string, string> = {
    'Authorization': `Bearer ${QUIDAX_API_SECRET}`,
    'Content-Type': 'application/json',
  };

  const options: RequestInit = {
    method,
    headers,
  };

  if (body) {
    options.body = JSON.stringify(body);
  }

  console.log(`Quidax request: ${method} ${endpoint}`);
  
  let lastError: Error | null = null;
  
  for (let attempt = 0; attempt < retries; attempt++) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 15000); // 15s timeout
      
      const response = await fetch(url, { ...options, signal: controller.signal });
      clearTimeout(timeoutId);
      
      const contentType = response.headers.get('content-type') || '';
      
      // Check if response is JSON
      if (!contentType.includes('application/json')) {
        const text = await response.text();
        console.error(`Quidax API returned non-JSON response (attempt ${attempt + 1}): ${text.slice(0, 200)}`);
        
        // Retry on 503/502/504 errors
        if (response.status >= 500 && attempt < retries - 1) {
          await new Promise(resolve => setTimeout(resolve, 1000 * (attempt + 1)));
          continue;
        }
        
        throw new Error('Exchange service temporarily unavailable');
      }
      
      const data = await response.json();
      
      if (!response.ok) {
        console.error('Quidax API error:', data);
        throw new Error(data.message || 'Quidax API error');
      }

      return data;
    } catch (error) {
      lastError = error as Error;
      
      // Don't retry on abort or non-retryable errors
      if ((error as Error).name === 'AbortError') {
        throw new Error('Request timeout - exchange service is slow');
      }
      
      if ((error as Error).message.includes('API error') || 
          (error as Error).message.includes('not configured')) {
        throw error;
      }
      
      // Wait before retry
      if (attempt < retries - 1) {
        console.log(`Quidax request failed, retrying in ${(attempt + 1)}s...`);
        await new Promise(resolve => setTimeout(resolve, 1000 * (attempt + 1)));
      }
    }
  }
  
  throw lastError || new Error('Exchange service temporarily unavailable');
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser();
    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    const { action, ...params } = await req.json();
    console.log(`Quidax action: ${action} for user: ${user.id}`);

    let result;

    switch (action) {
      case 'get_rates': {
        const { currency } = params;
        
        // Try Bybit first (more reliable)
        const bybitRate = await fetchBybitRate(currency);
        const usdNgnRate = await fetchUsdNgnRate();
        
        if (bybitRate) {
          const ngnRate = bybitRate.price * usdNgnRate;
          result = {
            pair: `${currency.toLowerCase()}ngn`,
            buy: ngnRate.toString(),
            sell: (ngnRate * 0.98).toString(), // 2% spread for sell
            last: ngnRate.toString(),
            source: 'bybit',
          };
        } else {
          // Try Quidax as fallback
          try {
            const pair = `${currency.toLowerCase()}ngn`;
            const ticker = await quidaxRequest(`/markets/tickers/${pair}`);
            result = {
              pair,
              buy: ticker.data.ticker.buy,
              sell: ticker.data.ticker.sell,
              last: ticker.data.ticker.last,
              source: 'quidax',
            };
          } catch (quidaxError) {
            console.log('Quidax rates failed, trying CoinGecko fallback:', quidaxError);
            // Fallback to CoinGecko for USD rates, then convert to NGN
            const coinGeckoId = getCoinGeckoId(currency);
            if (!coinGeckoId) throw new Error(`Unsupported currency: ${currency}`);
            
            const cgResponse = await fetch(
              `https://api.coingecko.com/api/v3/simple/price?ids=${coinGeckoId}&vs_currencies=usd,ngn`
            );
            const cgData = await cgResponse.json();
            const ngnRate = cgData[coinGeckoId]?.ngn || (cgData[coinGeckoId]?.usd * usdNgnRate);
            
            result = {
              pair: `${currency.toLowerCase()}ngn`,
              buy: ngnRate.toString(),
              sell: (ngnRate * 0.98).toString(),
              last: ngnRate.toString(),
              source: 'coingecko',
            };
          }
        }
        break;
      }

      case 'get_all_rates': {
        const currencies = ['btc', 'eth', 'usdt', 'sol'];
        const usdNgnRate = await fetchUsdNgnRate();
        let rates: Array<{ currency: string; sell: number; buy: number; source?: string }> = [];
        
        // Try Bybit first for all rates
        const bybitRates = await Promise.all(
          currencies.map(async (currency) => {
            const bybitRate = await fetchBybitRate(currency);
            if (bybitRate) {
              const ngnRate = bybitRate.price * usdNgnRate;
              return {
                currency: currency.toUpperCase(),
                sell: ngnRate * 0.98,
                buy: ngnRate,
                source: 'bybit',
              };
            }
            return null;
          })
        );
        
        rates = bybitRates.filter((r): r is NonNullable<typeof r> => r !== null);
        
        // If Bybit failed for some currencies, try Quidax as fallback
        const missingCurrencies = currencies.filter(
          c => !rates.find(r => r.currency === c.toUpperCase())
        );
        
        if (missingCurrencies.length > 0) {
          try {
            const quidaxRates = await Promise.all(
              missingCurrencies.map(async (currency) => {
                try {
                  const ticker = await quidaxRequest(`/markets/tickers/${currency}ngn`);
                  return {
                    currency: currency.toUpperCase(),
                    sell: parseFloat(ticker.data.ticker.sell),
                    buy: parseFloat(ticker.data.ticker.buy),
                    source: 'quidax',
                  };
                } catch (e) {
                  console.error(`Failed to get Quidax rate for ${currency}:`, e);
                  return null;
                }
              })
            );
            rates = [...rates, ...quidaxRates.filter((r): r is NonNullable<typeof r> => r !== null)];
          } catch (quidaxError) {
            console.log('Quidax all rates failed');
          }
        }
        
        // Final fallback to CoinGecko for any still missing
        const stillMissing = currencies.filter(
          c => !rates.find(r => r.currency === c.toUpperCase())
        );
        
        if (stillMissing.length > 0) {
          try {
            const cgResponse = await fetch(
              'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,tether,solana&vs_currencies=ngn'
            );
            const cgData = await cgResponse.json();
            
            const coinMap: Record<string, string> = {
              bitcoin: 'BTC',
              ethereum: 'ETH',
              tether: 'USDT',
              solana: 'SOL',
            };
            
            const cgRates = Object.entries(coinMap)
              .filter(([_, symbol]) => stillMissing.includes(symbol.toLowerCase()))
              .map(([id, symbol]) => {
                const ngnRate = cgData[id]?.ngn || 0;
                return {
                  currency: symbol,
                  sell: ngnRate * 0.98,
                  buy: ngnRate,
                  source: 'coingecko',
                };
              })
              .filter(r => r.sell > 0);
            
            rates = [...rates, ...cgRates];
          } catch (cgError) {
            console.error('CoinGecko fallback also failed:', cgError);
          }
        }
        
        result = rates;
        break;
      }

      case 'get_banks': {
        // Static list of Nigerian banks for reliability
        const NIGERIAN_BANKS = [
          { code: '044', name: 'Access Bank' },
          { code: '023', name: 'Citibank Nigeria' },
          { code: '063', name: 'Diamond Bank' },
          { code: '050', name: 'Ecobank Nigeria' },
          { code: '084', name: 'Enterprise Bank' },
          { code: '070', name: 'Fidelity Bank' },
          { code: '011', name: 'First Bank of Nigeria' },
          { code: '214', name: 'First City Monument Bank' },
          { code: '058', name: 'Guaranty Trust Bank' },
          { code: '030', name: 'Heritage Bank' },
          { code: '301', name: 'Jaiz Bank' },
          { code: '082', name: 'Keystone Bank' },
          { code: '526', name: 'Parallex Bank' },
          { code: '076', name: 'Polaris Bank' },
          { code: '101', name: 'Providus Bank' },
          { code: '221', name: 'Stanbic IBTC Bank' },
          { code: '068', name: 'Standard Chartered Bank' },
          { code: '232', name: 'Sterling Bank' },
          { code: '100', name: 'Suntrust Bank' },
          { code: '032', name: 'Union Bank of Nigeria' },
          { code: '033', name: 'United Bank For Africa' },
          { code: '215', name: 'Unity Bank' },
          { code: '035', name: 'Wema Bank' },
          { code: '057', name: 'Zenith Bank' },
          { code: '999992', name: 'OPay' },
          { code: '999991', name: 'PalmPay' },
          { code: '090267', name: 'Kuda Bank' },
          { code: '50515', name: 'Moniepoint MFB' },
        ];
        
        // Try Quidax first, fallback to static list
        try {
          const banks = await quidaxRequest('/withdrawals/banks');
          result = banks.data;
        } catch (e) {
          console.log('Using static bank list due to Quidax error:', e);
          result = NIGERIAN_BANKS;
        }
        break;
      }

      case 'get_mobile_money_providers': {
        result = MOBILE_MONEY_PROVIDERS;
        break;
      }

      case 'verify_account': {
        const { bank_code, account_number } = params;
        
        // Try Quidax verification first
        try {
          const verification = await quidaxRequest('/withdrawals/account/verify', 'POST', {
            bank_code,
            account_number,
          });
          result = verification.data;
        } catch (e) {
          // Fallback - return a placeholder that requires manual confirmation
          console.log('Account verification failed, using fallback:', e);
          result = { 
            account_name: 'Verification unavailable - please confirm account details',
            verified: false,
          };
        }
        break;
      }

      case 'verify_mobile_money': {
        const { provider_code, phone_number } = params;
        // Mobile money doesn't typically support bank-style verification
        result = { account_name: `Mobile Money (${phone_number})`, verified: true };
        break;
      }

      case 'sell_crypto': {
        const { currency, amount, bank_code, account_number, account_name, payout_type } = params;
        
        const { data: wallet, error: walletError } = await supabaseClient
          .from('wallets')
          .select('*')
          .eq('user_id', user.id)
          .eq('currency', currency.toUpperCase())
          .single();

        if (walletError || !wallet) {
          throw new Error(`Wallet not found for ${currency}`);
        }

        if (wallet.balance < amount) {
          throw new Error('Insufficient balance');
        }

        // Get rate from Bybit (more reliable)
        let rate = 0;
        const usdNgnRate = await fetchUsdNgnRate();
        
        const bybitRate = await fetchBybitRate(currency);
        if (bybitRate) {
          rate = bybitRate.price * usdNgnRate * 0.98; // 2% spread for sell
        } else {
          // Try CoinGecko as fallback
          try {
            const coinGeckoId = getCoinGeckoId(currency);
            if (coinGeckoId) {
              const cgResponse = await fetch(
                `https://api.coingecko.com/api/v3/simple/price?ids=${coinGeckoId}&vs_currencies=ngn`
              );
              const cgData = await cgResponse.json();
              rate = (cgData[coinGeckoId]?.ngn || 0) * 0.98;
            }
          } catch (e) {
            console.error('Rate fetch failed:', e);
          }
        }

        if (rate <= 0) {
          throw new Error('Unable to get exchange rate. Please try again later.');
        }

        const ngnAmount = amount * rate;
        const orderId = `SELL-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

        // Update wallet balance immediately
        const newBalance = wallet.balance - amount;
        const { error: updateError } = await supabaseClient
          .from('wallets')
          .update({ balance: newBalance })
          .eq('id', wallet.id);

        if (updateError) {
          console.error('Failed to update wallet:', updateError);
          throw new Error('Failed to process sell order. Please try again.');
        }

        // Record transaction with payout details
        const { data: txData, error: txError } = await supabaseClient
          .from('transactions')
          .insert({
            user_id: user.id,
            type: 'sell',
            from_currency: currency.toUpperCase(),
            to_currency: 'NGN',
            amount: amount,
            fee: 0,
            status: 'pending',
            recipient_address: `${payout_type}:${bank_code}:${account_number}:${account_name}`,
            tx_hash: orderId,
          })
          .select()
          .single();

        if (txError) {
          console.error('Failed to record transaction:', txError);
        }

        // Create notification for sell order placed
        const { error: notifError } = await supabaseClient
          .from('notifications')
          .insert({
            user_id: user.id,
            title: 'Sell Order Placed',
            message: `Your order to sell ${amount} ${currency.toUpperCase()} for ₦${ngnAmount.toLocaleString()} has been received and is being processed.`,
            type: 'sell_order',
            data: {
              transaction_id: txData?.id,
              crypto_amount: amount,
              crypto_currency: currency.toUpperCase(),
              ngn_amount: ngnAmount,
              payout_type,
              order_id: orderId,
            },
          });

        if (notifError) {
          console.error('Failed to create notification:', notifError);
        }

        console.log(`Sell order created: ${orderId}, ${amount} ${currency} -> ₦${ngnAmount}`);

        result = {
          success: true,
          order_id: orderId,
          ngn_amount: ngnAmount,
          rate,
          status: 'pending',
          payout_type,
          message: `Sell order received! ${amount} ${currency.toUpperCase()} will be converted to ₦${ngnAmount.toLocaleString('en-NG', { maximumFractionDigits: 2 })} and sent to your ${payout_type === 'mobile_money' ? 'mobile wallet' : 'bank account'} within 24 hours.`,
        };
        break;
      }

      case 'get_sell_orders': {
        // Get user's sell transactions
        const { data: transactions, error: txError } = await supabaseClient
          .from('transactions')
          .select('*')
          .eq('user_id', user.id)
          .eq('type', 'sell')
          .order('created_at', { ascending: false })
          .limit(50);

        if (txError) {
          throw new Error('Failed to fetch sell orders');
        }

        result = transactions.map((tx: any) => {
          const [payoutType, bankCode, accountNumber, accountName] = (tx.recipient_address || '').split(':');
          return {
            id: tx.id,
            crypto_amount: tx.amount,
            crypto_currency: tx.from_currency,
            ngn_currency: tx.to_currency,
            status: tx.status,
            created_at: tx.created_at,
            tx_hash: tx.tx_hash,
            payout_type: payoutType || 'bank',
            bank_code: bankCode,
            account_number: accountNumber,
            account_name: accountName,
          };
        });
        break;
      }

      case 'buy_crypto': {
        const { currency, ngn_amount, payment_method } = params;
        
        // Get rate from Bybit (more reliable)
        let rate = 0;
        const usdNgnRate = await fetchUsdNgnRate();
        
        const bybitRate = await fetchBybitRate(currency);
        if (bybitRate) {
          rate = bybitRate.price * usdNgnRate; // Buy rate (no spread reduction)
        } else {
          // Try CoinGecko as fallback
          try {
            const coinGeckoId = getCoinGeckoId(currency);
            if (coinGeckoId) {
              const cgResponse = await fetch(
                `https://api.coingecko.com/api/v3/simple/price?ids=${coinGeckoId}&vs_currencies=ngn`
              );
              const cgData = await cgResponse.json();
              rate = cgData[coinGeckoId]?.ngn || 0;
            }
          } catch (e) {
            console.error('Buy rate fetch failed:', e);
          }
        }

        if (rate <= 0) {
          throw new Error('Unable to get exchange rate. Please try again later.');
        }

        const cryptoAmount = ngn_amount / rate;
        const orderId = `BUY-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

        // Record transaction
        const { data: txData, error: txError } = await supabaseClient
          .from('transactions')
          .insert({
            user_id: user.id,
            type: 'buy',
            from_currency: 'NGN',
            to_currency: currency.toUpperCase(),
            amount: cryptoAmount,
            fee: 0,
            status: 'pending',
            recipient_address: `${payment_method}:${ngn_amount}`,
            tx_hash: orderId,
          })
          .select()
          .single();

        if (txError) {
          console.error('Failed to record buy transaction:', txError);
        }

        // Create notification
        await supabaseClient
          .from('notifications')
          .insert({
            user_id: user.id,
            title: 'Buy Order Placed',
            message: `Your order to buy ${cryptoAmount.toFixed(8)} ${currency.toUpperCase()} for ₦${ngn_amount.toLocaleString()} has been received. Complete payment to proceed.`,
            type: 'buy_order',
            data: {
              transaction_id: txData?.id,
              crypto_amount: cryptoAmount,
              crypto_currency: currency.toUpperCase(),
              ngn_amount,
              payment_method,
              order_id: orderId,
            },
          });

        console.log(`Buy order created: ${orderId}, ₦${ngn_amount} -> ${cryptoAmount} ${currency}`);

        result = {
          success: true,
          order_id: orderId,
          crypto_amount: cryptoAmount,
          rate,
          status: 'pending',
          message: `Buy order received! You will receive ${cryptoAmount.toFixed(8)} ${currency.toUpperCase()} after payment of ₦${ngn_amount.toLocaleString('en-NG', { maximumFractionDigits: 2 })} is confirmed.`,
        };
        break;
      }

      case 'get_buy_orders': {
        const { data: transactions, error: txError } = await supabaseClient
          .from('transactions')
          .select('*')
          .eq('user_id', user.id)
          .eq('type', 'buy')
          .order('created_at', { ascending: false })
          .limit(50);

        if (txError) {
          throw new Error('Failed to fetch buy orders');
        }

        result = transactions.map((tx: any) => {
          const [paymentMethod, ngnAmount] = (tx.recipient_address || '').split(':');
          return {
            id: tx.id,
            ngn_amount: parseFloat(ngnAmount) || 0,
            crypto_amount: tx.amount,
            crypto_currency: tx.to_currency,
            status: tx.status,
            created_at: tx.created_at,
            payment_method: paymentMethod || 'bank_transfer',
          };
        });
        break;
      }

      case 'cancel_buy_order': {
        const { transaction_id } = params;
        
        const { data: tx, error: txError } = await supabaseClient
          .from('transactions')
          .select('*')
          .eq('id', transaction_id)
          .eq('user_id', user.id)
          .eq('type', 'buy')
          .eq('status', 'pending')
          .maybeSingle();

        if (txError || !tx) {
          throw new Error('Order not found or cannot be cancelled');
        }

        // Update transaction status to cancelled
        await supabaseClient
          .from('transactions')
          .update({ status: 'cancelled' })
          .eq('id', transaction_id);

        // Create notification
        await supabaseClient
          .from('notifications')
          .insert({
            user_id: user.id,
            title: 'Buy Order Cancelled',
            message: `Your buy order for ${tx.amount} ${tx.to_currency} has been cancelled.`,
            type: 'order_cancelled',
            data: { transaction_id },
          });

        result = {
          success: true,
          message: 'Buy order cancelled successfully.',
        };
        break;
      }

      case 'get_withdrawal_status': {
        const { withdrawal_id } = params;
        const status = await quidaxRequest(`/users/me/withdraws/${withdrawal_id}`);
        result = status.data;
        break;
      }

      case 'cancel_sell_order': {
        const { transaction_id } = params;
        
        // Get the transaction
        const { data: tx, error: txError } = await supabaseClient
          .from('transactions')
          .select('*')
          .eq('id', transaction_id)
          .eq('user_id', user.id)
          .eq('type', 'sell')
          .eq('status', 'pending')
          .maybeSingle();

        if (txError || !tx) {
          throw new Error('Order not found or cannot be cancelled');
        }

        // Refund the crypto to user's wallet
        const { data: wallet, error: walletError } = await supabaseClient
          .from('wallets')
          .select('*')
          .eq('user_id', user.id)
          .eq('currency', tx.from_currency)
          .maybeSingle();

        if (wallet) {
          const newBalance = wallet.balance + tx.amount;
          await supabaseClient
            .from('wallets')
            .update({ balance: newBalance })
            .eq('id', wallet.id);
        }

        // Update transaction status to cancelled
        await supabaseClient
          .from('transactions')
          .update({ status: 'cancelled' })
          .eq('id', transaction_id);

        // Create notification
        await supabaseClient
          .from('notifications')
          .insert({
            user_id: user.id,
            title: 'Order Cancelled',
            message: `Your sell order for ${tx.amount} ${tx.from_currency} has been cancelled. Crypto returned to wallet.`,
            type: 'order_cancelled',
            data: { transaction_id },
          });

        result = {
          success: true,
          message: `Order cancelled. ${tx.amount} ${tx.from_currency} returned to your wallet.`,
        };
        break;
      }

      case 'swap': {
        const { fromSymbol, toSymbol, amount } = params;
        
        if (!fromSymbol || !toSymbol || !amount) {
          throw new Error('Missing required fields: fromSymbol, toSymbol, amount');
        }

        const swapAmount = parseFloat(amount);
        if (isNaN(swapAmount) || swapAmount <= 0) {
          throw new Error('Invalid swap amount');
        }

        // Get source wallet
        const { data: fromWallet, error: fromWalletError } = await supabaseClient
          .from('wallets')
          .select('*')
          .eq('user_id', user.id)
          .eq('currency', fromSymbol.toUpperCase())
          .maybeSingle();

        if (fromWalletError || !fromWallet) {
          throw new Error(`Source wallet not found for ${fromSymbol}`);
        }

        if (fromWallet.balance < swapAmount) {
          throw new Error(`Insufficient ${fromSymbol} balance`);
        }

        // Get rates for both currencies
        const usdNgnRate = await fetchUsdNgnRate();
        const fromRate = await fetchBybitRate(fromSymbol);
        const toRate = await fetchBybitRate(toSymbol);

        if (!fromRate || !toRate) {
          throw new Error(`Unable to get exchange rates for ${fromSymbol}/${toSymbol}. Please try again.`);
        }

        // Calculate output amount (apply 0.1% fee)
        const fromUsdValue = swapAmount * fromRate.price;
        const toAmount = (fromUsdValue / toRate.price) * 0.999; // 0.1% fee
        const fee = (fromUsdValue / toRate.price) * 0.001;

        // Deduct from source wallet
        const newFromBalance = fromWallet.balance - swapAmount;
        await supabaseClient
          .from('wallets')
          .update({ balance: newFromBalance })
          .eq('id', fromWallet.id);

        // Add to destination wallet (create if doesn't exist)
        const { data: toWallet } = await supabaseClient
          .from('wallets')
          .select('*')
          .eq('user_id', user.id)
          .eq('currency', toSymbol.toUpperCase())
          .maybeSingle();

        if (toWallet) {
          await supabaseClient
            .from('wallets')
            .update({ balance: toWallet.balance + toAmount })
            .eq('id', toWallet.id);
        } else {
          await supabaseClient
            .from('wallets')
            .insert({
              user_id: user.id,
              currency: toSymbol.toUpperCase(),
              balance: toAmount,
            });
        }

        // Record transaction
        const swapId = `SWAP-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
        await supabaseClient
          .from('transactions')
          .insert({
            user_id: user.id,
            type: 'swap',
            from_currency: fromSymbol.toUpperCase(),
            to_currency: toSymbol.toUpperCase(),
            amount: swapAmount,
            fee: fee,
            status: 'completed',
            tx_hash: swapId,
          });

        // Create notification
        await supabaseClient
          .from('notifications')
          .insert({
            user_id: user.id,
            title: 'Swap Completed',
            message: `Swapped ${swapAmount} ${fromSymbol.toUpperCase()} to ${toAmount.toFixed(6)} ${toSymbol.toUpperCase()}`,
            type: 'swap',
            data: { fromSymbol, toSymbol, fromAmount: swapAmount, toAmount, fee },
          });

        result = {
          success: true,
          fromSymbol: fromSymbol.toUpperCase(),
          toSymbol: toSymbol.toUpperCase(),
          fromAmount: swapAmount,
          toAmount,
          fee,
          rate: fromRate.price / toRate.price,
          txId: swapId,
        };
        break;
      }

      default:
        throw new Error(`Unknown action: ${action}`);
    }

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Quidax function error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';

    // IMPORTANT: Always return 200 so the client receives a JSON payload.
    // supabase-js otherwise surfaces a generic "Edge Function returned a non-2xx status code".
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
