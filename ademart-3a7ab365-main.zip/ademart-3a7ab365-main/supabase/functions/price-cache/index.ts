import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Price cache in memory (shared across invocations)
const priceCache: {
  data: Record<string, { usd: number; usd_24h_change?: number }>;
  timestamp: number;
} = {
  data: {},
  timestamp: 0,
};

const CACHE_DURATION = 60000; // 60 seconds - less aggressive than client-side

// CoinGecko ID mapping
const COINGECKO_IDS: Record<string, string> = {
  BTC: 'bitcoin',
  ETH: 'ethereum',
  LTC: 'litecoin',
  DOGE: 'dogecoin',
  TRX: 'tron',
  BNB: 'binancecoin',
  MATIC: 'polygon-ecosystem-token',
  USDT: 'tether',
  USDC: 'usd-coin',
};

// Fallback prices when APIs fail
const FALLBACK_PRICES: Record<string, { usd: number; usd_24h_change: number }> = {
  bitcoin: { usd: 95000, usd_24h_change: 0 },
  ethereum: { usd: 3400, usd_24h_change: 0 },
  litecoin: { usd: 110, usd_24h_change: 0 },
  dogecoin: { usd: 0.38, usd_24h_change: 0 },
  tron: { usd: 0.26, usd_24h_change: 0 },
  binancecoin: { usd: 700, usd_24h_change: 0 },
  'polygon-ecosystem-token': { usd: 0.48, usd_24h_change: 0 },
  tether: { usd: 1, usd_24h_change: 0 },
  'usd-coin': { usd: 1, usd_24h_change: 0 },
};

async function fetchWithTimeout(url: string, timeout = 8000): Promise<Response> {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);
  
  try {
    const response = await fetch(url, { signal: controller.signal });
    clearTimeout(id);
    return response;
  } catch (error) {
    clearTimeout(id);
    throw error;
  }
}

async function fetchPricesFromCoinGecko(): Promise<Record<string, { usd: number; usd_24h_change?: number }>> {
  const coinIds = Object.values(COINGECKO_IDS).join(',');
  
  // Try multiple times with increasing delays
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const response = await fetchWithTimeout(
        `https://api.coingecko.com/api/v3/simple/price?ids=${coinIds}&vs_currencies=usd&include_24hr_change=true`
      );
      
      if (response.status === 429) {
        // Rate limited - wait and retry
        console.log(`CoinGecko rate limited, attempt ${attempt + 1}`);
        await new Promise(r => setTimeout(r, 2000 * (attempt + 1)));
        continue;
      }
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      
      const data = await response.json();
      console.log('[Price Cache] Fetched prices from CoinGecko');
      return data;
    } catch (error) {
      console.error(`[Price Cache] CoinGecko attempt ${attempt + 1} failed:`, error);
      
      if (attempt < 2) {
        await new Promise(r => setTimeout(r, 1000 * (attempt + 1)));
      }
    }
  }
  
  throw new Error('All CoinGecko attempts failed');
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { action, symbols } = await req.json().catch(() => ({ action: 'get_prices' }));

    console.log(`[Price Cache] Action: ${action}`);

    switch (action) {
      case 'get_prices': {
        const now = Date.now();
        
        // Check cache
        if (priceCache.timestamp > 0 && now - priceCache.timestamp < CACHE_DURATION) {
          console.log('[Price Cache] Returning cached prices');
          return new Response(JSON.stringify({
            success: true,
            prices: priceCache.data,
            source: 'cache',
            cachedAt: priceCache.timestamp,
          }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }
        
        // Fetch fresh prices
        try {
          const prices = await fetchPricesFromCoinGecko();
          
          // Update cache
          priceCache.data = prices;
          priceCache.timestamp = now;
          
          return new Response(JSON.stringify({
            success: true,
            prices,
            source: 'api',
            cachedAt: now,
          }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        } catch (error) {
          console.error('[Price Cache] Fetch failed, using fallback');
          
          // Return cached data if available, otherwise fallback
          if (priceCache.timestamp > 0) {
            return new Response(JSON.stringify({
              success: true,
              prices: priceCache.data,
              source: 'stale-cache',
              cachedAt: priceCache.timestamp,
              warning: 'Using stale cached prices',
            }), {
              headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            });
          }
          
          return new Response(JSON.stringify({
            success: true,
            prices: FALLBACK_PRICES,
            source: 'fallback',
            warning: 'Using fallback prices - API unavailable',
          }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }
      }

      case 'get_symbol_prices': {
        // Get prices for specific symbols
        const requestedSymbols = symbols || ['BTC', 'ETH', 'USDT'];
        const coinIds = requestedSymbols
          .map((s: string) => COINGECKO_IDS[s.toUpperCase()])
          .filter(Boolean);
        
        const now = Date.now();
        
        // Check if we have cached data for all requested symbols
        const hasCachedData = priceCache.timestamp > 0 && 
          now - priceCache.timestamp < CACHE_DURATION &&
          coinIds.every((id: string) => priceCache.data[id]);
        
        if (hasCachedData) {
          const filteredPrices: Record<string, any> = {};
          coinIds.forEach((id: string) => {
            filteredPrices[id] = priceCache.data[id];
          });
          
          return new Response(JSON.stringify({
            success: true,
            prices: filteredPrices,
            source: 'cache',
          }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }
        
        // Fetch fresh
        try {
          const prices = await fetchPricesFromCoinGecko();
          priceCache.data = prices;
          priceCache.timestamp = now;
          
          const filteredPrices: Record<string, any> = {};
          coinIds.forEach((id: string) => {
            if (prices[id]) filteredPrices[id] = prices[id];
          });
          
          return new Response(JSON.stringify({
            success: true,
            prices: filteredPrices,
            source: 'api',
          }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        } catch (error) {
          // Use fallback
          const filteredPrices: Record<string, any> = {};
          coinIds.forEach((id: string) => {
            if (FALLBACK_PRICES[id]) filteredPrices[id] = FALLBACK_PRICES[id];
          });
          
          return new Response(JSON.stringify({
            success: true,
            prices: filteredPrices,
            source: 'fallback',
            warning: 'Using fallback prices',
          }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }
      }

      case 'health': {
        return new Response(JSON.stringify({
          success: true,
          status: 'healthy',
          cacheAge: priceCache.timestamp ? Date.now() - priceCache.timestamp : null,
          cachedSymbols: Object.keys(priceCache.data),
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      default:
        return new Response(JSON.stringify({
          success: false,
          error: `Unknown action: ${action}`,
        }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
    }
  } catch (error) {
    console.error('[Price Cache] Error:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});