import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface GasFeeResponse {
  fees: Record<string, {
    fee: string;
    speed: string;
    recommended?: boolean;
    gwei?: number;
  }>;
}

serve(async (req: Request) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Fetching live gas fees...');
    
    const fees: GasFeeResponse['fees'] = {};

    // Fetch Ethereum gas prices
    try {
      const ethResponse = await fetch('https://api.etherscan.io/api?module=gastracker&action=gasoracle');
      const ethData = await ethResponse.json();
      
      if (ethData.status === '1' && ethData.result) {
        const gasPrice = parseInt(ethData.result.ProposeGasPrice || '30');
        const ethPrice = 3000; // Approximate ETH price
        const gasLimit = 21000; // Standard transfer
        const feeInEth = (gasPrice * gasLimit) / 1e9;
        const feeInUsd = feeInEth * ethPrice;
        
        fees['ETH'] = {
          fee: `$${feeInUsd.toFixed(2)}-${(feeInUsd * 2).toFixed(2)}`,
          speed: '~2 min',
          gwei: gasPrice,
        };
        console.log('ETH gas:', gasPrice, 'gwei');
      }
    } catch (e) {
      console.log('ETH gas fetch failed:', e);
      fees['ETH'] = { fee: '$2-15', speed: '~2 min' };
    }

    // Fetch BSC gas prices
    try {
      const bscResponse = await fetch('https://api.bscscan.com/api?module=gastracker&action=gasoracle');
      const bscData = await bscResponse.json();
      
      if (bscData.status === '1' && bscData.result) {
        const gasPrice = parseInt(bscData.result.ProposeGasPrice || '3');
        const bnbPrice = 300; // Approximate BNB price
        const gasLimit = 21000;
        const feeInBnb = (gasPrice * gasLimit) / 1e9;
        const feeInUsd = feeInBnb * bnbPrice;
        
        fees['BSC'] = {
          fee: `$${feeInUsd.toFixed(3)}-${(feeInUsd * 2).toFixed(3)}`,
          speed: '~15 sec',
          recommended: true,
          gwei: gasPrice,
        };
        console.log('BSC gas:', gasPrice, 'gwei');
      }
    } catch (e) {
      console.log('BSC gas fetch failed:', e);
      fees['BSC'] = { fee: '$0.1-0.5', speed: '~15 sec', recommended: true };
    }

    // Fetch Polygon gas prices
    try {
      const maticResponse = await fetch('https://api.polygonscan.com/api?module=gastracker&action=gasoracle');
      const maticData = await maticResponse.json();
      
      if (maticData.status === '1' && maticData.result) {
        const gasPrice = parseInt(maticData.result.ProposeGasPrice || '30');
        const maticPrice = 0.5; // Approximate MATIC price
        const gasLimit = 21000;
        const feeInMatic = (gasPrice * gasLimit) / 1e9;
        const feeInUsd = feeInMatic * maticPrice;
        
        fees['MATIC'] = {
          fee: `$${feeInUsd.toFixed(4)}-${(feeInUsd * 2).toFixed(4)}`,
          speed: '~2 sec',
          recommended: true,
          gwei: gasPrice,
        };
        console.log('MATIC gas:', gasPrice, 'gwei');
      }
    } catch (e) {
      console.log('MATIC gas fetch failed:', e);
      fees['MATIC'] = { fee: '$0.01-0.1', speed: '~2 sec', recommended: true };
    }

    // Set default fees for other networks (no free API available)
    fees['TRX'] = fees['TRX'] || { fee: '$0.5-1', speed: '~1 min', recommended: true };
    fees['BTC'] = fees['BTC'] || { fee: '$1-5', speed: '~10 min' };
    fees['LTC'] = fees['LTC'] || { fee: '$0.01-0.1', speed: '~2.5 min' };
    fees['DOGE'] = fees['DOGE'] || { fee: '$0.01-0.05', speed: '~1 min' };

    console.log('Returning fees:', JSON.stringify(fees));

    return new Response(
      JSON.stringify({ fees }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Gas fees error:', error);
    
    // Return default fees on error
    return new Response(
      JSON.stringify({
        fees: {
          'ETH': { fee: '$2-15', speed: '~2 min' },
          'TRX': { fee: '$0.5-1', speed: '~1 min', recommended: true },
          'BTC': { fee: '$1-5', speed: '~10 min' },
          'BSC': { fee: '$0.1-0.5', speed: '~15 sec', recommended: true },
          'MATIC': { fee: '$0.01-0.1', speed: '~2 sec', recommended: true },
          'LTC': { fee: '$0.01-0.1', speed: '~2.5 min' },
          'DOGE': { fee: '$0.01-0.05', speed: '~1 min' },
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
