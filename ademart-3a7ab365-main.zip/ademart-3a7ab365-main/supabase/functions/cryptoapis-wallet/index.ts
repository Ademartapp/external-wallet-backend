import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";
import * as bip39 from "https://esm.sh/bip39@3.1.0";
import { HDKey } from "https://esm.sh/@scure/bip32@1.3.3";
import { sha256 } from "https://esm.sh/@noble/hashes@1.3.3/sha256";
import { ripemd160 } from "https://esm.sh/@noble/hashes@1.3.3/ripemd160";
import { bytesToHex, hexToBytes } from "https://esm.sh/@noble/hashes@1.3.3/utils";
import * as secp256k1 from "https://esm.sh/@noble/secp256k1@1.7.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// ==================== SAFE TEST MODE CONFIGURATION ====================
// Production default: OFF. Enable explicitly via backend variable SAFE_TEST_MODE="true".
const SAFE_TEST_MODE = (Deno.env.get('SAFE_TEST_MODE') ?? 'false').toLowerCase() === 'true';

// Withdrawal limits in SAFE_TEST_MODE (very small amounts for testing)
const WITHDRAWAL_LIMITS: Record<string, number> = {
  BTC: 0.0001,    // ~$3-10 USD
  LTC: 0.05,      // ~$3-5 USD
  DOGE: 50,       // ~$5-8 USD
};

// Minimum confirmations required before crediting deposits
const MIN_CONFIRMATIONS: Record<string, number> = {
  bitcoin: 2,
  litecoin: 6,
  dogecoin: 6,
};

// ==================== RATE LIMITING ====================
const rateLimitMap = new Map<string, { count: number; resetTime: number }>();
const RATE_LIMIT_WINDOW = 60000;
const RATE_LIMIT_MAX_WALLET = 10;
const RATE_LIMIT_MAX_BALANCE = 60;
const RATE_LIMIT_MAX_SEND = 5;

function checkRateLimit(key: string, action: string): boolean {
  const now = Date.now();
  const fullKey = `${key}:${action}`;
  const entry = rateLimitMap.get(fullKey);
  
  const maxAllowed = action === 'create_wallet' ? RATE_LIMIT_MAX_WALLET :
                     action === 'send' ? RATE_LIMIT_MAX_SEND :
                     RATE_LIMIT_MAX_BALANCE;
  
  if (!entry || now > entry.resetTime) {
    rateLimitMap.set(fullKey, { count: 1, resetTime: now + RATE_LIMIT_WINDOW });
    return true;
  }
  
  if (entry.count >= maxAllowed) return false;
  entry.count++;
  return true;
}

// ==================== ENVIRONMENT VALIDATION ====================
function validateEnvironment(): { valid: boolean; missing: string[]; warnings: string[] } {
  const required = ['SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY', 'CRYPTOAPIS_API_KEY'];
  const missing: string[] = [];
  const warnings: string[] = [];
  
  for (const key of required) {
    if (!Deno.env.get(key)) missing.push(key);
  }
  
  return { valid: missing.length === 0, missing, warnings };
}

const CRYPTOAPIS_API_KEY = () => Deno.env.get('CRYPTOAPIS_API_KEY') || '';
const CRYPTOAPIS_BASE_URL = 'https://rest.cryptoapis.io';

// ==================== CHAIN CONFIGURATIONS ====================
const CHAIN_CONFIG: Record<string, { 
  path: string;
  blockchain: string; 
  network: string;
  prefix: number[];
  symbol: string;
}> = {
  bitcoin: { 
    path: "m/84'/0'/0'/0/0", 
    blockchain: 'bitcoin', 
    network: 'mainnet',
    prefix: [0x00],
    symbol: 'BTC'
  },
  litecoin: { 
    path: "m/84'/2'/0'/0/0", 
    blockchain: 'litecoin', 
    network: 'mainnet',
    prefix: [0x30],
    symbol: 'LTC'
  },
  dogecoin: { 
    path: "m/44'/3'/0'/0/0", 
    blockchain: 'dogecoin', 
    network: 'mainnet',
    prefix: [0x1e],
    symbol: 'DOGE'
  }
};

// ==================== BASE58 ENCODING ====================
const BASE58_ALPHABET = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';

function base58Encode(bytes: Uint8Array): string {
  const digits = [0];
  for (const byte of bytes) {
    let carry = byte;
    for (let j = 0; j < digits.length; j++) {
      carry += digits[j] * 256;
      digits[j] = carry % 58;
      carry = Math.floor(carry / 58);
    }
    while (carry > 0) {
      digits.push(carry % 58);
      carry = Math.floor(carry / 58);
    }
  }
  for (const byte of bytes) {
    if (byte === 0) digits.push(0);
    else break;
  }
  return digits.reverse().map(d => BASE58_ALPHABET[d]).join('');
}

function base58CheckEncode(payload: Uint8Array): string {
  const checksum = sha256(sha256(payload)).slice(0, 4);
  const combined = new Uint8Array(payload.length + 4);
  combined.set(payload);
  combined.set(checksum, payload.length);
  return base58Encode(combined);
}

// ==================== ADDRESS DERIVATION ====================
function deriveBtcAddress(publicKey: Uint8Array, prefix: number[]): string {
  const sha256Hash = sha256(publicKey);
  const ripemdHash = ripemd160(sha256Hash);
  const payload = new Uint8Array(prefix.length + ripemdHash.length);
  payload.set(prefix);
  payload.set(ripemdHash, prefix.length);
  return base58CheckEncode(payload);
}

// ==================== WALLET GENERATION ====================
async function generateWallet(mnemonic: string, chain: string): Promise<{ address: string; privateKey: string; publicKey: string }> {
  const config = CHAIN_CONFIG[chain];
  if (!config) throw new Error(`Unsupported chain: ${chain}`);

  const seed = await bip39.mnemonicToSeed(mnemonic);
  const hdKey = HDKey.fromMasterSeed(seed);
  const derived = hdKey.derive(config.path);
  
  if (!derived.privateKey || !derived.publicKey) {
    throw new Error('Failed to derive keys');
  }
  
  const privateKey = bytesToHex(derived.privateKey);
  const publicKey = bytesToHex(derived.publicKey);
  const address = deriveBtcAddress(derived.publicKey, config.prefix);
  
  return { address, privateKey, publicKey };
}

// Get or create mnemonic for user (NEVER exposed to frontend)
async function getOrCreateMnemonic(supabase: any, userId: string): Promise<string> {
  const { data: existing } = await supabase
    .from('user_wallet_secrets')
    .select('mnemonic_encrypted')
    .eq('user_id', userId)
    .maybeSingle();

  if (existing?.mnemonic_encrypted) {
    return existing.mnemonic_encrypted;
  }

  const mnemonic = bip39.generateMnemonic();
  
  await supabase.from('user_wallet_secrets').insert({
    user_id: userId,
    mnemonic_encrypted: mnemonic,
  });

  return mnemonic;
}

// ==================== CRYPTOAPIS REQUEST HELPER ====================
async function cryptoApiRequest(endpoint: string, method = 'GET', body?: unknown) {
  const apiKey = CRYPTOAPIS_API_KEY();
  if (!apiKey) throw new Error('CRYPTOAPIS_API_KEY not configured');

  const url = `${CRYPTOAPIS_BASE_URL}${endpoint}`;
  
  const response = await fetch(url, {
    method,
    headers: {
      'Content-Type': 'application/json',
      'X-API-Key': apiKey
    },
    body: body ? JSON.stringify(body) : undefined
  });
  
  const data = await response.json();
  
  if (!response.ok) {
    console.error('[CryptoAPIs] Error:', data);
    throw new Error(data.error?.message || `API error: ${response.status}`);
  }
  
  return data;
}

// ==================== ON-CHAIN BALANCE QUERIES (SOURCE OF TRUTH) ====================
async function getBalance(address: string, chain: string): Promise<string> {
  const config = CHAIN_CONFIG[chain];
  if (!config) throw new Error(`Unsupported chain: ${chain}`);
  
  try {
    const response = await cryptoApiRequest(
      `/blockchain-data/${config.blockchain}/${config.network}/addresses/${address}/balance`
    );
    
    return response.data?.item?.confirmedBalance?.amount || '0';
  } catch (error) {
    console.error(`[CryptoAPIs] Balance error for ${address?.substring(0, 10)}...`);
    return '0';
  }
}

// ==================== UTXO & FEE QUERIES ====================
async function getUtxos(address: string, chain: string): Promise<any[]> {
  const config = CHAIN_CONFIG[chain];
  if (!config) throw new Error(`Unsupported chain: ${chain}`);
  
  try {
    const response = await cryptoApiRequest(
      `/blockchain-data/${config.blockchain}/${config.network}/addresses/${address}/unspent-outputs?limit=50`
    );
    
    return response.data?.items || [];
  } catch (error) {
    console.error(`[CryptoAPIs] UTXO error`);
    return [];
  }
}

async function getFeeEstimate(chain: string): Promise<{ slow: string; standard: string; fast: string }> {
  const config = CHAIN_CONFIG[chain];
  if (!config) throw new Error(`Unsupported chain: ${chain}`);
  
  try {
    const response = await cryptoApiRequest(
      `/blockchain-data/${config.blockchain}/${config.network}/mempool/fees`
    );
    
    return {
      slow: response.data?.item?.slow || '0.00001',
      standard: response.data?.item?.standard || '0.00005',
      fast: response.data?.item?.fast || '0.0001'
    };
  } catch (error) {
    console.error(`[CryptoAPIs] Fee estimate error`);
    return { slow: '0.00001', standard: '0.00005', fast: '0.0001' };
  }
}

// ==================== CRYPTOAPIS WEBHOOK REGISTRATION ====================
async function registerCryptoApisWebhook(address: string, chain: string): Promise<{ success: boolean; error?: string }> {
  const config = CHAIN_CONFIG[chain];
  if (!config) return { success: false, error: `Unsupported chain: ${chain}` };
  
  const supabaseUrl = Deno.env.get('SUPABASE_URL');
  const callbackUrl = `${supabaseUrl}/functions/v1/cryptoapis-webhook`;
  const minConf = MIN_CONFIRMATIONS[chain] || 3;
  
  try {
    // Register for confirmed transactions
    await cryptoApiRequest(
      `/blockchain-events/${config.blockchain}/${config.network}/subscriptions/address-coins-transactions-confirmed`,
      'POST',
      {
        data: {
          item: {
            address,
            callbackUrl,
            confirmationsCount: minConf
          }
        }
      }
    );
    
    // Also register for unconfirmed (to show pending)
    await cryptoApiRequest(
      `/blockchain-events/${config.blockchain}/${config.network}/subscriptions/address-coins-transactions-unconfirmed`,
      'POST',
      {
        data: {
          item: {
            address,
            callbackUrl
          }
        }
      }
    );
    
    console.log(`[CryptoAPIs] Registered webhooks for ${address?.substring(0, 10)}...`);
    return { success: true };
  } catch (error) {
    console.error('[CryptoAPIs] Webhook registration error');
    return { success: false, error: 'Webhook registration failed' };
  }
}

// ==================== TRANSACTION SENDING (SERVER-SIDE ONLY) ====================
async function createAndSignTransaction(
  supabase: any,
  userId: string,
  chain: string,
  toAddress: string,
  amount: string,
  feeLevel: 'slow' | 'standard' | 'fast' = 'standard'
): Promise<{ success: boolean; txHash?: string; error?: string }> {
  try {
    const config = CHAIN_CONFIG[chain];
    if (!config) throw new Error(`Unsupported chain: ${chain}`);

    // SAFE_TEST_MODE: Enforce withdrawal limits
    if (SAFE_TEST_MODE) {
      const limit = WITHDRAWAL_LIMITS[config.symbol] || 0.0001;
      const numAmount = parseFloat(amount);
      if (numAmount > limit) {
        return { 
          success: false, 
          error: `SAFE_TEST_MODE: Maximum withdrawal is ${limit} ${config.symbol}. Requested: ${numAmount}` 
        };
      }
    }

    // Get mnemonic and derive wallet (server-side only)
    const mnemonic = await getOrCreateMnemonic(supabase, userId);
    const wallet = await generateWallet(mnemonic, chain);
    
    // Get UTXOs
    const utxos = await getUtxos(wallet.address, chain);
    if (utxos.length === 0) {
      return { success: false, error: 'No confirmed UTXOs available' };
    }

    // Get fee estimate
    const fees = await getFeeEstimate(chain);
    const feeRate = parseFloat(fees[feeLevel]);
    
    const amountSatoshis = Math.floor(parseFloat(amount) * 1e8);
    const estimatedSize = 250;
    const feeSatoshis = Math.floor(feeRate * 1e8 * estimatedSize / 1000);
    const totalNeeded = amountSatoshis + feeSatoshis;

    // Select UTXOs
    let totalInput = 0;
    const selectedUtxos: any[] = [];
    
    for (const utxo of utxos) {
      selectedUtxos.push(utxo);
      totalInput += Math.floor(parseFloat(utxo.amount) * 1e8);
      if (totalInput >= totalNeeded) break;
    }

    if (totalInput < totalNeeded) {
      return { success: false, error: `Insufficient confirmed funds. Need ${totalNeeded / 1e8}, have ${totalInput / 1e8}` };
    }

    const change = totalInput - totalNeeded;

    // Prepare outputs
    const outputs = [{
      address: toAddress,
      amount: (amountSatoshis / 1e8).toFixed(8)
    }];

    if (change > 1000) {
      outputs.push({
        address: wallet.address,
        amount: (change / 1e8).toFixed(8)
      });
    }

    // Use CryptoAPIs to prepare and sign
    const prepareResponse = await cryptoApiRequest(
      `/wallet-as-a-service/${config.blockchain}/${config.network}/transactions/prepare-utxo-transaction`,
      'POST',
      {
        data: {
          item: {
            fee: {
              exactAmount: (feeSatoshis / 1e8).toFixed(8)
            },
            recipients: outputs,
            senders: [{
              address: wallet.address,
              privateKey: wallet.privateKey
            }]
          }
        }
      }
    );

    const signedTxHex = prepareResponse.data?.item?.signedTransactionHex;
    if (!signedTxHex) {
      return { success: false, error: 'Failed to sign transaction' };
    }

    // Broadcast transaction
    const broadcastResponse = await cryptoApiRequest(
      `/blockchain-tools/${config.blockchain}/${config.network}/transactions/broadcast`,
      'POST',
      {
        data: {
          item: {
            signedTransactionHex: signedTxHex
          }
        }
      }
    );

    const txHash = broadcastResponse.data?.item?.transactionId;
    if (!txHash) {
      return { success: false, error: 'Failed to broadcast transaction' };
    }

    console.log(`[CryptoAPIs] Transaction broadcast: ${txHash?.substring(0, 20)}...`);
    return { success: true, txHash };

  } catch (error) {
    console.error('[CryptoAPIs] Send error');
    return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
  }
}

// ==================== MAIN HANDLER ====================
serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const envCheck = validateEnvironment();
  if (!envCheck.valid) {
    return new Response(JSON.stringify({
      success: false,
      error: `Missing required environment variables: ${envCheck.missing.join(', ')}`
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { action, userId, chain, toAddress, amount, feeLevel } = await req.json();
    const config = CHAIN_CONFIG[chain];
    const symbol = config?.symbol || chain?.toUpperCase();
    
    // Rate limiting
    const rateLimitKey = userId || req.headers.get('x-forwarded-for') || 'anonymous';
    if (!checkRateLimit(rateLimitKey, action)) {
      return new Response(JSON.stringify({
        success: false,
        error: 'Rate limit exceeded. Please try again later.'
      }), {
        status: 429,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log(`[CryptoAPIs] Action: ${action}, User: ${userId?.substring(0, 8)}..., Chain: ${chain}`);

    switch (action) {
      case 'create_wallet': {
        if (!userId || !chain) {
          throw new Error('Missing required fields: userId, chain');
        }

        if (!CHAIN_CONFIG[chain]) {
          throw new Error(`Unsupported UTXO chain: ${chain}. Supported: bitcoin, litecoin, dogecoin`);
        }

        const mnemonic = await getOrCreateMnemonic(supabaseClient, userId);
        const wallet = await generateWallet(mnemonic, chain);

        const { data: existingWallet } = await supabaseClient
          .from('wallet_addresses')
          .select('*')
          .eq('user_id', userId)
          .eq('chain', chain)
          .eq('symbol', symbol)
          .maybeSingle();

        if (!existingWallet) {
          await supabaseClient.from('wallet_addresses').insert({
            user_id: userId,
            chain,
            symbol,
            address: wallet.address,
            is_primary: true
          });
          
          // Register webhook for deposits (non-blocking)
          registerCryptoApisWebhook(wallet.address, chain).catch(() => {});
          
          console.log(`[CryptoAPIs] Created wallet: ${wallet.address.substring(0, 10)}...`);
        }

        return new Response(JSON.stringify({
          success: true,
          address: existingWallet?.address || wallet.address,
          chain,
          symbol
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      case 'get_balance': {
        if (!userId || !chain) {
          throw new Error('Missing required fields');
        }

        const { data: wallet } = await supabaseClient
          .from('wallet_addresses')
          .select('address')
          .eq('user_id', userId)
          .eq('chain', chain)
          .eq('symbol', symbol)
          .maybeSingle();

        if (!wallet) {
          return new Response(JSON.stringify({
            success: true,
            balance: '0',
            address: null
          }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
          });
        }

        // ALWAYS fetch from blockchain (source of truth)
        const balance = await getBalance(wallet.address, chain);

        return new Response(JSON.stringify({
          success: true,
          balance,
          address: wallet.address,
          source: 'blockchain'
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      case 'get_fee_estimate': {
        if (!chain) {
          throw new Error('Missing chain');
        }

        const fees = await getFeeEstimate(chain);

        return new Response(JSON.stringify({
          success: true,
          fees
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      case 'send': {
        if (!userId || !chain || !toAddress || !amount) {
          throw new Error('Missing required fields for send');
        }

        const numAmount = parseFloat(amount);
        if (isNaN(numAmount) || numAmount <= 0) {
          throw new Error('Invalid amount');
        }

        // SAFE_TEST_MODE limit check
        if (SAFE_TEST_MODE) {
          const limit = WITHDRAWAL_LIMITS[symbol] || 0.0001;
          if (numAmount > limit) {
            throw new Error(`SAFE_TEST_MODE active: Maximum withdrawal is ${limit} ${symbol}`);
          }
        }

        // Validate address format
        const cfg = CHAIN_CONFIG[chain];
        if (!cfg) {
          throw new Error(`Unsupported chain: ${chain}`);
        }

        let isValidAddress = false;
        if (chain === 'bitcoin') {
          isValidAddress = /^(1|3|bc1)[a-zA-HJ-NP-Z0-9]{25,62}$/.test(toAddress);
        } else if (chain === 'litecoin') {
          isValidAddress = /^(L|M|ltc1)[a-zA-HJ-NP-Z0-9]{25,62}$/.test(toAddress);
        } else if (chain === 'dogecoin') {
          isValidAddress = /^D[5-9A-HJ-NP-U][1-9A-HJ-NP-Za-km-z]{32}$/.test(toAddress);
        }

        if (!isValidAddress) {
          throw new Error(`Invalid ${chain} address format`);
        }

        // Check CONFIRMED on-chain balance
        const { data: wallet } = await supabaseClient
          .from('wallet_addresses')
          .select('address')
          .eq('user_id', userId)
          .eq('chain', chain)
          .eq('symbol', symbol)
          .maybeSingle();

        if (!wallet) {
          throw new Error('Wallet not found');
        }

        const balance = await getBalance(wallet.address, chain);
        if (parseFloat(balance) < numAmount) {
          throw new Error(`Insufficient confirmed balance. Available: ${balance} ${symbol}`);
        }

        // Generate idempotency key
        const idempotencyKey = `${userId}-${chain}-${symbol}-${toAddress}-${amount}-${Date.now()}`;

        // Record pending transaction BEFORE sending
        const { data: txRecord, error: txError } = await supabaseClient
          .from('transactions')
          .insert({
            user_id: userId,
            type: 'send',
            from_currency: symbol,
            amount: numAmount,
            recipient_address: toAddress,
            status: 'pending',
            idempotency_key: idempotencyKey
          })
          .select()
          .single();

        if (txError) {
          console.error('[CryptoAPIs] Failed to record transaction');
          throw new Error('Failed to initiate transaction');
        }

        // Send transaction (signed server-side)
        const result = await createAndSignTransaction(
          supabaseClient,
          userId,
          chain,
          toAddress,
          amount,
          feeLevel || 'standard'
        );

        // Update transaction with result
        await supabaseClient
          .from('transactions')
          .update({
            status: result.success ? 'pending' : 'failed',
            tx_hash: result.txHash,
            last_error: result.error
          })
          .eq('id', txRecord.id);

        if (!result.success) {
          return new Response(JSON.stringify({
            success: false,
            error: result.error
          }), {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
          });
        }

        return new Response(JSON.stringify({
          success: true,
          txHash: result.txHash,
          chain,
          symbol,
          amount,
          toAddress,
          status: 'pending',
          message: 'Transaction broadcast. Awaiting confirmation.'
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      case 'register_webhook': {
        if (!userId || !chain) {
          throw new Error('Missing required fields');
        }

        const { data: wallet } = await supabaseClient
          .from('wallet_addresses')
          .select('address')
          .eq('user_id', userId)
          .eq('chain', chain)
          .maybeSingle();

        if (!wallet) {
          throw new Error('Wallet not found');
        }

        const result = await registerCryptoApisWebhook(wallet.address, chain);

        return new Response(JSON.stringify({
          success: result.success,
          error: result.error
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      case 'get_config': {
        return new Response(JSON.stringify({
          success: true,
          safeTestMode: SAFE_TEST_MODE,
          withdrawalLimits: WITHDRAWAL_LIMITS,
          minConfirmations: MIN_CONFIRMATIONS,
          supportedChains: Object.keys(CHAIN_CONFIG)
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      case 'sanity_test': {
        if (!userId) {
          throw new Error('Missing userId for sanity test');
        }

        const testChain = chain || 'bitcoin';

        const mnemonic = await getOrCreateMnemonic(supabaseClient, userId);
        const wallet = await generateWallet(mnemonic, testChain);
        const balance = await getBalance(wallet.address, testChain);
        const fees = await getFeeEstimate(testChain);

        return new Response(JSON.stringify({
          success: true,
          test: 'sanity_check',
          wallet: {
            address: wallet.address,
            chain: testChain,
            symbol: CHAIN_CONFIG[testChain]?.symbol
          },
          balance,
          fees,
          safeTestMode: SAFE_TEST_MODE,
          apiConfigured: !!CRYPTOAPIS_API_KEY()
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      default:
        throw new Error(`Unknown action: ${action}`);
    }
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('[CryptoAPIs] Error:', errorMessage);
    return new Response(JSON.stringify({
      success: false,
      error: errorMessage
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
