import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-cron-secret",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

// RPC endpoints for balance lookups
const RPC_ENDPOINTS: Record<string, string> = {
  ETH: "https://eth.llamarpc.com",
  BSC: "https://bsc-dataseed.binance.org",
  MATIC: "https://polygon-rpc.com",
};

const TRON_API = "https://api.trongrid.io";

// Block explorer API endpoints (free tier)
const EXPLORER_APIS: Record<string, { url: string; apiKey?: string }> = {
  BTC: { url: "https://blockchain.info/q/addressbalance/" },
  LTC: { url: "https://api.blockcypher.com/v1/ltc/main/addrs/" },
  DOGE: { url: "https://api.blockcypher.com/v1/doge/main/addrs/" },
  TRX: { url: "https://apilist.tronscan.org/api/account?address=" },
};

// TRC20 Token contract addresses
const TRC20_TOKENS: Record<string, string> = {
  USDT: "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t",
  USDC: "TEkxiTehnzSmSe2XqrBj4w32RUN966rdz8",
};

// ERC20 Token contract addresses  
const ERC20_TOKENS: Record<string, string> = {
  USDT: "0xdAC17F958D2ee523a2206206994597C13D831ec7",
  USDC: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
};

const CRON_SECRET = Deno.env.get("ONCHAIN_CRON_SECRET") || "";

// Check TRON transaction status
async function checkTronTransaction(txHash: string): Promise<{ confirmed: boolean; success: boolean }> {
  try {
    const res = await fetch(`${TRON_API}/walletsolidity/gettransactioninfobyid`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ value: txHash }),
    });
    const data = await res.json();
    
    if (!data.id) {
      return { confirmed: false, success: false };
    }
    
    if (data.receipt) {
      const success = data.receipt.result === "SUCCESS" || !data.receipt.result;
      return { confirmed: true, success };
    }
    
    return { confirmed: false, success: false };
  } catch (error) {
    console.error("Error checking TRON tx:", error);
    return { confirmed: false, success: false };
  }
}

// Check EVM transaction status
async function checkEvmTransaction(txHash: string, chain: string): Promise<{ confirmed: boolean; success: boolean }> {
  const rpc = RPC_ENDPOINTS[chain];
  if (!rpc) return { confirmed: false, success: false };
  
  try {
    const res = await fetch(rpc, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        jsonrpc: "2.0",
        id: 1,
        method: "eth_getTransactionReceipt",
        params: [txHash],
      }),
    });
    const data = await res.json();
    
    if (!data.result) {
      return { confirmed: false, success: false };
    }
    
    const receipt = data.result;
    const success = receipt.status === "0x1";
    return { confirmed: true, success };
  } catch (error) {
    console.error(`Error checking ${chain} tx:`, error);
    return { confirmed: false, success: false };
  }
}

// Fetch EVM balance via JSON-RPC
async function getEvmBalance(address: string, chain: string): Promise<number> {
  const rpc = RPC_ENDPOINTS[chain];
  if (!rpc) return 0;

  try {
    const res = await fetch(rpc, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        jsonrpc: "2.0",
        id: 1,
        method: "eth_getBalance",
        params: [address, "latest"],
      }),
    });

    const data = await res.json();
    if (data.result) {
      const wei = parseInt(data.result, 16);
      return wei / 1e18;
    }
  } catch (e) {
    console.error(`EVM balance error for ${chain}:`, e);
  }
  return 0;
}

// Fetch ERC20 token balance via JSON-RPC
async function getErc20Balance(address: string, chain: string, tokenSymbol: string): Promise<number> {
  const rpc = RPC_ENDPOINTS[chain];
  const tokenAddress = ERC20_TOKENS[tokenSymbol];
  if (!rpc || !tokenAddress) return 0;

  try {
    const paddedAddress = address.toLowerCase().replace("0x", "").padStart(64, "0");
    const data = `0x70a08231${paddedAddress}`;

    const res = await fetch(rpc, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        jsonrpc: "2.0",
        id: 1,
        method: "eth_call",
        params: [{ to: tokenAddress, data }, "latest"],
      }),
    });

    const result = await res.json();
    if (result.result && result.result !== "0x") {
      const balance = parseInt(result.result, 16);
      return balance / 1e6;
    }
  } catch (e) {
    console.error(`ERC20 balance error for ${tokenSymbol} on ${chain}:`, e);
  }
  return 0;
}

// Fetch BTC balance
async function getBtcBalance(address: string): Promise<number> {
  try {
    const res = await fetch(`${EXPLORER_APIS.BTC.url}${address}`);
    if (!res.ok) return 0;
    const satoshis = parseInt(await res.text(), 10);
    return satoshis / 1e8;
  } catch (e) {
    console.error("BTC balance error:", e);
    return 0;
  }
}

// Fetch LTC/DOGE balance via Blockcypher
async function getBlockcypherBalance(address: string, chain: "LTC" | "DOGE"): Promise<number> {
  try {
    const res = await fetch(`${EXPLORER_APIS[chain].url}${address}/balance`);
    if (!res.ok) return 0;
    const data = await res.json();
    return (data.balance || 0) / 1e8;
  } catch (e) {
    console.error(`${chain} balance error:`, e);
    return 0;
  }
}

// Fetch TRX balance (native)
async function getTrxBalance(address: string): Promise<number> {
  try {
    const res = await fetch(`${EXPLORER_APIS.TRX.url}${address}`);
    if (!res.ok) return 0;
    const data = await res.json();
    return (data.balance || 0) / 1e6;
  } catch (e) {
    console.error("TRX balance error:", e);
    return 0;
  }
}

// Fetch TRC20 token balance
async function getTrc20Balance(address: string, tokenSymbol: string): Promise<number> {
  const tokenContract = TRC20_TOKENS[tokenSymbol];
  if (!tokenContract) return 0;

  try {
    const res = await fetch(`${EXPLORER_APIS.TRX.url}${address}`);
    if (!res.ok) return 0;
    
    const data = await res.json();
    
    if (data.trc20token_balances && Array.isArray(data.trc20token_balances)) {
      for (const token of data.trc20token_balances) {
        if (token.tokenId === tokenContract || token.tokenAbbr === tokenSymbol) {
          const balance = parseInt(token.balance || "0", 10);
          const decimals = token.tokenDecimal || 6;
          return balance / Math.pow(10, decimals);
        }
      }
    }
    return 0;
  } catch (e) {
    console.error(`TRC20 balance error for ${tokenSymbol}:`, e);
    return 0;
  }
}

// Get balance for a specific chain and symbol
async function getOnchainBalance(address: string, chain: string, symbol: string): Promise<number> {
  if (symbol === "USDT" || symbol === "USDC") {
    if (chain === "TRX") {
      return getTrc20Balance(address, symbol);
    } else if (chain === "ETH") {
      return getErc20Balance(address, chain, symbol);
    }
    return 0;
  }

  const nativeCoins: Record<string, string> = {
    BTC: "BTC", ETH: "ETH", BSC: "BNB", MATIC: "MATIC",
    LTC: "LTC", DOGE: "DOGE", TRX: "TRX",
  };

  if (nativeCoins[chain] !== symbol) return 0;

  switch (chain) {
    case "ETH":
    case "BSC":
    case "MATIC":
      return getEvmBalance(address, chain);
    case "BTC":
      return getBtcBalance(address);
    case "LTC":
      return getBlockcypherBalance(address, "LTC");
    case "DOGE":
      return getBlockcypherBalance(address, "DOGE");
    case "TRX":
      return getTrxBalance(address);
    default:
      return 0;
  }
}

// Determine chain from currency
function getChainFromCurrency(currency: string): string {
  const chainMap: Record<string, string> = {
    TRX: "TRX", USDT: "TRX", USDC: "ETH",
    ETH: "ETH", BNB: "BSC", MATIC: "MATIC",
  };
  return chainMap[currency] || "TRX";
}

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !supabaseServiceKey) {
      throw new Error("Missing Supabase configuration");
    }

    const authHeader = req.headers.get("authorization");
    const cronSecret = req.headers.get("x-cron-secret");
    
    // Allow cron calls (via x-cron-secret header) or authenticated user calls
    const isCronCall = cronSecret === "true" || (cronSecret === CRON_SECRET && CRON_SECRET !== "");
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    let user: any = null;
    
    if (!isCronCall) {
      if (!authHeader) {
        return new Response(JSON.stringify({ error: "No authorization" }), {
          status: 401,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      
      const token = authHeader.replace("Bearer ", "");
      const { data: { user: authUser }, error: userError } = await supabase.auth.getUser(token);

      if (userError || !authUser) {
        return new Response(JSON.stringify({ error: "Invalid token" }), {
          status: 401,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      user = authUser;
    }

    const body = await req.json().catch(() => ({}));
    const { action } = body;
    console.log(`Onchain monitor action: ${action}, isCron: ${isCronCall}, user: ${user?.id || 'cron'}`);

    switch (action) {
      case "check_pending_transactions": {
        // Check status of pending transactions (cron job)
        const { data: pendingTxs } = await supabase
          .from("transactions")
          .select("*")
          .eq("status", "pending")
          .in("type", ["send", "deposit"])
          .not("tx_hash", "is", null)
          .not("tx_hash", "like", "bybit_%")
          .not("tx_hash", "like", "onchain_sync_%")
          .order("created_at", { ascending: true })
          .limit(50);

        console.log(`Found ${pendingTxs?.length || 0} pending transactions`);

        const results = { checked: 0, confirmed: 0, failed: 0, pending: 0 };

        for (const tx of pendingTxs || []) {
          results.checked++;
          const chain = getChainFromCurrency(tx.from_currency);
          let status: { confirmed: boolean; success: boolean };
          
          if (chain === "TRX") {
            status = await checkTronTransaction(tx.tx_hash);
          } else if (["ETH", "BSC", "MATIC"].includes(chain)) {
            status = await checkEvmTransaction(tx.tx_hash, chain);
          } else {
            results.pending++;
            continue;
          }

          if (status.confirmed) {
            const newStatus = status.success ? "completed" : "failed";
            
            await supabase
              .from("transactions")
              .update({ 
                status: newStatus,
                error_details: status.success ? null : "Transaction failed on-chain",
              })
              .eq("id", tx.id);

            // Get wallet for reserved balance operations
            const { data: wallet } = await supabase
              .from("wallets")
              .select("id, balance, reserved_balance")
              .eq("user_id", tx.user_id)
              .eq("currency", tx.from_currency)
              .maybeSingle();

            if (status.success) {
              results.confirmed++;
              
              // For sends: confirm reserved balance (just remove from reserved, balance already reduced)
              if (tx.type === "send" && wallet) {
                await supabase.rpc('confirm_reserved_balance', {
                  p_wallet_id: wallet.id,
                  p_amount: tx.amount,
                });
              }
              
              await supabase.from("notifications").insert({
                user_id: tx.user_id,
                type: "transaction_confirmed",
                title: "Transaction Confirmed",
                message: `Your ${tx.amount} ${tx.from_currency} transaction has been confirmed`,
                data: { txHash: tx.tx_hash, amount: tx.amount, currency: tx.from_currency },
              });
            } else {
              results.failed++;
              
              // For sends: release reserved balance (move back to available)
              if (tx.type === "send" && wallet) {
                await supabase.rpc('release_reserved_balance', {
                  p_wallet_id: wallet.id,
                  p_amount: tx.amount,
                });
                
                // Mark as retryable
                await supabase
                  .from("transactions")
                  .update({ 
                    can_retry: true,
                    last_error: "Transaction failed on-chain",
                  })
                  .eq("id", tx.id);
              }
              
              await supabase.from("notifications").insert({
                user_id: tx.user_id,
                type: "transaction_failed",
                title: "Transaction Failed",
                message: `Your ${tx.amount} ${tx.from_currency} transaction failed${tx.type === "send" ? ". Funds released back to your wallet." : ""}`,
                data: { txHash: tx.tx_hash },
              });
            }
          } else {
            results.pending++;
          }
          
          await new Promise(r => setTimeout(r, 100));
        }

        return new Response(JSON.stringify({ success: true, results }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "sync_balances": {
        if (!user) {
          return new Response(JSON.stringify({ error: "User required" }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        const { data: walletAddresses } = await supabase
          .from("wallet_addresses")
          .select("*")
          .eq("user_id", user.id);

        if (!walletAddresses?.length) {
          return new Response(JSON.stringify({
            success: true,
            data: { synced: 0, message: "No wallets to sync" },
          }), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        const results: Array<{ symbol: string; chain: string; balance: number; credited: number }> = [];
        let totalCredited = 0;

        for (const wa of walletAddresses) {
          try {
            const onchainBalance = await getOnchainBalance(wa.address, wa.chain, wa.symbol);

            const { data: wallet } = await supabase
              .from("wallets")
              .select("id, balance")
              .eq("user_id", user.id)
              .eq("currency", wa.symbol)
              .maybeSingle();

            const currentBalance = wallet?.balance || 0;

            if (onchainBalance > currentBalance) {
              const diff = onchainBalance - currentBalance;

              if (wallet) {
                await supabase
                  .from("wallets")
                  .update({ balance: onchainBalance })
                  .eq("id", wallet.id);
              } else {
                await supabase
                  .from("wallets")
                  .upsert({
                    user_id: user.id,
                    currency: wa.symbol,
                    balance: onchainBalance,
                  }, { onConflict: "user_id,currency" });
              }

              await supabase.from("transactions").insert({
                user_id: user.id,
                type: "deposit",
                from_currency: wa.symbol,
                amount: diff,
                status: "completed",
                recipient_address: wa.address,
                tx_hash: `onchain_sync_${Date.now()}_${wa.symbol}`,
              });

              await supabase.from("notifications").insert({
                user_id: user.id,
                title: "Deposit Credited",
                message: `${diff.toFixed(6)} ${wa.symbol} credited from on-chain deposit`,
                type: "deposit",
                data: { amount: diff, currency: wa.symbol },
              });

              results.push({ symbol: wa.symbol, chain: wa.chain, balance: onchainBalance, credited: diff });
              totalCredited += diff;
            } else {
              results.push({ symbol: wa.symbol, chain: wa.chain, balance: onchainBalance, credited: 0 });
            }
          } catch (e) {
            console.error(`Error syncing ${wa.symbol}:`, e);
            results.push({ symbol: wa.symbol, chain: wa.chain, balance: 0, credited: 0 });
          }
        }

        return new Response(JSON.stringify({
          success: true,
          data: { synced: walletAddresses.length, totalCredited, results },
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      default:
        return new Response(JSON.stringify({ error: `Unknown action: ${action}` }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
    }
  } catch (error) {
    console.error("Onchain monitor error:", error);
    return new Response(JSON.stringify({
      error: error instanceof Error ? error.message : "Unknown error",
    }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
