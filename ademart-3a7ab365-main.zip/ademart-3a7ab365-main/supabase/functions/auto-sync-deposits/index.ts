import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

// TRC20 Token contract addresses
const TRC20_TOKENS: Record<string, string> = {
  USDT: "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t",
  USDC: "TEkxiTehnzSmSe2XqrBj4w32RUN966rdz8",
};

// Fetch TRC20 token balance
async function getTrc20Balance(address: string, tokenSymbol: string): Promise<number> {
  const tokenContract = TRC20_TOKENS[tokenSymbol];
  if (!tokenContract) return 0;

  try {
    const res = await fetch(`https://apilist.tronscan.org/api/account?address=${address}`);
    if (!res.ok) return 0;
    
    const data = await res.json();
    
    if (data.trc20token_balances && Array.isArray(data.trc20token_balances)) {
      for (const token of data.trc20token_balances) {
        if (token.tokenId === tokenContract || token.tokenAbbr === tokenSymbol) {
          const balance = parseInt(token.balance || "0", 10);
          const decimals = token.tokenDecimal || 6;
          return balance / Math.pow(10, decimals);
        }
      }
    }
    return 0;
  } catch (e) {
    console.error(`TRC20 balance error for ${tokenSymbol}:`, e);
    return 0;
  }
}

// Fetch ERC20 token balance
async function getErc20Balance(address: string, tokenSymbol: string): Promise<number> {
  const ERC20_TOKENS: Record<string, string> = {
    USDT: "0xdAC17F958D2ee523a2206206994597C13D831ec7",
    USDC: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
  };
  
  const tokenAddress = ERC20_TOKENS[tokenSymbol];
  if (!tokenAddress) return 0;

  try {
    const paddedAddress = address.toLowerCase().replace("0x", "").padStart(64, "0");
    const data = `0x70a08231${paddedAddress}`;

    const res = await fetch("https://eth.llamarpc.com", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        jsonrpc: "2.0",
        id: 1,
        method: "eth_call",
        params: [{ to: tokenAddress, data }, "latest"],
      }),
    });

    const result = await res.json();
    if (result.result && result.result !== "0x") {
      const balance = parseInt(result.result, 16);
      return balance / 1e6; // USDT and USDC have 6 decimals
    }
  } catch (e) {
    console.error(`ERC20 balance error for ${tokenSymbol}:`, e);
  }
  return 0;
}

// Get stablecoin balance
async function getStablecoinBalance(address: string, chain: string, symbol: string): Promise<number> {
  if (symbol === "USDT" || symbol === "USDC") {
    if (chain === "TRX") {
      return getTrc20Balance(address, symbol);
    } else if (chain === "ETH") {
      return getErc20Balance(address, symbol);
    }
  }
  return 0;
}

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const cronSecret = Deno.env.get("ONCHAIN_CRON_SECRET");

    if (!supabaseUrl || !supabaseServiceKey) {
      throw new Error("Missing Supabase configuration");
    }

    // Verify cron secret for scheduled calls
    const authHeader = req.headers.get("authorization");
    const providedSecret = authHeader?.replace("Bearer ", "");
    
    if (providedSecret !== cronSecret && !authHeader?.includes("eyJ")) {
      console.log("Unauthorized cron request");
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    console.log("Starting automatic deposit sync for all users...");

    // Get all stablecoin wallet addresses
    const { data: walletAddresses, error: walletsError } = await supabase
      .from("wallet_addresses")
      .select("*")
      .in("symbol", ["USDT", "USDC"]);

    if (walletsError) {
      throw new Error("Failed to fetch wallet addresses: " + walletsError.message);
    }

    if (!walletAddresses || walletAddresses.length === 0) {
      console.log("No stablecoin wallets to sync");
      return new Response(JSON.stringify({
        success: true,
        data: { synced: 0, credited: 0, message: "No stablecoin wallets found" },
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log(`Found ${walletAddresses.length} stablecoin wallets to sync`);

    let totalCredited = 0;
    let walletsChecked = 0;
    const creditedDeposits: Array<{ userId: string; symbol: string; amount: number }> = [];

    for (const wa of walletAddresses) {
      try {
        const onchainBalance = await getStablecoinBalance(wa.address, wa.chain, wa.symbol);
        walletsChecked++;
        
        if (onchainBalance <= 0) continue;

        console.log(`${wa.symbol}/${wa.chain} for user ${wa.user_id}: ${onchainBalance}`);

        // Get current wallet balance
        const { data: wallet } = await supabase
          .from("wallets")
          .select("id, balance")
          .eq("user_id", wa.user_id)
          .eq("currency", wa.symbol)
          .maybeSingle();

        const currentDbBalance = wallet?.balance || 0;

        // Credit difference if on-chain is higher
        if (onchainBalance > currentDbBalance) {
          const difference = onchainBalance - currentDbBalance;
          console.log(`Crediting ${difference} ${wa.symbol} to user ${wa.user_id}`);

          // Update or create wallet
          if (wallet) {
            await supabase
              .from("wallets")
              .update({ balance: onchainBalance, updated_at: new Date().toISOString() })
              .eq("id", wallet.id);
          } else {
            await supabase
              .from("wallets")
              .upsert({
                user_id: wa.user_id,
                currency: wa.symbol,
                balance: onchainBalance,
              }, { onConflict: "user_id,currency" });
          }

          // Record transaction
          await supabase
            .from("transactions")
            .insert({
              user_id: wa.user_id,
              type: "receive",
              from_currency: wa.symbol,
              amount: difference,
              status: "completed",
              recipient_address: wa.address,
              tx_hash: `auto_sync_${Date.now()}_${wa.symbol}_${wa.chain}`,
            });

          // Create notification
          await supabase
            .from("notifications")
            .insert({
              user_id: wa.user_id,
              title: "Deposit Credited",
              message: `${difference.toFixed(6)} ${wa.symbol} (${wa.chain}) has been credited from on-chain deposit.`,
              type: "deposit",
              data: {
                amount: difference,
                currency: wa.symbol,
                chain: wa.chain,
                address: wa.address,
              },
            });

          creditedDeposits.push({ userId: wa.user_id, symbol: wa.symbol, amount: difference });
          totalCredited += difference;
        }
      } catch (walletError) {
        console.error(`Error syncing ${wa.symbol}/${wa.chain} for user ${wa.user_id}:`, walletError);
      }

      // Small delay to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 200));
    }

    console.log(`Auto-sync complete: checked ${walletsChecked} wallets, credited ${creditedDeposits.length} deposits totaling ${totalCredited}`);

    return new Response(JSON.stringify({
      success: true,
      data: {
        walletsChecked,
        depositsFound: creditedDeposits.length,
        totalCredited,
        creditedDeposits,
        syncedAt: new Date().toISOString(),
      },
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error("Auto-sync error:", error);
    return new Response(JSON.stringify({
      error: error instanceof Error ? error.message : "Unknown error",
    }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
