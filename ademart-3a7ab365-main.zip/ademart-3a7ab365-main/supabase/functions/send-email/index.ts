import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");

// Allowed origins for CORS - restrict to known domains
const allowedOrigins = [
  "https://tvcowgddpcnmlssrnvgx.lovableproject.com",
  "https://preview--tvcowgddpcnmlssrnvgx.lovable.app",
  "http://localhost:5173",
  "http://localhost:3000",
];

function getCorsHeaders(requestOrigin: string | null): Record<string, string> {
  // Check if origin matches any allowed pattern
  const isAllowed = requestOrigin && (
    allowedOrigins.some(o => requestOrigin.startsWith(o.replace(/\/$/, ''))) ||
    requestOrigin.includes('.lovableproject.com') ||
    requestOrigin.includes('.lovable.app')
  );

  const origin = isAllowed ? requestOrigin : allowedOrigins[0];

  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Credentials": "true",
  };
}

interface EmailRequest {
  type: 'transaction_sent' | 'transaction_received' | 'wallet_created' | 'welcome' | 'admin_deposit_alert' | 'admin_withdrawal_alert' | 'deposit_received' | 'payout_completed' | 'payout_failed' | 'order_cancelled' | 'buy_order_placed' | 'buy_order_completed' | 'buy_order_cancelled' | 'retry_success' | 'retry_failed';
  to: string;
  data: {
    amount?: string;
    symbol?: string;
    txHash?: string;
    recipientAddress?: string;
    senderAddress?: string;
    walletAddress?: string;
    chain?: string;
    username?: string;
    userEmail?: string;
    fee?: string;
    netAmount?: string;
    ngnAmount?: string;
    payoutMethod?: string;
    accountName?: string;
    reason?: string;
    cryptoAmount?: string;
    retryCount?: number;
    errorMessage?: string;
  };
}

async function sendEmail(to: string, subject: string, html: string) {
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${RESEND_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from: "CryptoWallet <onboarding@resend.dev>",
      to: [to],
      subject,
      html,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Failed to send email: ${error}`);
  }

  return await response.json();
}

serve(async (req: Request): Promise<Response> => {
  const origin = req.headers.get("origin");
  const corsHeaders = getCorsHeaders(origin);

  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: req.headers.get('Authorization')! } } }
    );

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser();
    if (authError || !user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { type, to, data }: EmailRequest = await req.json();
    
    let subject = '';
    let html = '';

    switch (type) {
      case 'transaction_sent':
        subject = `Transaction Sent: ${data.amount} ${data.symbol}`;
        html = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h1 style="color: #10b981;">Transaction Sent Successfully!</h1>
            <div style="background: #f3f4f6; border-radius: 8px; padding: 20px; margin: 20px 0;">
              <p style="margin: 10px 0;"><strong>Amount:</strong> ${data.amount} ${data.symbol}</p>
              <p style="margin: 10px 0;"><strong>To:</strong> ${data.recipientAddress}</p>
              ${data.txHash ? `<p style="margin: 10px 0;"><strong>TX Hash:</strong> ${data.txHash}</p>` : ''}
            </div>
            <p style="color: #6b7280; font-size: 12px;">This is an automated notification from your crypto wallet.</p>
          </div>
        `;
        break;

      case 'transaction_received':
        subject = `Transaction Received: ${data.amount} ${data.symbol}`;
        html = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h1 style="color: #10b981;">You Received Crypto!</h1>
            <div style="background: #f3f4f6; border-radius: 8px; padding: 20px; margin: 20px 0;">
              <p style="margin: 10px 0;"><strong>Amount:</strong> ${data.amount} ${data.symbol}</p>
              <p style="margin: 10px 0;"><strong>From:</strong> ${data.senderAddress}</p>
              ${data.txHash ? `<p style="margin: 10px 0;"><strong>TX Hash:</strong> ${data.txHash}</p>` : ''}
            </div>
            <p style="color: #6b7280; font-size: 12px;">This is an automated notification from your crypto wallet.</p>
          </div>
        `;
        break;

      case 'wallet_created':
        subject = `New ${data.symbol} Wallet Created`;
        html = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h1 style="color: #3b82f6;">New Wallet Created!</h1>
            <div style="background: #f3f4f6; border-radius: 8px; padding: 20px; margin: 20px 0;">
              <p style="margin: 10px 0;"><strong>Chain:</strong> ${data.chain}</p>
              <p style="margin: 10px 0;"><strong>Symbol:</strong> ${data.symbol}</p>
              <p style="margin: 10px 0;"><strong>Address:</strong> ${data.walletAddress}</p>
            </div>
            <p style="color: #dc2626; font-size: 14px;"><strong>Important:</strong> Make sure to securely back up your recovery phrase!</p>
          </div>
        `;
        break;

      case 'admin_deposit_alert':
        subject = `🔔 New Deposit: ${data.amount} ${data.symbol}`;
        html = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h1 style="color: #10b981;">💰 New Deposit Received!</h1>
            <div style="background: #ecfdf5; border-radius: 8px; padding: 20px; margin: 20px 0; border-left: 4px solid #10b981;">
              <p style="margin: 10px 0;"><strong>User:</strong> ${data.userEmail || 'Unknown'}</p>
              <p style="margin: 10px 0;"><strong>Amount:</strong> ${data.amount} ${data.symbol}</p>
              <p style="margin: 10px 0;"><strong>Fee Collected:</strong> ${data.fee} ${data.symbol}</p>
              <p style="margin: 10px 0;"><strong>Net to User:</strong> ${data.netAmount} ${data.symbol}</p>
              ${data.txHash ? `<p style="margin: 10px 0;"><strong>TX Hash:</strong> ${data.txHash}</p>` : ''}
            </div>
            <p style="color: #6b7280; font-size: 12px;">This is an automated admin notification from Ade Mart.</p>
          </div>
        `;
        break;

      case 'admin_withdrawal_alert':
        subject = `🔔 New Withdrawal: ${data.amount} ${data.symbol}`;
        html = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h1 style="color: #f59e0b;">📤 New Withdrawal Request!</h1>
            <div style="background: #fffbeb; border-radius: 8px; padding: 20px; margin: 20px 0; border-left: 4px solid #f59e0b;">
              <p style="margin: 10px 0;"><strong>User:</strong> ${data.userEmail || 'Unknown'}</p>
              <p style="margin: 10px 0;"><strong>Amount:</strong> ${data.amount} ${data.symbol}</p>
              <p style="margin: 10px 0;"><strong>Fee Collected:</strong> ${data.fee} ${data.symbol}</p>
              <p style="margin: 10px 0;"><strong>To Address:</strong> ${data.recipientAddress}</p>
              ${data.txHash ? `<p style="margin: 10px 0;"><strong>TX Hash:</strong> ${data.txHash}</p>` : ''}
            </div>
            <p style="color: #6b7280; font-size: 12px;">This is an automated admin notification from Ade Mart.</p>
          </div>
        `;
        break;

      case 'deposit_received':
        subject = `💰 Deposit Received: ${data.amount} ${data.symbol}`;
        html = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h1 style="color: #10b981;">💰 Deposit Received!</h1>
            <div style="background: #ecfdf5; border-radius: 8px; padding: 20px; margin: 20px 0; border-left: 4px solid #10b981;">
              <p style="margin: 10px 0;"><strong>Amount:</strong> ${data.amount} ${data.symbol}</p>
              ${data.txHash ? `<p style="margin: 10px 0;"><strong>TX Hash:</strong> ${data.txHash}</p>` : ''}
            </div>
            <p>Your deposit has been credited to your wallet. You can now use your funds!</p>
            <p style="color: #6b7280; font-size: 12px;">This is an automated notification from your crypto wallet.</p>
          </div>
        `;
        break;

      case 'welcome':
        subject = 'Welcome to Ade Mart!';
        html = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h1 style="color: #8b5cf6;">Welcome to Ade Mart!</h1>
            <p>Hi ${data.username || 'there'},</p>
            <p>Your account has been created successfully. You can now:</p>
            <ul>
              <li>Create wallets for Bitcoin, Ethereum, TRON, and more</li>
              <li>Send and receive crypto using wallet addresses or @CryptoTags</li>
              <li>Track your portfolio in real-time</li>
            </ul>
            <p>Get started by creating your first wallet!</p>
          </div>
        `;
        break;

      case 'payout_completed':
        subject = `✅ Payout Complete: ₦${data.ngnAmount}`;
        html = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h1 style="color: #10b981;">🎉 Payout Complete!</h1>
            <div style="background: #ecfdf5; border-radius: 8px; padding: 20px; margin: 20px 0; border-left: 4px solid #10b981;">
              <p style="margin: 10px 0;"><strong>Amount Sold:</strong> ${data.amount} ${data.symbol}</p>
              <p style="margin: 10px 0;"><strong>Naira Received:</strong> ₦${data.ngnAmount}</p>
              <p style="margin: 10px 0;"><strong>Payout Method:</strong> ${data.payoutMethod}</p>
              <p style="margin: 10px 0;"><strong>Recipient:</strong> ${data.accountName}</p>
            </div>
            <p>Your funds have been sent to your account. It may take a few minutes to reflect.</p>
            <p style="color: #6b7280; font-size: 12px;">This is an automated notification from Ade Mart.</p>
          </div>
        `;
        break;

      case 'payout_failed':
        subject = `❌ Payout Failed: ${data.amount} ${data.symbol}`;
        html = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h1 style="color: #ef4444;">Payout Failed</h1>
            <div style="background: #fef2f2; border-radius: 8px; padding: 20px; margin: 20px 0; border-left: 4px solid #ef4444;">
              <p style="margin: 10px 0;"><strong>Amount:</strong> ${data.amount} ${data.symbol}</p>
              ${data.reason ? `<p style="margin: 10px 0;"><strong>Reason:</strong> ${data.reason}</p>` : ''}
            </div>
            <p>Your crypto has been returned to your wallet. Please try again or contact support.</p>
            <p style="color: #6b7280; font-size: 12px;">This is an automated notification from Ade Mart.</p>
          </div>
        `;
        break;

      case 'order_cancelled':
        subject = `🚫 Sell Order Cancelled: ${data.amount} ${data.symbol}`;
        html = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h1 style="color: #6b7280;">Sell Order Cancelled</h1>
            <div style="background: #f3f4f6; border-radius: 8px; padding: 20px; margin: 20px 0;">
              <p style="margin: 10px 0;"><strong>Amount:</strong> ${data.amount} ${data.symbol}</p>
            </div>
            <p>Your sell order has been cancelled. Your crypto has been returned to your wallet.</p>
            <p style="color: #6b7280; font-size: 12px;">This is an automated notification from Ade Mart.</p>
          </div>
        `;
        break;

      case 'buy_order_placed':
        subject = `🛒 Buy Order Placed: ${data.cryptoAmount} ${data.symbol}`;
        html = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h1 style="color: #6366f1;">Buy Order Placed!</h1>
            <div style="background: #eef2ff; border-radius: 8px; padding: 20px; margin: 20px 0; border-left: 4px solid #6366f1;">
              <p style="margin: 10px 0;"><strong>Crypto:</strong> ${data.cryptoAmount} ${data.symbol}</p>
              <p style="margin: 10px 0;"><strong>Amount Paid:</strong> ₦${data.ngnAmount}</p>
              <p style="margin: 10px 0;"><strong>Payment Method:</strong> ${data.payoutMethod}</p>
            </div>
            <p>Your buy order is being processed. You will be notified once the crypto is credited to your wallet.</p>
            <p style="color: #6b7280; font-size: 12px;">This is an automated notification from Ade Mart.</p>
          </div>
        `;
        break;

      case 'buy_order_completed':
        subject = `✅ Buy Order Completed: ${data.cryptoAmount} ${data.symbol}`;
        html = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h1 style="color: #10b981;">🎉 Buy Order Completed!</h1>
            <div style="background: #ecfdf5; border-radius: 8px; padding: 20px; margin: 20px 0; border-left: 4px solid #10b981;">
              <p style="margin: 10px 0;"><strong>Crypto Received:</strong> ${data.cryptoAmount} ${data.symbol}</p>
              <p style="margin: 10px 0;"><strong>Amount Paid:</strong> ₦${data.ngnAmount}</p>
            </div>
            <p>Your crypto has been credited to your wallet. Happy trading!</p>
            <p style="color: #6b7280; font-size: 12px;">This is an automated notification from Ade Mart.</p>
          </div>
        `;
        break;

      case 'buy_order_cancelled':
        subject = `🚫 Buy Order Cancelled: ${data.cryptoAmount} ${data.symbol}`;
        html = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h1 style="color: #6b7280;">Buy Order Cancelled</h1>
            <div style="background: #f3f4f6; border-radius: 8px; padding: 20px; margin: 20px 0;">
              <p style="margin: 10px 0;"><strong>Crypto:</strong> ${data.cryptoAmount} ${data.symbol}</p>
              <p style="margin: 10px 0;"><strong>Amount:</strong> ₦${data.ngnAmount}</p>
            </div>
            <p>Your buy order has been cancelled. If you were charged, your refund will be processed shortly.</p>
            <p style="color: #6b7280; font-size: 12px;">This is an automated notification from Ade Mart.</p>
          </div>
        `;
        break;

      case 'retry_success':
        subject = `✅ Transaction Retry Successful: ${data.amount} ${data.symbol}`;
        html = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h1 style="color: #10b981;">🎉 Transaction Retry Successful!</h1>
            <div style="background: #ecfdf5; border-radius: 8px; padding: 20px; margin: 20px 0; border-left: 4px solid #10b981;">
              <p style="margin: 10px 0;"><strong>Amount:</strong> ${data.amount} ${data.symbol}</p>
              <p style="margin: 10px 0;"><strong>To:</strong> ${data.recipientAddress}</p>
              ${data.txHash ? `<p style="margin: 10px 0;"><strong>New TX Hash:</strong> ${data.txHash}</p>` : ''}
              <p style="margin: 10px 0;"><strong>Retry Attempt:</strong> #${data.retryCount || 1}</p>
            </div>
            <p>Your previously failed transaction has been successfully re-sent and is now being processed.</p>
            <p style="color: #6b7280; font-size: 12px;">This is an automated notification from Ade Mart.</p>
          </div>
        `;
        break;

      case 'retry_failed':
        subject = `❌ Transaction Retry Failed: ${data.amount} ${data.symbol}`;
        html = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h1 style="color: #ef4444;">Transaction Retry Failed</h1>
            <div style="background: #fef2f2; border-radius: 8px; padding: 20px; margin: 20px 0; border-left: 4px solid #ef4444;">
              <p style="margin: 10px 0;"><strong>Amount:</strong> ${data.amount} ${data.symbol}</p>
              <p style="margin: 10px 0;"><strong>To:</strong> ${data.recipientAddress}</p>
              <p style="margin: 10px 0;"><strong>Retry Attempt:</strong> #${data.retryCount || 1}</p>
              ${data.errorMessage ? `<p style="margin: 10px 0;"><strong>Error:</strong> ${data.errorMessage}</p>` : ''}
            </div>
            <p>Your transaction retry has failed. ${(data.retryCount || 0) >= 3 ? 'Maximum retry attempts reached. Please try again manually from the app.' : 'We will automatically try again shortly.'}</p>
            <p style="color: #6b7280; font-size: 12px;">This is an automated notification from Ade Mart.</p>
          </div>
        `;
        break;

      default:
        throw new Error(`Unknown email type: ${type}`);
    }

    console.log(`Sending ${type} email to ${to}`);
    const emailResponse = await sendEmail(to, subject, html);
    console.log("Email sent successfully:", emailResponse);

    return new Response(JSON.stringify(emailResponse), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: unknown) {
    console.error("Error in send-email function:", error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
});
