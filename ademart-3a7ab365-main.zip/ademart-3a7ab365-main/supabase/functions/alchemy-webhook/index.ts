import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Minimum confirmations required before crediting balance
const MIN_CONFIRMATIONS: Record<string, number> = {
  ethereum: 12,
  polygon: 128,
  bsc: 15,
  tron: 19
};

// Network to chain mapping
const NETWORK_CHAIN_MAP: Record<string, string> = {
  'ETH_MAINNET': 'ethereum',
  'MATIC_MAINNET': 'polygon',
  'BSC_MAINNET': 'bsc',
  'OPTIMISM_MAINNET': 'optimism',
  'ARBITRUM_MAINNET': 'arbitrum',
};

// Rate limiting for webhooks (prevent abuse)
const webhookRateLimit = new Map<string, number>();
const WEBHOOK_RATE_LIMIT = 100;
const WEBHOOK_WINDOW = 60000;

function checkWebhookRateLimit(address: string): boolean {
  const now = Date.now();
  const key = `${address}-${Math.floor(now / WEBHOOK_WINDOW)}`;
  const currentCount = webhookRateLimit.get(key) || 0;
  
  if (currentCount >= WEBHOOK_RATE_LIMIT) {
    console.warn(`[Alchemy Webhook] Rate limit exceeded for ${address?.substring(0, 10)}...`);
    return false;
  }
  
  webhookRateLimit.set(key, currentCount + 1);
  return true;
}

// Processed transaction cache to prevent duplicates
const processedTxCache = new Map<string, number>();
const TX_CACHE_TTL = 3600000; // 1 hour

function isTransactionProcessed(txHash: string, userId: string): boolean {
  const key = `${txHash}-${userId}`;
  const processed = processedTxCache.get(key);
  
  if (processed && Date.now() - processed < TX_CACHE_TTL) {
    return true;
  }
  
  return false;
}

function markTransactionProcessed(txHash: string, userId: string): void {
  const key = `${txHash}-${userId}`;
  processedTxCache.set(key, Date.now());
  
  // Cleanup old entries
  if (processedTxCache.size > 10000) {
    const now = Date.now();
    for (const [k, v] of processedTxCache.entries()) {
      if (now - v > TX_CACHE_TTL) {
        processedTxCache.delete(k);
      }
    }
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const body = await req.json();
    const { webhookId, id, createdAt, type, event } = body;

    if (!type || !event) {
      console.warn('[Alchemy Webhook] Invalid webhook payload');
      return new Response(JSON.stringify({ success: false, error: 'Invalid payload' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log(`[Alchemy Webhook] Type: ${type}`);

    // Handle ADDRESS_ACTIVITY (deposits)
    if (type === 'ADDRESS_ACTIVITY') {
      const { network, activity } = event;
      const chain = NETWORK_CHAIN_MAP[network] || 'ethereum';
      const minConf = MIN_CONFIRMATIONS[chain] || 12;
      
      if (!activity || !Array.isArray(activity)) {
        return new Response(JSON.stringify({ success: true }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      for (const tx of activity) {
        const { fromAddress, toAddress, value, asset, hash, category, blockNum } = tx;
        
        // Skip zero-value transactions
        if (!value || parseFloat(value) === 0) continue;
        if (!hash) continue;

        // Rate limit check
        if (!checkWebhookRateLimit(toAddress)) continue;

        // Check for incoming transaction (deposit)
        const { data: recipientWallet } = await supabaseClient
          .from('wallet_addresses')
          .select('user_id, chain, symbol')
          .or(`address.eq.${toAddress},address.ilike.${toAddress}`)
          .maybeSingle();

        if (recipientWallet) {
          // Prevent duplicate processing
          if (isTransactionProcessed(hash, recipientWallet.user_id)) {
            console.log(`[Alchemy Webhook] Already processed: ${hash?.substring(0, 15)}...`);
            continue;
          }

          // Check for duplicate in database
          const { data: existingTx } = await supabaseClient
            .from('transactions')
            .select('id')
            .eq('tx_hash', hash)
            .eq('user_id', recipientWallet.user_id)
            .eq('type', 'deposit')
            .maybeSingle();

          if (existingTx) {
            console.log(`[Alchemy Webhook] Duplicate transaction in DB: ${hash?.substring(0, 15)}...`);
            markTransactionProcessed(hash, recipientWallet.user_id);
            continue;
          }

          const amount = parseFloat(value);
          const symbol = recipientWallet.symbol || asset || 'ETH';

          // Record the deposit transaction (balance updated from blockchain on next query)
          await supabaseClient.from('transactions').insert({
            user_id: recipientWallet.user_id,
            type: 'deposit',
            from_currency: symbol,
            amount,
            tx_hash: hash,
            status: 'completed'
          });

          // Create notification
          await supabaseClient.from('notifications').insert({
            user_id: recipientWallet.user_id,
            title: 'Deposit Confirmed',
            message: `${amount} ${symbol} has been credited to your wallet`,
            type: 'deposit',
            data: {
              amount,
              symbol,
              txHash: hash,
              network,
              blockNumber: blockNum,
              minConfirmations: minConf
            }
          });

          markTransactionProcessed(hash, recipientWallet.user_id);
          console.log(`[Alchemy Webhook] Deposit recorded: ${amount} ${symbol}`);
        }

        // Check for outgoing transaction confirmation (send)
        const { data: senderWallet } = await supabaseClient
          .from('wallet_addresses')
          .select('user_id, chain, symbol')
          .or(`address.eq.${fromAddress},address.ilike.${fromAddress}`)
          .maybeSingle();

        if (senderWallet) {
          // Update pending transaction to completed
          const { data: updatedTx } = await supabaseClient
            .from('transactions')
            .update({ status: 'completed' })
            .eq('user_id', senderWallet.user_id)
            .eq('tx_hash', hash)
            .eq('status', 'pending')
            .eq('type', 'send')
            .select()
            .maybeSingle();

          if (updatedTx) {
            await supabaseClient.from('notifications').insert({
              user_id: senderWallet.user_id,
              title: 'Send Confirmed',
              message: `Your ${senderWallet.symbol} transaction has been confirmed`,
              type: 'send_confirmed',
              data: {
                txHash: hash,
                symbol: senderWallet.symbol,
                amount: updatedTx.amount
              }
            });

            console.log(`[Alchemy Webhook] Send confirmed: ${hash?.substring(0, 15)}...`);
          }
        }
      }
    }

    // Handle MINED_TRANSACTION
    if (type === 'MINED_TRANSACTION') {
      const { hash, status } = event.transaction || {};
      
      if (hash) {
        const newStatus = status === 1 ? 'completed' : 'failed';
        
        const { data: updatedTx } = await supabaseClient
          .from('transactions')
          .update({ status: newStatus })
          .eq('tx_hash', hash)
          .eq('status', 'pending')
          .select()
          .maybeSingle();

        if (updatedTx) {
          const title = newStatus === 'completed' ? 'Transaction Confirmed' : 'Transaction Failed';
          const message = newStatus === 'completed' 
            ? 'Your transaction has been confirmed on the blockchain'
            : 'Your transaction has failed. Please try again.';

          await supabaseClient.from('notifications').insert({
            user_id: updatedTx.user_id,
            title,
            message,
            type: newStatus === 'completed' ? 'tx_confirmed' : 'tx_failed',
            data: { txHash: hash, status: newStatus }
          });

          console.log(`[Alchemy Webhook] Transaction ${hash?.substring(0, 15)}... marked as ${newStatus}`);
        }
      }
    }

    // Handle DROPPED_TRANSACTION
    if (type === 'DROPPED_TRANSACTION') {
      const { hash } = event.transaction || {};
      
      if (hash) {
        const { data: droppedTx } = await supabaseClient
          .from('transactions')
          .update({ 
            status: 'failed',
            last_error: 'Transaction was dropped from mempool',
            can_retry: true
          })
          .eq('tx_hash', hash)
          .eq('status', 'pending')
          .select()
          .maybeSingle();

        if (droppedTx) {
          await supabaseClient.from('notifications').insert({
            user_id: droppedTx.user_id,
            title: 'Transaction Dropped',
            message: 'Your transaction was dropped. You may retry.',
            type: 'tx_dropped',
            data: { txHash: hash }
          });

          console.log(`[Alchemy Webhook] Transaction ${hash?.substring(0, 15)}... dropped`);
        }
      }
    }

    return new Response(JSON.stringify({ success: true }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('[Alchemy Webhook] Error:', errorMessage);
    
    // Return 200 to prevent webhook retries
    return new Response(JSON.stringify({
      success: false,
      error: errorMessage
    }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
