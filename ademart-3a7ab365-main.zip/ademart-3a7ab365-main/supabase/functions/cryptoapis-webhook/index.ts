import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Minimum confirmations required before crediting deposits
const MIN_CONFIRMATIONS: Record<string, number> = {
  bitcoin: 2,
  litecoin: 6,
  dogecoin: 6
};

// Rate limiting for webhooks
const webhookRateLimit = new Map<string, number>();
const WEBHOOK_RATE_LIMIT = 100;
const WEBHOOK_WINDOW = 60000;

function checkWebhookRateLimit(address: string): boolean {
  const now = Date.now();
  const key = `${address}-${Math.floor(now / WEBHOOK_WINDOW)}`;
  const currentCount = webhookRateLimit.get(key) || 0;
  
  if (currentCount >= WEBHOOK_RATE_LIMIT) {
    console.warn(`[CryptoAPIs Webhook] Rate limit exceeded for ${address?.substring(0, 10)}...`);
    return false;
  }
  
  webhookRateLimit.set(key, currentCount + 1);
  return true;
}

// Processed transaction cache to prevent duplicates
const processedTxCache = new Map<string, number>();
const TX_CACHE_TTL = 3600000; // 1 hour

function isTransactionProcessed(txHash: string, userId: string): boolean {
  const key = `${txHash}-${userId}`;
  const processed = processedTxCache.get(key);
  
  if (processed && Date.now() - processed < TX_CACHE_TTL) {
    return true;
  }
  
  return false;
}

function markTransactionProcessed(txHash: string, userId: string): void {
  const key = `${txHash}-${userId}`;
  processedTxCache.set(key, Date.now());
  
  // Cleanup old entries
  if (processedTxCache.size > 10000) {
    const now = Date.now();
    for (const [k, v] of processedTxCache.entries()) {
      if (now - v > TX_CACHE_TTL) {
        processedTxCache.delete(k);
      }
    }
  }
}

// Blockchain to chain mapping
const BLOCKCHAIN_CHAIN_MAP: Record<string, string> = {
  'bitcoin': 'bitcoin',
  'litecoin': 'litecoin',
  'dogecoin': 'dogecoin',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const body = await req.json();
    const { event, data } = body;

    if (!event || !data) {
      console.warn('[CryptoAPIs Webhook] Invalid webhook payload');
      return new Response(JSON.stringify({ success: false, error: 'Invalid payload' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log(`[CryptoAPIs Webhook] Event: ${event}`);

    switch (event) {
      case 'ADDRESS_COINS_TRANSACTION_CONFIRMED': {
        const item = data.item || {};
        const { address, transactionId, amount, direction, confirmations, blockchain } = item;
        
        if (!address || !transactionId || !amount) {
          console.warn('[CryptoAPIs Webhook] Missing required fields');
          break;
        }

        // Rate limit check
        if (!checkWebhookRateLimit(address)) break;

        // Find the wallet
        const { data: wallet } = await supabaseClient
          .from('wallet_addresses')
          .select('user_id, chain, symbol')
          .eq('address', address)
          .maybeSingle();

        if (!wallet) {
          console.log(`[CryptoAPIs Webhook] Address ${address?.substring(0, 10)}... not found`);
          break;
        }

        const chain = BLOCKCHAIN_CHAIN_MAP[blockchain] || wallet.chain;
        const minConf = MIN_CONFIRMATIONS[chain] || 3;
        const parsedConfirmations = parseInt(confirmations) || 0;

        // Handle incoming deposit
        if (direction === 'incoming' && parsedConfirmations >= minConf) {
          // Prevent duplicate processing
          if (isTransactionProcessed(transactionId, wallet.user_id)) {
            console.log(`[CryptoAPIs Webhook] Already processed: ${transactionId?.substring(0, 15)}...`);
            break;
          }

          // Check for duplicate in database
          const { data: existingTx } = await supabaseClient
            .from('transactions')
            .select('id')
            .eq('tx_hash', transactionId)
            .eq('user_id', wallet.user_id)
            .eq('type', 'deposit')
            .maybeSingle();

          if (existingTx) {
            console.log(`[CryptoAPIs Webhook] Duplicate in DB: ${transactionId?.substring(0, 15)}...`);
            markTransactionProcessed(transactionId, wallet.user_id);
            break;
          }

          const numAmount = parseFloat(amount);

          // Record deposit (balance comes from blockchain on next query)
          await supabaseClient.from('transactions').insert({
            user_id: wallet.user_id,
            type: 'deposit',
            from_currency: wallet.symbol,
            amount: numAmount,
            tx_hash: transactionId,
            status: 'completed'
          });

          // Create notification
          await supabaseClient.from('notifications').insert({
            user_id: wallet.user_id,
            title: 'Deposit Confirmed',
            message: `${amount} ${wallet.symbol} has been credited (${confirmations} confirmations)`,
            type: 'deposit',
            data: {
              amount: numAmount,
              symbol: wallet.symbol,
              txHash: transactionId,
              confirmations: parsedConfirmations,
              blockchain
            }
          });

          markTransactionProcessed(transactionId, wallet.user_id);
          console.log(`[CryptoAPIs Webhook] Deposit recorded: ${amount} ${wallet.symbol}`);
        } 
        // Handle pending deposit (not enough confirmations yet)
        else if (direction === 'incoming' && parsedConfirmations < minConf) {
          console.log(`[CryptoAPIs Webhook] Pending deposit: ${parsedConfirmations}/${minConf} confirmations`);
        } 
        // Handle outgoing transaction confirmation
        else if (direction === 'outgoing') {
          const { data: updatedTx } = await supabaseClient
            .from('transactions')
            .update({ status: 'completed' })
            .eq('user_id', wallet.user_id)
            .eq('tx_hash', transactionId)
            .eq('status', 'pending')
            .eq('type', 'send')
            .select()
            .maybeSingle();

          if (updatedTx) {
            await supabaseClient.from('notifications').insert({
              user_id: wallet.user_id,
              title: 'Send Confirmed',
              message: `Your ${wallet.symbol} transaction has been confirmed`,
              type: 'send_confirmed',
              data: {
                txHash: transactionId,
                symbol: wallet.symbol,
                confirmations: parsedConfirmations
              }
            });

            console.log(`[CryptoAPIs Webhook] Send confirmed: ${transactionId?.substring(0, 15)}...`);
          }
        }
        break;
      }

      case 'ADDRESS_COINS_TRANSACTION_UNCONFIRMED': {
        const item = data.item || {};
        const { address, transactionId, amount, direction } = item;
        
        if (!address || !transactionId) break;

        // Find the wallet
        const { data: wallet } = await supabaseClient
          .from('wallet_addresses')
          .select('user_id, chain, symbol')
          .eq('address', address)
          .maybeSingle();

        if (!wallet) break;

        if (direction === 'incoming') {
          // Notify about pending deposit (don't credit yet)
          await supabaseClient.from('notifications').insert({
            user_id: wallet.user_id,
            title: 'Pending Deposit',
            message: `${amount} ${wallet.symbol} deposit detected. Waiting for confirmations...`,
            type: 'deposit_pending',
            data: {
              amount: parseFloat(amount),
              symbol: wallet.symbol,
              txHash: transactionId
            }
          });

          console.log(`[CryptoAPIs Webhook] Pending deposit notification sent`);
        }
        break;
      }

      case 'TRANSACTION_REQUEST_APPROVAL':
      case 'TRANSACTION_REQUEST_BROADCASTED':
      case 'TRANSACTION_REQUEST_MINED': {
        const item = data.item || {};
        const { transactionRequestId, transactionId, status } = item;
        
        const statusMap: Record<string, string> = {
          'approved': 'pending',
          'broadcasted': 'pending',
          'mined': 'completed',
          'failed': 'failed',
          'rejected': 'failed'
        };

        const newStatus = statusMap[status?.toLowerCase()] || 'pending';
        const txHash = transactionId || transactionRequestId;
        
        const { data: updatedTx } = await supabaseClient
          .from('transactions')
          .update({
            status: newStatus,
            tx_hash: transactionId || transactionRequestId
          })
          .eq('tx_hash', transactionRequestId)
          .select()
          .maybeSingle();

        if (updatedTx && newStatus === 'completed') {
          await supabaseClient.from('notifications').insert({
            user_id: updatedTx.user_id,
            title: 'Transaction Confirmed',
            message: 'Your transaction has been confirmed on the blockchain',
            type: 'tx_confirmed',
            data: { txHash }
          });
          console.log(`[CryptoAPIs Webhook] Transaction completed: ${txHash?.substring(0, 15)}...`);
        } else if (updatedTx && newStatus === 'failed') {
          await supabaseClient.from('notifications').insert({
            user_id: updatedTx.user_id,
            title: 'Transaction Failed',
            message: 'Your transaction has failed. Please try again.',
            type: 'tx_failed',
            data: { txHash }
          });
          console.log(`[CryptoAPIs Webhook] Transaction failed: ${txHash?.substring(0, 15)}...`);
        }
        break;
      }

      case 'TRANSACTION_REQUEST_REJECTION':
      case 'TRANSACTION_REQUEST_FAIL': {
        const item = data.item || {};
        const { transactionRequestId, errorMessage } = item;
        
        const { data: failedTx } = await supabaseClient
          .from('transactions')
          .update({
            status: 'failed',
            last_error: errorMessage || 'Transaction rejected or failed',
            can_retry: true
          })
          .eq('tx_hash', transactionRequestId)
          .select()
          .maybeSingle();

        if (failedTx) {
          await supabaseClient.from('notifications').insert({
            user_id: failedTx.user_id,
            title: 'Transaction Failed',
            message: errorMessage || 'Your transaction has failed. You may retry.',
            type: 'tx_failed',
            data: { txHash: transactionRequestId }
          });
          console.log(`[CryptoAPIs Webhook] Transaction failed: ${transactionRequestId?.substring(0, 15)}...`);
        }
        break;
      }

      default:
        console.log(`[CryptoAPIs Webhook] Unhandled event type: ${event}`);
    }

    return new Response(JSON.stringify({ success: true }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('[CryptoAPIs Webhook] Error:', errorMessage);
    
    // Return 200 to prevent webhook retries
    return new Response(JSON.stringify({
      success: false,
      error: errorMessage
    }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
