import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";
import * as bip39 from "https://esm.sh/bip39@3.1.0";
import { HDKey } from "https://esm.sh/@scure/bip32@1.3.3";
import { keccak_256 } from "https://esm.sh/@noble/hashes@1.3.3/sha3";
import { sha256 } from "https://esm.sh/@noble/hashes@1.3.3/sha256";
import { ripemd160 } from "https://esm.sh/@noble/hashes@1.3.3/ripemd160";
import { bytesToHex } from "https://esm.sh/@noble/hashes@1.3.3/utils";
import * as secp256k1 from "https://esm.sh/@noble/secp256k1@1.7.1";
const allowedOrigins = [
  "http://localhost:5173",
  "http://localhost:8080",
  "https://lovable.dev",
];

function getCorsHeaders(requestOrigin: string | null): Record<string, string> {
  const isAllowed = requestOrigin && (
    allowedOrigins.some(o => requestOrigin.startsWith(o.replace(/\/$/, ''))) ||
    requestOrigin.includes('.lovableproject.com') ||
    requestOrigin.includes('.lovable.app')
  );

  const origin = isAllowed ? requestOrigin : allowedOrigins[0];

  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };
}

// Chain configurations for HD wallet derivation
const chainConfigs: Record<string, { 
  path: string; 
  addressType: 'eth' | 'btc' | 'ltc' | 'trx' | 'doge';
  prefix?: number[];
}> = {
  'BTC': { path: "m/84'/0'/0'/0/0", addressType: 'btc', prefix: [0x00] },
  'ETH': { path: "m/44'/60'/0'/0/0", addressType: 'eth' },
  'BSC': { path: "m/44'/60'/0'/0/0", addressType: 'eth' },
  'MATIC': { path: "m/44'/60'/0'/0/0", addressType: 'eth' },
  'LTC': { path: "m/84'/2'/0'/0/0", addressType: 'ltc', prefix: [0x30] },
  'TRX': { path: "m/44'/195'/0'/0/0", addressType: 'trx' },
  'DOGE': { path: "m/44'/3'/0'/0/0", addressType: 'doge', prefix: [0x1e] },
};

// Base58 alphabet for encoding
const BASE58_ALPHABET = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';

function base58Encode(bytes: Uint8Array): string {
  const digits = [0];
  for (const byte of bytes) {
    let carry = byte;
    for (let j = 0; j < digits.length; j++) {
      carry += digits[j] * 256;
      digits[j] = carry % 58;
      carry = Math.floor(carry / 58);
    }
    while (carry > 0) {
      digits.push(carry % 58);
      carry = Math.floor(carry / 58);
    }
  }
  
  // Handle leading zeros
  for (const byte of bytes) {
    if (byte === 0) digits.push(0);
    else break;
  }
  
  return digits.reverse().map(d => BASE58_ALPHABET[d]).join('');
}

function base58CheckEncode(payload: Uint8Array): string {
  const checksum = sha256(sha256(payload)).slice(0, 4);
  const combined = new Uint8Array(payload.length + 4);
  combined.set(payload);
  combined.set(checksum, payload.length);
  return base58Encode(combined);
}

// Derive ETH/BSC/MATIC address from public key
function deriveEthAddress(publicKey: Uint8Array): string {
  // Use uncompressed public key (without 04 prefix if present, or decompress)
  let uncompressedKey: Uint8Array;
  if (publicKey.length === 33) {
    // Compressed, need to decompress using secp256k1 v1 API
    const point = secp256k1.Point.fromHex(bytesToHex(publicKey));
    uncompressedKey = point.toRawBytes(false).slice(1); // Remove 04 prefix
  } else if (publicKey.length === 65) {
    uncompressedKey = publicKey.slice(1); // Remove 04 prefix
  } else {
    uncompressedKey = publicKey;
  }
  
  const hash = keccak_256(uncompressedKey);
  const addressBytes = hash.slice(-20);
  return '0x' + bytesToHex(addressBytes);
}

// Derive BTC/LTC/DOGE address from public key (P2PKH)
function deriveBtcAddress(publicKey: Uint8Array, prefix: number[]): string {
  const sha256Hash = sha256(publicKey);
  const ripemdHash = ripemd160(sha256Hash);
  const payload = new Uint8Array(prefix.length + ripemdHash.length);
  payload.set(prefix);
  payload.set(ripemdHash, prefix.length);
  return base58CheckEncode(payload);
}

// Derive TRX address from public key
function deriveTrxAddress(publicKey: Uint8Array): string {
  let uncompressedKey: Uint8Array;
  if (publicKey.length === 33) {
    const point = secp256k1.Point.fromHex(bytesToHex(publicKey));
    uncompressedKey = point.toRawBytes(false).slice(1);
  } else if (publicKey.length === 65) {
    uncompressedKey = publicKey.slice(1);
  } else {
    uncompressedKey = publicKey;
  }
  
  const hash = keccak_256(uncompressedKey);
  const addressBytes = hash.slice(-20);
  const payload = new Uint8Array(21);
  payload[0] = 0x41; // TRX mainnet prefix
  payload.set(addressBytes, 1);
  return base58CheckEncode(payload);
}

// ==================== TRANSACTION BROADCASTING ====================

// TRON API endpoints (primary + fallbacks)
const TRONGRID_API_KEY = Deno.env.get("TRONGRID_API_KEY") || "";
const TRON_ENDPOINTS = [
  "https://api.trongrid.io",
  "https://api.tronstack.io", 
  "https://nile.trongrid.io", // Testnet fallback that sometimes works for mainnet queries
];

// Get TRON API headers with API key
function getTronHeaders(): Record<string, string> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (TRONGRID_API_KEY) {
    headers["TRON-PRO-API-KEY"] = TRONGRID_API_KEY;
  }
  return headers;
}

// Fetch with TRON endpoint fallback and retry logic
async function fetchTronWithFallback(
  path: string,
  body: any,
  method: string = "POST"
): Promise<{ data: any; endpoint: string }> {
  let lastError: Error | null = null;
  const headers = getTronHeaders();
  
  for (const endpoint of TRON_ENDPOINTS) {
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        console.log(`TRON API call: ${endpoint}${path} (attempt ${attempt + 1})`);
        
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 15000);
        
        const res = await fetch(`${endpoint}${path}`, {
          method,
          headers,
          body: body ? JSON.stringify(body) : undefined,
          signal: controller.signal,
        });
        clearTimeout(timeout);
        
        const data = await res.json();
        
        // Check for rate limiting or errors
        if (res.status === 429) {
          console.warn(`TRON rate limited on ${endpoint}, trying next...`);
          await new Promise(r => setTimeout(r, 1000));
          continue;
        }
        
        if (res.ok || res.status < 500) {
          return { data, endpoint };
        }
        
        lastError = new Error(`HTTP ${res.status}: ${JSON.stringify(data)}`);
      } catch (e) {
        lastError = e instanceof Error ? e : new Error(String(e));
        console.warn(`TRON endpoint ${endpoint} attempt ${attempt + 1} failed:`, lastError.message);
        
        if (attempt < 1) {
          await new Promise(r => setTimeout(r, 500));
        }
      }
    }
  }
  throw lastError || new Error("All TRON endpoints failed");
}

const TRON_API = TRON_ENDPOINTS[0]; // Primary endpoint

// EVM RPC endpoints with fallbacks
const EVM_RPC: Record<string, string[]> = {
  ETH: ["https://eth.llamarpc.com", "https://rpc.ankr.com/eth", "https://cloudflare-eth.com"],
  BSC: ["https://bsc-dataseed.binance.org", "https://bsc-dataseed1.defibit.io", "https://rpc.ankr.com/bsc"],
  MATIC: ["https://polygon-rpc.com", "https://rpc.ankr.com/polygon", "https://polygon.llamarpc.com"],
};

// Fetch with EVM fallback
async function fetchEvmWithFallback(chain: string, body: string): Promise<any> {
  const endpoints = EVM_RPC[chain] || [];
  let lastError: Error | null = null;
  
  for (const rpc of endpoints) {
    try {
      const res = await fetch(rpc, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body,
      });
      const data = await res.json();
      if (!data.error) {
        return data;
      }
      lastError = new Error(data.error?.message || "RPC error");
    } catch (e) {
      lastError = e instanceof Error ? e : new Error(String(e));
      console.warn(`EVM endpoint ${rpc} failed:`, lastError.message);
    }
  }
  throw lastError || new Error(`All ${chain} RPC endpoints failed`);
}

// TRC20 Token contract addresses
const TRC20_TOKENS: Record<string, string> = {
  USDT: "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t",
  USDC: "TEkxiTehnzSmSe2XqrBj4w32RUN966rdz8",
};

// ERC20 Token contract addresses
const ERC20_TOKENS: Record<string, string> = {
  USDT: "0xdAC17F958D2ee523a2206206994597C13D831ec7",
  USDC: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
};

// Explorer URLs
const EXPLORERS: Record<string, string> = {
  TRX: "https://tronscan.org/#/transaction/",
  ETH: "https://etherscan.io/tx/",
  BSC: "https://bscscan.com/tx/",
  MATIC: "https://polygonscan.com/tx/",
};

// Convert Base58Check address to hex address ("41" + 20 bytes)
function base58Decode(input: string): Uint8Array {
  let num = BigInt(0);
  for (const char of input) {
    const idx = BASE58_ALPHABET.indexOf(char);
    if (idx === -1) throw new Error(`Invalid base58 character: ${char}`);
    num = num * BigInt(58) + BigInt(idx);
  }

  let hex = num.toString(16);
  if (hex.length % 2) hex = "0" + hex;
  let bytes = hex.length ? hexToBytes(hex) : new Uint8Array();

  // Preserve leading zeros (each leading '1' is a 0x00 byte)
  const leadingOnes = input.match(/^1+/)?.[0]?.length ?? 0;
  if (leadingOnes > 0) {
    const withLeading = new Uint8Array(leadingOnes + bytes.length);
    withLeading.set(bytes, leadingOnes);
    bytes = withLeading;
  }

  return bytes;
}

function base58CheckDecode(input: string): Uint8Array {
  const decoded = base58Decode(input);
  if (decoded.length < 5) throw new Error('Invalid Base58Check: too short');

  const payload = decoded.slice(0, -4);
  const checksum = decoded.slice(-4);
  const expected = sha256(sha256(payload)).slice(0, 4);

  for (let i = 0; i < 4; i++) {
    if (checksum[i] !== expected[i]) throw new Error('Invalid Base58Check: checksum mismatch');
  }

  return payload;
}

function tronBase58ToHex(address: string): string {
  // Already hex format
  if (address.startsWith('0x')) {
    return '41' + address.slice(2).toLowerCase();
  }
  if (address.startsWith('41') && address.length === 42 && /^[0-9a-fA-F]+$/.test(address)) {
    return address.toLowerCase();
  }

  // Validate TRON base58 format
  if (!address.startsWith('T') || address.length !== 34) {
    throw new Error(`Invalid TRON address format: ${address}`);
  }

  const payload = base58CheckDecode(address);
  // TRON hex address should be 21 bytes: 0x41 + 20 bytes
  if (payload.length !== 21 || payload[0] !== 0x41) {
    throw new Error(`Invalid TRON address payload for: ${address}`);
  }

  return bytesToHex(payload);
}

function isMeaningfulTronText(text: string): boolean {
  const t = text.trim();
  if (t.length < 8) return false;
  if (!/[a-zA-Z]/.test(t)) return false;
  const alphaNum = t.match(/[a-zA-Z0-9]/g)?.length ?? 0;
  return alphaNum / t.length > 0.35;
}

function decodeTronMessage(input: unknown): string {
  if (!input) return '';

  // If we get a structured object back from TronGrid, prefer `code`, and only
  // include decoded `message` when it looks human-readable.
  if (typeof input === 'object') {
    try {
      const anyVal = input as any;
      const code = anyVal?.code ? String(anyVal.code) : '';
      const message = anyVal?.message ?? anyVal?.Error ?? anyVal?.error ?? '';
      const decoded = decodeTronMessage(message);

      if (code && isMeaningfulTronText(decoded)) return `${code}: ${decoded}`;
      if (code) return code;
      if (isMeaningfulTronText(decoded)) return decoded;

      return JSON.stringify(input);
    } catch {
      return String(input);
    }
  }

  const msg = String(input);

  // hex-encoded
  if (/^[0-9a-fA-F]+$/.test(msg) && msg.length % 2 === 0) {
    try {
      const out: string[] = [];
      for (let i = 0; i < msg.length; i += 2) {
        out.push(String.fromCharCode(parseInt(msg.slice(i, i + 2), 16)));
      }
      const printable = out.join('').replace(/[^\t\r\n\x20-\x7E]/g, '').trim();
      if (isMeaningfulTronText(printable)) return printable;
    } catch {
      // ignore
    }
  }

  // base64-encoded (sometimes TronGrid uses base64 for message)
  if (/^[A-Za-z0-9+/=]+$/.test(msg) && msg.length >= 8) {
    try {
      const decoded = atob(msg);
      const printable = decoded.replace(/[^\t\r\n\x20-\x7E]/g, '').trim();
      if (isMeaningfulTronText(printable)) return printable;
    } catch {
      // ignore
    }
  }

  return msg;
}

// Broadcast TRON native or TRC20 transaction with proper error handling
async function broadcastTronTransaction(
  privateKeyHex: string,
  from: string,
  to: string,
  amount: string,
  symbol: string
): Promise<{ txHash: string; explorerUrl: string } | { error: string }> {
  try {
    // Validate amount
    const amountNum = parseFloat(amount);
    if (isNaN(amountNum) || amountNum <= 0) {
      return { error: `Invalid amount: ${amount}` };
    }

    // Convert addresses to hex format for API
    let fromHex: string;
    let toHex: string;

    try {
      fromHex = tronBase58ToHex(from);
      toHex = tronBase58ToHex(to);
    } catch (addrError) {
      const msg = addrError instanceof Error ? addrError.message : 'Address conversion error';
      console.error('Address conversion error:', addrError);
      return { error: `Invalid address: ${msg}` };
    }

    console.log(`TRON tx: ${symbol} from ${from} to ${to}, amount: ${amount}`);

    let transaction: any = null;
    let txError: string | null = null;

    if (symbol === "TRX") {
      // Native TRX transfer - amount in SUN (1 TRX = 1,000,000 SUN)
      const amountSun = Math.floor(amountNum * 1e6);

      if (amountSun < 1) {
        return { error: "Amount too small (minimum 0.000001 TRX)" };
      }

      console.log(`Creating TRX transfer: ${amountSun} SUN`);

      try {
        const { data } = await fetchTronWithFallback("/wallet/createtransaction", {
          owner_address: fromHex,
          to_address: toHex,
          amount: amountSun,
          visible: false,
        });
        
        console.log("TRON createtransaction response:", JSON.stringify(data));

        if (data.Error) {
          txError = decodeTronMessage(data.Error);
        } else if (!data.txID) {
          txError = decodeTronMessage(data.message || 'No txID returned - check wallet has sufficient TRX balance');
        } else {
          transaction = data;
        }
      } catch (e) {
        txError = e instanceof Error ? e.message : "Failed to create TRX transaction";
      }
    } else if (TRC20_TOKENS[symbol]) {
      // TRC20 token transfer - USDT/USDC have 6 decimals
      const decimals = symbol === 'USDT' || symbol === 'USDC' ? 6 : 18;
      const amountRaw = BigInt(Math.floor(amountNum * Math.pow(10, decimals)));

      if (amountRaw < BigInt(1)) {
        return { error: `Amount too small for ${symbol}` };
      }

      const contractAddress = TRC20_TOKENS[symbol];
      let contractHex: string;
      try {
        contractHex = tronBase58ToHex(contractAddress);
      } catch {
        console.error(`Invalid contract address: ${contractAddress}`);
        return { error: `Invalid contract address for ${symbol}` };
      }

      // Encode transfer(address,uint256)
      // TRON expects the 20-byte address (without 0x41 prefix) padded to 32 bytes.
      const toParam = toHex.slice(2).padStart(64, '0');
      const amountParam = amountRaw.toString(16).padStart(64, '0');
      const parameter = toParam + amountParam;

      console.log(`TRC20 transfer: ${symbol} to ${to}, amount: ${amountNum}`);

      try {
        const { data } = await fetchTronWithFallback("/wallet/triggersmartcontract", {
          owner_address: fromHex,
          contract_address: contractHex,
          function_selector: "transfer(address,uint256)",
          parameter,
          fee_limit: 150000000, // 150 TRX max fee for TRC20
          call_value: 0,
          visible: false,
        });
        
        console.log("TRC20 triggersmartcontract response:", JSON.stringify(data));

        if (data.result?.result === false || data.Error) {
          const rawMsg = data.result?.message || data.Error || 'TRC20 contract call failed';
          txError = decodeTronMessage(rawMsg);
          
          // Check for common errors and provide helpful messages
          if (txError.toLowerCase().includes('energy') || txError.toLowerCase().includes('bandwidth')) {
            txError = `Insufficient TRX for network fees. You need ~15-30 TRX for energy/bandwidth. Original error: ${txError}`;
          } else if (txError.toLowerCase().includes('balance')) {
            txError = `Insufficient ${symbol} balance or TRX for fees. Original error: ${txError}`;
          }
        } else if (!data.transaction?.txID) {
          txError = 'Failed to create TRC20 transaction - ensure you have enough TRX for fees (15-30 TRX recommended)';
        } else {
          transaction = data.transaction;
        }
      } catch (e) {
        txError = e instanceof Error ? e.message : "Failed to create TRC20 transaction";
      }
    } else {
      return { error: `Unsupported token: ${symbol}. Only TRX, USDT, and USDC are supported on TRON.` };
    }

    if (!transaction || !transaction.txID) {
      const err = txError || 'Failed to create TRON transaction - check balance and network fees';
      console.error('Failed to create TRON transaction:', err);
      return { error: err };
    }

    // Sign the transaction
    const txHash = transaction.txID;
    const txHashBytes = hexToBytes(txHash);

    // TRON signature format: r (32 bytes) + s (32 bytes) + v (1 byte, 0 or 1)
    let signatureHex: string;
    try {
      const sigResult = await secp256k1.sign(txHashBytes, privateKeyHex, { recovered: true, der: false });
      const sigBytes = sigResult[0];
      const recovery = sigResult[1];
      signatureHex = bytesToHex(sigBytes) + recovery.toString(16).padStart(2, '0');
    } catch (signError) {
      console.error("Signing error:", signError);
      return { error: "Failed to sign transaction" };
    }

    transaction.signature = [signatureHex];

    console.log(`Broadcasting TRON tx: ${txHash}`);

    // Broadcast with retry across endpoints
    let broadcastResult: any = null;
    let lastError = '';
    
    for (let attempt = 0; attempt < 3; attempt++) {
      for (const endpoint of TRON_ENDPOINTS) {
        try {
          const controller = new AbortController();
          const timeout = setTimeout(() => controller.abort(), 10000);
          
          const broadcastRes = await fetch(`${endpoint}/wallet/broadcasttransaction`, {
            method: "POST",
            headers: getTronHeaders(),
            body: JSON.stringify(transaction),
            signal: controller.signal,
          });
          clearTimeout(timeout);
          
          broadcastResult = await broadcastRes.json();
          console.log(`TRON broadcast ${endpoint} attempt ${attempt + 1}:`, JSON.stringify(broadcastResult));

          if (broadcastResult.result === true) {
            return {
              txHash,
              explorerUrl: `${EXPLORERS.TRX}${txHash}`,
            };
          }

          const rawMsg = broadcastResult.message || broadcastResult.Error || broadcastResult.code || 'Broadcast rejected';
          lastError = decodeTronMessage(rawMsg);
          
          // Check for specific error types
          if (lastError.toLowerCase().includes('dup') || lastError.toLowerCase().includes('exist')) {
            // Transaction already submitted - this is actually success
            return {
              txHash,
              explorerUrl: `${EXPLORERS.TRX}${txHash}`,
            };
          }
        } catch (e) {
          console.error(`TRON broadcast ${endpoint} attempt ${attempt + 1} failed:`, e);
          lastError = e instanceof Error ? e.message : 'Network error during broadcast';
        }
      }
      
      if (attempt < 2) {
        await new Promise(r => setTimeout(r, 1500 * (attempt + 1)));
      }
    }

    console.error('TRON broadcast failed after all retries:', lastError);
    return { error: lastError || 'Transaction broadcast failed after multiple attempts' };
  } catch (error) {
    console.error("TRON transaction error:", error);
    return { error: error instanceof Error ? error.message : 'TRON transaction error' };
  }
}

// Broadcast EVM (ETH/BSC/MATIC) native or ERC20 transaction
async function broadcastEvmTransaction(
  privateKeyHex: string,
  from: string,
  to: string,
  amount: string,
  symbol: string,
  chain: string
): Promise<{ txHash: string; explorerUrl: string } | { error: string }> {
  try {
    const rpcList = EVM_RPC[chain];
    if (!rpcList || rpcList.length === 0) {
      console.error(`No RPC for chain: ${chain}`);
      return { error: `No RPC endpoint for chain: ${chain}` };
    }
    
    // Get nonce
    const nonceData = await fetchEvmWithFallback(chain, JSON.stringify({
      jsonrpc: "2.0", id: 1, method: "eth_getTransactionCount",
      params: [from, "latest"],
    }));
    const nonce = parseInt(nonceData.result, 16);
    
    // Get gas price
    const gasPriceData = await fetchEvmWithFallback(chain, JSON.stringify({
      jsonrpc: "2.0", id: 1, method: "eth_gasPrice", params: []
    }));
    const gasPrice = parseInt(gasPriceData.result, 16);
    
    let txData: string;
    let toAddress: string;
    let value: bigint;
    let gasLimit: number;
    
    const nativeCoins: Record<string, string> = { ETH: "ETH", BSC: "BNB", MATIC: "MATIC" };
    
    if (symbol === nativeCoins[chain]) {
      // Native coin transfer
      txData = "0x";
      toAddress = to;
      value = BigInt(Math.floor(parseFloat(amount) * 1e18));
      gasLimit = 21000;
    } else if (ERC20_TOKENS[symbol]) {
      // ERC20 token transfer
      const tokenAddress = ERC20_TOKENS[symbol];
      const amountWei = BigInt(Math.floor(parseFloat(amount) * 1e6)); // USDT/USDC have 6 decimals
      
      // transfer(address,uint256) function signature + parameters
      const functionSelector = "a9059cbb";
      const paddedTo = to.toLowerCase().replace("0x", "").padStart(64, "0");
      const paddedAmount = amountWei.toString(16).padStart(64, "0");
      txData = "0x" + functionSelector + paddedTo + paddedAmount;
      
      toAddress = tokenAddress;
      value = BigInt(0);
      gasLimit = 100000;
    } else {
      console.error(`Unsupported ERC20 token: ${symbol}`);
      return { error: `Unsupported ERC20 token: ${symbol}` };
    }
    
    // Build raw transaction (legacy format for simplicity)
    const chainIds: Record<string, number> = { ETH: 1, BSC: 56, MATIC: 137 };
    const chainId = chainIds[chain];
    
    // RLP encode transaction
    const txFields = [
      nonce,
      gasPrice,
      gasLimit,
      toAddress,
      value,
      txData,
      chainId,
      0,
      0,
    ];
    
    const rlpEncoded = rlpEncode(txFields);
    const txHashBytes = keccak_256(rlpEncoded);
    
    // Sign
    const sigResult = await secp256k1.sign(txHashBytes, privateKeyHex, { recovered: true, der: false });
    const sigBytes = sigResult[0];
    const recovery = sigResult[1];
    const r = BigInt('0x' + bytesToHex(sigBytes.slice(0, 32)));
    const s = BigInt('0x' + bytesToHex(sigBytes.slice(32, 64)));
    const v = recovery + chainId * 2 + 35;
    
    // RLP encode signed transaction
    const signedTxFields = [
      nonce,
      gasPrice,
      gasLimit,
      toAddress,
      value,
      txData,
      v,
      r,
      s,
    ];
    const signedTx = "0x" + bytesToHex(rlpEncode(signedTxFields));
    
    // Broadcast
    const broadcastData = await fetchEvmWithFallback(chain, JSON.stringify({
      jsonrpc: "2.0", id: 1, method: "eth_sendRawTransaction",
      params: [signedTx],
    }));
    
    if (broadcastData.result) {
      return {
        txHash: broadcastData.result,
        explorerUrl: `${EXPLORERS[chain]}${broadcastData.result}`,
      };
    } else {
      const errMsg = broadcastData.error?.message || "EVM broadcast failed";
      console.error("EVM broadcast failed:", errMsg);
      return { error: errMsg };
    }
  } catch (error) {
    console.error("EVM transaction error:", error);
    return { error: error instanceof Error ? error.message : "EVM transaction error" };
  }
}

// Simple RLP encoding for transaction data
function rlpEncode(input: any): Uint8Array {
  if (typeof input === "string") {
    if (input.startsWith("0x")) {
      const hex = input.slice(2);
      if (hex.length === 0) return new Uint8Array([0x80]);
      const bytes = hexToBytes(hex);
      if (bytes.length === 1 && bytes[0] < 0x80) return bytes;
      return concatBytes(encodeLength(bytes.length, 0x80), bytes);
    }
    const bytes = new TextEncoder().encode(input);
    if (bytes.length === 1 && bytes[0] < 0x80) return bytes;
    return concatBytes(encodeLength(bytes.length, 0x80), bytes);
  }
  
  if (typeof input === "number" || typeof input === "bigint") {
    if (input === 0 || input === BigInt(0)) return new Uint8Array([0x80]);
    let hex = input.toString(16);
    if (hex.length % 2) hex = "0" + hex;
    const bytes = hexToBytes(hex);
    if (bytes.length === 1 && bytes[0] < 0x80) return bytes;
    return concatBytes(encodeLength(bytes.length, 0x80), bytes);
  }
  
  if (Array.isArray(input)) {
    const encoded = input.map(rlpEncode);
    const totalLength = encoded.reduce((sum, e) => sum + e.length, 0);
    const lengthPrefix = encodeLength(totalLength, 0xc0);
    return concatBytes(lengthPrefix, ...encoded);
  }
  
  return new Uint8Array([0x80]);
}

function encodeLength(len: number, offset: number): Uint8Array {
  if (len < 56) {
    return new Uint8Array([len + offset]);
  }
  let hexLength = len.toString(16);
  if (hexLength.length % 2) hexLength = "0" + hexLength;
  const lengthBytes = hexToBytes(hexLength);
  return concatBytes(new Uint8Array([lengthBytes.length + offset + 55]), lengthBytes);
}

function hexToBytes(hex: string): Uint8Array {
  if (hex.length % 2) hex = "0" + hex;
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i++) {
    bytes[i] = parseInt(hex.substr(i * 2, 2), 16);
  }
  return bytes;
}

function concatBytes(...arrays: Uint8Array[]): Uint8Array {
  const totalLength = arrays.reduce((sum, arr) => sum + arr.length, 0);
  const result = new Uint8Array(totalLength);
  let offset = 0;
  for (const arr of arrays) {
    result.set(arr, offset);
    offset += arr.length;
  }
  return result;
}

// Generate address from HD key for a specific chain
function deriveAddress(hdKey: HDKey, chain: string): string {
  const config = chainConfigs[chain];
  if (!config) throw new Error(`Unsupported chain: ${chain}`);
  
  const derivedKey = hdKey.derive(config.path);
  if (!derivedKey.publicKey) throw new Error('Failed to derive public key');
  
  switch (config.addressType) {
    case 'eth':
      return deriveEthAddress(derivedKey.publicKey);
    case 'btc':
    case 'ltc':
    case 'doge':
      return deriveBtcAddress(derivedKey.publicKey, config.prefix || [0x00]);
    case 'trx':
      return deriveTrxAddress(derivedKey.publicKey);
    default:
      throw new Error(`Unknown address type: ${config.addressType}`);
  }
}

// Simple encryption for mnemonic storage (in production, use proper encryption)
function encryptMnemonic(mnemonic: string, userId: string): string {
  // XOR-based simple encryption with user ID as key
  // In production, use AES-256-GCM with proper key management
  const encoder = new TextEncoder();
  const mnemonicBytes = encoder.encode(mnemonic);
  const keyBytes = encoder.encode(userId.repeat(10).slice(0, mnemonicBytes.length));
  
  const encrypted = new Uint8Array(mnemonicBytes.length);
  for (let i = 0; i < mnemonicBytes.length; i++) {
    encrypted[i] = mnemonicBytes[i] ^ keyBytes[i];
  }
  
  return btoa(String.fromCharCode(...encrypted));
}

function decryptMnemonic(encrypted: string, userId: string): string {
  const encryptedBytes = new Uint8Array(atob(encrypted).split('').map(c => c.charCodeAt(0)));
  const keyBytes = new TextEncoder().encode(userId.repeat(10).slice(0, encryptedBytes.length));
  
  const decrypted = new Uint8Array(encryptedBytes.length);
  for (let i = 0; i < encryptedBytes.length; i++) {
    decrypted[i] = encryptedBytes[i] ^ keyBytes[i];
  }
  
  return new TextDecoder().decode(decrypted);
}

serve(async (req: Request) => {
  const requestOrigin = req.headers.get("origin");
  const corsHeaders = getCorsHeaders(requestOrigin);

  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    
    if (!supabaseUrl || !supabaseServiceKey) {
      console.error("Missing Supabase configuration - URL:", !!supabaseUrl, "ServiceKey:", !!supabaseServiceKey);
      throw new Error("Missing Supabase configuration");
    }

    const authHeader = req.headers.get("authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "No authorization header" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Create service role client that bypasses RLS
    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });
    
    console.log("Created Supabase service role client");
    
    // Verify user token
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    
    if (userError || !user) {
      console.error("User verification failed:", userError);
      return new Response(JSON.stringify({ error: "Invalid token" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    
    console.log(`User verified: ${user.id}`);

    // Parse body once - it can only be consumed once
    const body = await req.json();
    const { 
      action, 
      symbol, 
      chain, 
      mnemonic: importedMnemonic,
      // send_onchain params
      to,
      sendAmount,
      sendSymbol,
      sendChain,
      // estimate_fee params
      feeChain,
      feeSymbol,
    } = body;
    console.log(`HD Wallet action: ${action} for user: ${user.id}, symbol: ${symbol}, chain: ${chain}`);

    // Helper function to get or create mnemonic from secure storage
    async function getOrCreateMnemonic(): Promise<{ mnemonic: string; isNew: boolean }> {
      const userId = user!.id;
      console.log(`getOrCreateMnemonic called for user: ${userId}`);
      
      // Check secure storage for existing mnemonic
      const { data: existingSecret, error: selectError } = await supabase
        .from('user_wallet_secrets')
        .select('mnemonic_encrypted')
        .eq('user_id', userId)
        .maybeSingle();

      if (selectError) {
        console.error('Error checking existing mnemonic:', selectError);
      }

      if (existingSecret?.mnemonic_encrypted) {
        console.log(`Found existing mnemonic for user: ${userId}`);
        return {
          mnemonic: decryptMnemonic(existingSecret.mnemonic_encrypted, userId),
          isNew: false,
        };
      }

      console.log(`No existing mnemonic found for user: ${userId}, generating new one`);
      
      // Generate new mnemonic with cryptographically secure randomness
      const newMnemonic = bip39.generateMnemonic(256); // 24 words
      const encryptedMnemonic = encryptMnemonic(newMnemonic, userId);

      console.log(`Generated new mnemonic for user: ${userId}, encrypted length: ${encryptedMnemonic.length}`);

      // Store in secure table using service role (bypasses RLS)
      const { data: insertData, error: insertError } = await supabase
        .from('user_wallet_secrets')
        .insert({
          user_id: userId,
          mnemonic_encrypted: encryptedMnemonic,
        })
        .select('id')
        .single();

      if (insertError) {
        console.error('Failed to store mnemonic:', JSON.stringify(insertError));
        // Check if it's a unique constraint error (user already has a mnemonic)
        if (insertError.code === '23505') {
          console.log('Mnemonic already exists, fetching it');
          const { data: retrySecret } = await supabase
            .from('user_wallet_secrets')
            .select('mnemonic_encrypted')
            .eq('user_id', userId)
            .single();
          
          if (retrySecret?.mnemonic_encrypted) {
            return {
              mnemonic: decryptMnemonic(retrySecret.mnemonic_encrypted, userId),
              isNew: false,
            };
          }
        }
        throw new Error(`Failed to secure wallet secret: ${insertError.message}`);
      }

      console.log(`Successfully stored new mnemonic for user: ${userId}, record id: ${insertData?.id}`);
      return { mnemonic: newMnemonic, isNew: true };
    }

    switch (action) {
      case "generate_wallet": {
        // Check if user already has a wallet for this symbol/chain
        const { data: existingWallet } = await supabase
          .from('wallet_addresses')
          .select('*')
          .eq('user_id', user.id)
          .eq('symbol', symbol)
          .eq('chain', chain)
          .maybeSingle();

        if (existingWallet) {
          console.log(`User already has wallet for ${symbol}/${chain}: ${existingWallet.address}`);
          return new Response(JSON.stringify({
            success: true,
            data: {
              address: existingWallet.address,
              symbol,
              chain,
              isNew: false,
            }
          }), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        const { mnemonic } = await getOrCreateMnemonic();

        // Derive seed and address
        const seed = await bip39.mnemonicToSeed(mnemonic);
        const hdKey = HDKey.fromMasterSeed(seed);
        const address = deriveAddress(hdKey, chain);

        console.log(`Generated address for ${symbol}/${chain}: ${address}`);

        // Check how many wallets user already has for this symbol
        const { count } = await supabase
          .from('wallet_addresses')
          .select('*', { count: 'exact', head: true })
          .eq('user_id', user.id)
          .eq('symbol', symbol);

        const isPrimary = (count ?? 0) === 0;

        // Store wallet address with upsert to handle race conditions (using user_id,symbol,chain constraint)
        const { data: insertedWallet, error: insertError } = await supabase
          .from('wallet_addresses')
          .upsert({
            user_id: user.id,
            symbol,
            chain,
            address,
            is_primary: isPrimary,
          }, {
            onConflict: 'user_id,symbol,chain',
            ignoreDuplicates: true,
          })
          .select()
          .maybeSingle();

        if (insertError) {
          console.error('Failed to store wallet:', insertError);
          // If it's a duplicate, fetch the existing one
          if (insertError.code === '23505') {
            const { data: retryWallet } = await supabase
              .from('wallet_addresses')
              .select('*')
              .eq('user_id', user.id)
              .eq('symbol', symbol)
              .eq('chain', chain)
              .maybeSingle();
            
            if (retryWallet) {
              return new Response(JSON.stringify({
                success: true,
                data: {
                  address: retryWallet.address,
                  symbol,
                  chain,
                  isNew: false,
                }
              }), {
                headers: { ...corsHeaders, "Content-Type": "application/json" },
              });
            }
          }
          throw new Error('Failed to store wallet address');
        }

        // Also create a balance entry in wallets table if it doesn't exist
        const { data: existingBalance } = await supabase
          .from('wallets')
          .select('id')
          .eq('user_id', user.id)
          .eq('currency', symbol)
          .maybeSingle();

        if (!existingBalance) {
          await supabase
            .from('wallets')
            .upsert({
              user_id: user.id,
              currency: symbol,
              balance: 0,
            }, {
              onConflict: 'user_id,currency',
              ignoreDuplicates: true,
            });
        }

        return new Response(JSON.stringify({
          success: true,
          data: {
            address: insertedWallet?.address || address,
            symbol,
            chain,
            isNew: true,
            isPrimary,
          }
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "generate_all_wallets": {
        // Generate wallets for all supported chains
        const supportedAssets = [
          { symbol: 'BTC', chain: 'BTC' },
          { symbol: 'ETH', chain: 'ETH' },
          { symbol: 'LTC', chain: 'LTC' },
          { symbol: 'TRX', chain: 'TRX' },
          { symbol: 'BNB', chain: 'BSC' },
          { symbol: 'MATIC', chain: 'MATIC' },
          { symbol: 'DOGE', chain: 'DOGE' },
          { symbol: 'USDT', chain: 'TRX' },
          { symbol: 'USDC', chain: 'ETH' },
        ];

        const { mnemonic } = await getOrCreateMnemonic();

        const seed = await bip39.mnemonicToSeed(mnemonic);
        const hdKey = HDKey.fromMasterSeed(seed);
        const generatedWallets: any[] = [];

        for (const asset of supportedAssets) {
          // Check if wallet exists
          const { data: existing } = await supabase
            .from('wallet_addresses')
            .select('address')
            .eq('user_id', user.id)
            .eq('symbol', asset.symbol)
            .eq('chain', asset.chain)
            .maybeSingle();

          if (existing) {
            generatedWallets.push({ ...asset, address: existing.address, isNew: false });
            continue;
          }

          const address = deriveAddress(hdKey, asset.chain);

          // Check if this is first wallet for symbol
          const { count } = await supabase
            .from('wallet_addresses')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', user.id)
            .eq('symbol', asset.symbol);

          const isPrimary = (count ?? 0) === 0;

          const { error: insertErr } = await supabase
            .from('wallet_addresses')
            .upsert({
              user_id: user.id,
              symbol: asset.symbol,
              chain: asset.chain,
              address,
              is_primary: isPrimary,
            }, {
              onConflict: 'user_id,symbol,chain',
              ignoreDuplicates: true,
            });

          // Create balance entry with upsert
          await supabase
            .from('wallets')
            .upsert({
              user_id: user.id,
              currency: asset.symbol,
              balance: 0,
            }, {
              onConflict: 'user_id,currency',
              ignoreDuplicates: true,
            });

          generatedWallets.push({ ...asset, address, isNew: true, isPrimary });
        }

        return new Response(JSON.stringify({
          success: true,
          data: { wallets: generatedWallets }
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "get_recovery_phrase": {
        // Get and decrypt the mnemonic for backup from secure storage
        const { data: secretData } = await supabase
          .from('user_wallet_secrets')
          .select('mnemonic_encrypted')
          .eq('user_id', user.id)
          .maybeSingle();

        if (!secretData?.mnemonic_encrypted) {
          return new Response(JSON.stringify({
            success: false,
            error: 'No wallet found. Generate a wallet first.',
          }), {
            status: 404,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        const mnemonic = decryptMnemonic(secretData.mnemonic_encrypted, user.id);
        const words = mnemonic.split(' ');

        console.log(`Recovery phrase requested for user: ${user.id}`);

        return new Response(JSON.stringify({
          success: true,
          data: {
            words,
            wordCount: words.length,
          }
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "import_wallet": {
        // Import wallet from mnemonic phrase
        if (!importedMnemonic || typeof importedMnemonic !== 'string') {
          return new Response(JSON.stringify({
            success: false,
            error: 'Recovery phrase is required',
          }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        // Validate mnemonic
        const normalizedMnemonic = importedMnemonic.trim().toLowerCase();
        if (!bip39.validateMnemonic(normalizedMnemonic)) {
          return new Response(JSON.stringify({
            success: false,
            error: 'Invalid recovery phrase. Please check and try again.',
          }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        // Check if user already has a wallet
        const { data: existingSecret } = await supabase
          .from('user_wallet_secrets')
          .select('id')
          .eq('user_id', user.id)
          .maybeSingle();

        if (existingSecret) {
          return new Response(JSON.stringify({
            success: false,
            error: 'You already have a wallet. To import a new one, please contact support.',
          }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        // Encrypt and store the imported mnemonic
        const encryptedMnemonic = encryptMnemonic(normalizedMnemonic, user.id);

        const { error: insertError } = await supabase
          .from('user_wallet_secrets')
          .insert({
            user_id: user.id,
            mnemonic_encrypted: encryptedMnemonic,
          });

        if (insertError) {
          console.error('Failed to store imported mnemonic:', insertError);
          throw new Error('Failed to import wallet');
        }

        // Generate addresses for all supported chains
        const supportedAssets = [
          { symbol: 'BTC', chain: 'BTC' },
          { symbol: 'ETH', chain: 'ETH' },
          { symbol: 'LTC', chain: 'LTC' },
          { symbol: 'TRX', chain: 'TRX' },
          { symbol: 'BNB', chain: 'BSC' },
          { symbol: 'MATIC', chain: 'MATIC' },
          { symbol: 'DOGE', chain: 'DOGE' },
          { symbol: 'USDT', chain: 'TRX' },
          { symbol: 'USDC', chain: 'ETH' },
        ];

        const seed = await bip39.mnemonicToSeed(normalizedMnemonic);
        const hdKey = HDKey.fromMasterSeed(seed);
        const importedWallets: any[] = [];

        for (const asset of supportedAssets) {
          const address = deriveAddress(hdKey, asset.chain);

          await supabase
            .from('wallet_addresses')
            .upsert({
              user_id: user.id,
              symbol: asset.symbol,
              chain: asset.chain,
              address,
              is_primary: true,
            }, {
              onConflict: 'user_id,symbol,chain',
              ignoreDuplicates: true,
            });

          // Create balance entry
          await supabase
            .from('wallets')
            .upsert({
              user_id: user.id,
              currency: asset.symbol,
              balance: 0,
            }, { onConflict: 'user_id,currency', ignoreDuplicates: true });

          importedWallets.push({ ...asset, address });
        }

        console.log(`Wallet imported for user: ${user.id}, ${importedWallets.length} addresses generated`);

        return new Response(JSON.stringify({
          success: true,
          data: {
            message: 'Wallet imported successfully',
            walletCount: importedWallets.length,
            wallets: importedWallets,
          }
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "send_onchain": {
        // Sign and broadcast a transaction from the user's HD wallet
        // Variables to, sendAmount, sendSymbol, sendChain are already parsed from body at top
        if (!to || !sendAmount || !sendSymbol || !sendChain) {
          return new Response(JSON.stringify({ error: "Missing required fields: to, sendAmount, sendSymbol, sendChain" }), {
            status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        
        // Get user's mnemonic
        const { data: secretData } = await supabase
          .from('user_wallet_secrets')
          .select('mnemonic_encrypted')
          .eq('user_id', user.id)
          .maybeSingle();

        if (!secretData?.mnemonic_encrypted) {
          return new Response(JSON.stringify({ error: "No wallet found. Generate a wallet first." }), {
            status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        const mnemonic = decryptMnemonic(secretData.mnemonic_encrypted, user.id);
        const seed = await bip39.mnemonicToSeed(mnemonic);
        const hdKey = HDKey.fromMasterSeed(seed);
        
        const config = chainConfigs[sendChain];
        if (!config) {
          return new Response(JSON.stringify({ error: `Unsupported chain: ${sendChain}` }), {
            status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        
        const derivedKey = hdKey.derive(config.path);
        if (!derivedKey.privateKey) {
          return new Response(JSON.stringify({ error: "Failed to derive private key" }), {
            status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        
        const privateKeyHex = bytesToHex(derivedKey.privateKey);
        const fromAddress = deriveAddress(hdKey, sendChain);
        
        let txResult: { txHash: string; explorerUrl: string } | null = null;
        let txError: string | null = null;
        
        // Get wallet for balance operations
        const { data: wallet } = await supabase
          .from("wallets")
          .select("id, balance, reserved_balance")
          .eq("user_id", user.id)
          .eq("currency", sendSymbol)
          .maybeSingle();
        
        const sendAmountNum = parseFloat(sendAmount);
        
        // Check available balance (balance - reserved)
        const availableBalance = (wallet?.balance || 0) - (wallet?.reserved_balance || 0);
        if (!wallet || availableBalance < sendAmountNum) {
          return new Response(JSON.stringify({ 
            error: `Insufficient balance. Available: ${availableBalance.toFixed(8)} ${sendSymbol}` 
          }), {
            status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        
        // Reserve funds BEFORE broadcast (prevents double-spend)
        const { error: reserveError } = await supabase.rpc('reserve_wallet_balance', {
          p_wallet_id: wallet.id,
          p_amount: sendAmountNum,
        });
        
        if (reserveError) {
          console.error("Failed to reserve balance:", reserveError);
          return new Response(JSON.stringify({ error: "Failed to reserve funds" }), {
            status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        
        // Generate idempotency key to prevent duplicate sends
        const idempotencyKey = `${user.id}_${to}_${sendAmount}_${sendSymbol}_${Date.now()}`;
        
        // Handle TRX and TRC20 transactions
        if (sendChain === "TRX") {
          const tronResult = await broadcastTronTransaction(privateKeyHex, fromAddress, to, sendAmount, sendSymbol);
          if ('error' in tronResult) {
            txError = tronResult.error;
          } else {
            txResult = tronResult;
          }
        } 
        // Handle EVM chains (ETH, BSC, MATIC) and ERC20 tokens
        else if (["ETH", "BSC", "MATIC"].includes(sendChain)) {
          const evmResult = await broadcastEvmTransaction(privateKeyHex, fromAddress, to, sendAmount, sendSymbol, sendChain);
          if ('error' in evmResult) {
            txError = evmResult.error;
          } else {
            txResult = evmResult;
          }
        }
        // Handle BTC-like chains
        else if (["BTC", "LTC", "DOGE"].includes(sendChain)) {
          // Release reserved funds since we can't proceed
          await supabase.rpc('release_reserved_balance', {
            p_wallet_id: wallet.id,
            p_amount: sendAmountNum,
          });
          return new Response(JSON.stringify({ 
            error: `On-chain ${sendChain} sending is not yet supported. Please use Bybit withdrawal.` 
          }), {
            status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        
        if (!txResult) {
          // Broadcast failed - release reserved funds and mark as retryable
          await supabase.rpc('release_reserved_balance', {
            p_wallet_id: wallet.id,
            p_amount: sendAmountNum,
          });
          
          const errorMsg = txError || "Transaction broadcast failed";
          console.error("Send failed:", errorMsg);
          
          // Record failed transaction with retry capability
          await supabase.from("transactions").insert({
            user_id: user.id,
            type: "send",
            from_currency: sendSymbol,
            amount: sendAmountNum,
            recipient_address: to,
            tx_hash: null,
            status: "failed",
            error_details: errorMsg,
            can_retry: true,
            retry_count: 0,
            last_error: errorMsg,
            idempotency_key: idempotencyKey,
          });
          
          return new Response(JSON.stringify({ 
            error: errorMsg,
            canRetry: true,
            errorDetails: errorMsg,
          }), {
            status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        
        // Broadcast succeeded - record transaction with reserved funds
        // Funds stay reserved until confirmed by onchain-monitor
        await supabase.from("transactions").insert({
          user_id: user.id,
          type: "send",
          from_currency: sendSymbol,
          amount: sendAmountNum,
          recipient_address: to,
          tx_hash: txResult.txHash,
          status: "pending",
          idempotency_key: idempotencyKey,
        });
        
        // Create notification
        await supabase.from("notifications").insert({
          user_id: user.id,
          title: "Transaction Sent",
          message: `Sent ${sendAmount} ${sendSymbol} to ${to.slice(0, 10)}... (confirming)`,
          type: "send",
          data: { txHash: txResult.txHash, amount: sendAmount, symbol: sendSymbol, to },
        });
        
        console.log(`On-chain send: ${sendAmount} ${sendSymbol} from ${fromAddress} to ${to}, tx: ${txResult.txHash}`);
        
        return new Response(JSON.stringify({
          success: true,
          data: {
            txHash: txResult.txHash,
            explorerUrl: txResult.explorerUrl,
            from: fromAddress,
            to,
            amount: sendAmount,
            symbol: sendSymbol,
            chain: sendChain,
            status: "pending",
          }
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "estimate_fee": {
        // Estimate network fee for a transaction
        // feeChain, feeSymbol are already parsed from body at top
        let feeEstimate = { fee: "0", feeSymbol: feeChain, speed: "~1 min" };
        
        if (feeChain === "TRX") {
          feeEstimate = { fee: "1", feeSymbol: "TRX", speed: "~3 sec" };
          if (feeSymbol === "USDT" || feeSymbol === "USDC") {
            feeEstimate = { fee: "15-30", feeSymbol: "TRX", speed: "~3 sec" };
          }
        } else if (feeChain === "ETH") {
          feeEstimate = { fee: "0.001-0.005", feeSymbol: "ETH", speed: "~15 sec" };
          if (feeSymbol === "USDT" || feeSymbol === "USDC") {
            feeEstimate = { fee: "0.002-0.01", feeSymbol: "ETH", speed: "~15 sec" };
          }
        } else if (feeChain === "BSC") {
          feeEstimate = { fee: "0.0005-0.001", feeSymbol: "BNB", speed: "~3 sec" };
        } else if (feeChain === "MATIC") {
          feeEstimate = { fee: "0.001-0.01", feeSymbol: "MATIC", speed: "~2 sec" };
        } else if (feeChain === "BTC") {
          feeEstimate = { fee: "0.00005-0.0005", feeSymbol: "BTC", speed: "~10 min" };
        } else if (feeChain === "LTC") {
          feeEstimate = { fee: "0.0001-0.001", feeSymbol: "LTC", speed: "~2.5 min" };
        } else if (feeChain === "DOGE") {
          feeEstimate = { fee: "1-5", feeSymbol: "DOGE", speed: "~1 min" };
        }
        
        return new Response(JSON.stringify({ success: true, data: feeEstimate }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // ==================== COMPATIBILITY ALIASES ====================
      // These aliases allow unified-wallet to call hd-wallet with normalized action names
      
      case "create_wallet": {
        // Alias for generate_wallet - unified-wallet calls this
        // Map chain names: ethereum -> ETH, polygon -> MATIC, bsc -> BSC, tron -> TRX
        const chainMap: Record<string, string> = {
          ethereum: 'ETH', polygon: 'MATIC', bsc: 'BSC', tron: 'TRX',
          ETH: 'ETH', MATIC: 'MATIC', BSC: 'BSC', TRX: 'TRX',
        };
        const mappedChain = chainMap[chain] || chain;
        
        // Check if user already has a wallet for this symbol/chain
        const { data: existingWallet } = await supabase
          .from('wallet_addresses')
          .select('*')
          .eq('user_id', user.id)
          .eq('symbol', symbol)
          .eq('chain', chain)
          .maybeSingle();

        if (existingWallet) {
          console.log(`User already has wallet for ${symbol}/${chain}: ${existingWallet.address}`);
          return new Response(JSON.stringify({
            success: true,
            address: existingWallet.address,
            symbol,
            chain,
            isNew: false,
          }), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        const { mnemonic: walletMnemonic } = await getOrCreateMnemonic();

        // Derive seed and address using mapped chain
        const walletSeed = await bip39.mnemonicToSeed(walletMnemonic);
        const walletHdKey = HDKey.fromMasterSeed(walletSeed);
        
        // Use mappedChain for derivation
        const walletConfig = chainConfigs[mappedChain];
        if (!walletConfig) {
          throw new Error(`Unsupported chain: ${chain} (mapped: ${mappedChain})`);
        }
        
        const derivedKey = walletHdKey.derive(walletConfig.path);
        if (!derivedKey.publicKey) throw new Error('Failed to derive public key');
        
        let walletAddress: string;
        switch (walletConfig.addressType) {
          case 'eth':
            walletAddress = deriveEthAddress(derivedKey.publicKey);
            break;
          case 'trx':
            walletAddress = deriveTrxAddress(derivedKey.publicKey);
            break;
          default:
            throw new Error(`Unsupported address type: ${walletConfig.addressType}`);
        }

        console.log(`Generated address for ${symbol}/${chain}: ${walletAddress}`);

        // Check how many wallets user already has for this symbol
        const { count: walletCount } = await supabase
          .from('wallet_addresses')
          .select('*', { count: 'exact', head: true })
          .eq('user_id', user.id)
          .eq('symbol', symbol);

        const isPrimaryWallet = (walletCount ?? 0) === 0;

        // Store wallet address with upsert
        const { data: insertedWallet, error: walletInsertError } = await supabase
          .from('wallet_addresses')
          .upsert({
            user_id: user.id,
            symbol,
            chain,
            address: walletAddress,
            is_primary: isPrimaryWallet,
          }, {
            onConflict: 'user_id,symbol,chain',
            ignoreDuplicates: true,
          })
          .select()
          .maybeSingle();

        if (walletInsertError && walletInsertError.code !== '23505') {
          console.error('Failed to store wallet:', walletInsertError);
          throw new Error('Failed to store wallet address');
        }

        // Also create a balance entry in wallets table if it doesn't exist
        await supabase
          .from('wallets')
          .upsert({
            user_id: user.id,
            currency: symbol,
            balance: 0,
          }, {
            onConflict: 'user_id,currency',
            ignoreDuplicates: true,
          });

        return new Response(JSON.stringify({
          success: true,
          address: insertedWallet?.address || walletAddress,
          symbol,
          chain,
          isNew: true,
          isPrimary: isPrimaryWallet,
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "get_balance": {
        // Get on-chain balance for a wallet
        const chainToRpc: Record<string, string> = {
          ethereum: 'ALCHEMY_ETH_RPC', polygon: 'ALCHEMY_POLYGON_RPC', bsc: 'ALCHEMY_BSC_RPC',
          ETH: 'ALCHEMY_ETH_RPC', MATIC: 'ALCHEMY_POLYGON_RPC', BSC: 'ALCHEMY_BSC_RPC',
        };
        
        // Get wallet address from DB
        const { data: walletData } = await supabase
          .from('wallet_addresses')
          .select('address')
          .eq('user_id', user.id)
          .eq('symbol', symbol)
          .eq('chain', chain)
          .maybeSingle();
        
        if (!walletData) {
          return new Response(JSON.stringify({
            success: true,
            balance: '0',
            address: null,
            chain,
            symbol,
            error: 'No wallet found',
          }), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        
        let balance = '0';
        try {
          // Check if this is a token or native coin
          const isToken = ['USDT', 'USDC'].includes(symbol);
          const isTron = chain === 'tron' || chain === 'TRX';
          
          if (isTron) {
            // Fetch TRON balance
            const apiKey = Deno.env.get('TRONGRID_API_KEY');
            const headers: Record<string, string> = { 'Content-Type': 'application/json' };
            if (apiKey) headers['TRON-PRO-API-KEY'] = apiKey;
            
            const res = await fetch(`https://api.trongrid.io/v1/accounts/${walletData.address}`, { headers });
            const data = await res.json();
            
            if (data.data && data.data.length > 0) {
              if (isToken) {
                // TRC20 token balance
                const trc20 = data.data[0].trc20 || [];
                const tokenAddresses: Record<string, string> = {
                  USDT: 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t',
                  USDC: 'TEkxiTehnzSmSe2XqrBj4w32RUN966rdz8',
                };
                const tokenBal = trc20.find((t: Record<string, string>) => 
                  Object.keys(t)[0] === tokenAddresses[symbol]
                );
                if (tokenBal) {
                  const rawBal = BigInt(Object.values(tokenBal)[0] as string);
                  balance = (Number(rawBal) / 1e6).toString();
                }
              } else {
                // Native TRX balance
                balance = ((data.data[0].balance || 0) / 1e6).toString();
              }
            }
          } else {
            // EVM balance
            const rpcEnv = chainToRpc[chain];
            const rpcUrl = rpcEnv ? Deno.env.get(rpcEnv) : null;
            
            if (rpcUrl) {
              if (isToken) {
                // ERC20 token balance
                const tokenAddresses: Record<string, Record<string, { address: string; decimals: number }>> = {
                  ethereum: { USDT: { address: '0xdAC17F958D2ee523a2206206994597C13D831ec7', decimals: 6 }, USDC: { address: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48', decimals: 6 } },
                  polygon: { USDT: { address: '0xc2132D05D31c914a87C6611C10748AEb04B58e8F', decimals: 6 }, USDC: { address: '0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174', decimals: 6 } },
                  bsc: { USDT: { address: '0x55d398326f99059fF775485246999027B3197955', decimals: 18 }, USDC: { address: '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d', decimals: 18 } },
                };
                const tokenInfo = tokenAddresses[chain]?.[symbol];
                if (tokenInfo) {
                  const balanceOfSelector = '0x70a08231';
                  const paddedAddr = walletData.address.slice(2).padStart(64, '0');
                  const callData = balanceOfSelector + paddedAddr;
                  
                  const res = await fetch(rpcUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                      jsonrpc: '2.0', id: 1, method: 'eth_call',
                      params: [{ to: tokenInfo.address, data: callData }, 'latest']
                    })
                  });
                  const data = await res.json();
                  if (!data.error && data.result) {
                    const rawBal = BigInt(data.result || '0x0');
                    balance = (Number(rawBal) / Math.pow(10, tokenInfo.decimals)).toString();
                  }
                }
              } else {
                // Native balance
                const res = await fetch(rpcUrl, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    jsonrpc: '2.0', id: 1, method: 'eth_getBalance',
                    params: [walletData.address, 'latest']
                  })
                });
                const data = await res.json();
                if (!data.error && data.result) {
                  const weiBalance = BigInt(data.result || '0x0');
                  balance = (Number(weiBalance) / 1e18).toString();
                }
              }
            }
          }
        } catch (err) {
          console.error(`Error fetching balance for ${symbol}/${chain}:`, err);
          balance = '0';
        }
        
        return new Response(JSON.stringify({
          success: true,
          balance,
          address: walletData.address,
          chain,
          symbol,
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "send": {
        // Alias for send_onchain - unified-wallet calls this
        // Map chain and extract params from body
        const chainMap: Record<string, string> = {
          ethereum: 'ETH', polygon: 'MATIC', bsc: 'BSC', tron: 'TRX',
          ETH: 'ETH', MATIC: 'MATIC', BSC: 'BSC', TRX: 'TRX',
        };
        const mappedSendChain = chainMap[chain] || chain;
        
        // Get amount and toAddress from body (unified-wallet sends these)
        const sendTo = body.toAddress || to;
        const sendAmt = body.amount || sendAmount;
        const sendSym = symbol || sendSymbol;
        
        if (!sendTo || !sendAmt || !sendSym) {
          return new Response(JSON.stringify({ 
            success: false,
            error: "Missing required fields: toAddress, amount, symbol" 
          }), {
            status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        
        // Get user's mnemonic
        const { data: sendSecretData } = await supabase
          .from('user_wallet_secrets')
          .select('mnemonic_encrypted')
          .eq('user_id', user.id)
          .maybeSingle();

        if (!sendSecretData?.mnemonic_encrypted) {
          return new Response(JSON.stringify({ 
            success: false,
            error: "No wallet found. Generate a wallet first." 
          }), {
            status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        const sendMnemonic = decryptMnemonic(sendSecretData.mnemonic_encrypted, user.id);
        const sendSeed = await bip39.mnemonicToSeed(sendMnemonic);
        const sendHdKey = HDKey.fromMasterSeed(sendSeed);
        
        const sendConfig = chainConfigs[mappedSendChain];
        if (!sendConfig) {
          return new Response(JSON.stringify({ 
            success: false,
            error: `Unsupported chain: ${chain}` 
          }), {
            status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        
        const sendDerivedKey = sendHdKey.derive(sendConfig.path);
        if (!sendDerivedKey.privateKey) {
          return new Response(JSON.stringify({ 
            success: false,
            error: "Failed to derive private key" 
          }), {
            status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        
        const sendPrivateKeyHex = bytesToHex(sendDerivedKey.privateKey);
        
        // Derive from address
        let sendFromAddress: string;
        if (sendConfig.addressType === 'eth') {
          sendFromAddress = deriveEthAddress(sendDerivedKey.publicKey!);
        } else if (sendConfig.addressType === 'trx') {
          sendFromAddress = deriveTrxAddress(sendDerivedKey.publicKey!);
        } else {
          return new Response(JSON.stringify({ 
            success: false,
            error: `Unsupported address type: ${sendConfig.addressType}` 
          }), {
            status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        
        let sendTxResult: { txHash: string; explorerUrl: string } | null = null;
        let sendTxError: string | null = null;
        
        // Get wallet for balance operations
        const { data: sendWallet } = await supabase
          .from("wallets")
          .select("id, balance, reserved_balance")
          .eq("user_id", user.id)
          .eq("currency", sendSym)
          .maybeSingle();
        
        const sendAmountNum = parseFloat(sendAmt);
        
        // Check available balance
        const availBal = (sendWallet?.balance || 0) - (sendWallet?.reserved_balance || 0);
        if (!sendWallet || availBal < sendAmountNum) {
          return new Response(JSON.stringify({ 
            success: false,
            error: `Insufficient balance. Available: ${availBal.toFixed(8)} ${sendSym}` 
          }), {
            status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        
        // Reserve funds BEFORE broadcast
        const { error: reserveErr } = await supabase.rpc('reserve_wallet_balance', {
          p_wallet_id: sendWallet.id,
          p_amount: sendAmountNum,
        });
        
        if (reserveErr) {
          console.error("Failed to reserve balance:", reserveErr);
          return new Response(JSON.stringify({ 
            success: false,
            error: "Failed to reserve funds" 
          }), {
            status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        
        const sendIdempotencyKey = `${user.id}_${sendTo}_${sendAmt}_${sendSym}_${Date.now()}`;
        
        // Handle TRX and TRC20 transactions
        if (mappedSendChain === "TRX") {
          const tronRes = await broadcastTronTransaction(sendPrivateKeyHex, sendFromAddress, sendTo, sendAmt, sendSym);
          if ('error' in tronRes) {
            sendTxError = tronRes.error;
          } else {
            sendTxResult = tronRes;
          }
        } 
        // Handle EVM chains
        else if (["ETH", "BSC", "MATIC"].includes(mappedSendChain)) {
          const evmRes = await broadcastEvmTransaction(sendPrivateKeyHex, sendFromAddress, sendTo, sendAmt, sendSym, mappedSendChain);
          if ('error' in evmRes) {
            sendTxError = evmRes.error;
          } else {
            sendTxResult = evmRes;
          }
        }
        // Handle BTC-like chains - not supported
        else {
          await supabase.rpc('release_reserved_balance', {
            p_wallet_id: sendWallet.id,
            p_amount: sendAmountNum,
          });
          return new Response(JSON.stringify({ 
            success: false,
            error: `On-chain ${mappedSendChain} sending not supported. Use UTXO chains via cryptoapis.` 
          }), {
            status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        
        if (!sendTxResult) {
          // Broadcast failed - release reserved funds
          await supabase.rpc('release_reserved_balance', {
            p_wallet_id: sendWallet.id,
            p_amount: sendAmountNum,
          });
          
          const errMsg = sendTxError || "Transaction broadcast failed";
          console.error("Send failed:", errMsg);
          
          // Record failed transaction
          await supabase.from("transactions").insert({
            user_id: user.id,
            type: "send",
            from_currency: sendSym,
            amount: sendAmountNum,
            recipient_address: sendTo,
            tx_hash: null,
            status: "failed",
            error_details: errMsg,
            can_retry: true,
            retry_count: 0,
            last_error: errMsg,
            idempotency_key: sendIdempotencyKey,
          });
          
          return new Response(JSON.stringify({ 
            success: false,
            error: errMsg,
            canRetry: true,
            errorDetails: errMsg,
          }), {
            status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        
        // Broadcast succeeded
        await supabase.from("transactions").insert({
          user_id: user.id,
          type: "send",
          from_currency: sendSym,
          amount: sendAmountNum,
          recipient_address: sendTo,
          tx_hash: sendTxResult.txHash,
          status: "pending",
          idempotency_key: sendIdempotencyKey,
        });
        
        // Create notification
        await supabase.from("notifications").insert({
          user_id: user.id,
          title: "Transaction Sent",
          message: `Sent ${sendAmt} ${sendSym} to ${sendTo.slice(0, 10)}... (confirming)`,
          type: "send",
          data: { txHash: sendTxResult.txHash, amount: sendAmt, symbol: sendSym, to: sendTo },
        });
        
        console.log(`On-chain send: ${sendAmt} ${sendSym} from ${sendFromAddress} to ${sendTo}, tx: ${sendTxResult.txHash}`);
        
        return new Response(JSON.stringify({
          success: true,
          txHash: sendTxResult.txHash,
          explorerUrl: sendTxResult.explorerUrl,
          from: sendFromAddress,
          to: sendTo,
          amount: sendAmt,
          symbol: sendSym,
          chain: chain,
          status: "pending",
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "sanity_test": {
        // Simple health check for unified-wallet to verify hd-wallet is working
        const safeTestModeEnv = (Deno.env.get('SAFE_TEST_MODE') ?? 'false').toLowerCase() === 'true';
        const envWarnings: string[] = [];
        if (!Deno.env.get('ALCHEMY_ETH_RPC')) envWarnings.push('ALCHEMY_ETH_RPC not configured');
        if (!Deno.env.get('ALCHEMY_POLYGON_RPC')) envWarnings.push('ALCHEMY_POLYGON_RPC not configured');
        if (!Deno.env.get('ALCHEMY_BSC_RPC')) envWarnings.push('ALCHEMY_BSC_RPC not configured');
        if (!Deno.env.get('TRONGRID_API_KEY')) envWarnings.push('TRONGRID_API_KEY not configured');
        
        return new Response(JSON.stringify({
          success: true,
          status: 'healthy',
          safeTestMode: safeTestModeEnv,
          warnings: envWarnings,
          supportedChains: Object.keys(chainConfigs),
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      default:
        return new Response(JSON.stringify({ 
          success: false,
          error: `Unknown action: ${action}` 
        }), {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
    }

  } catch (error) {
    console.error("HD Wallet error:", error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : "Unknown error" 
    }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
