import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";
import * as bip39 from "https://esm.sh/bip39@3.1.0";
import { HDKey } from "https://esm.sh/@scure/bip32@1.3.3";
import { keccak_256 } from "https://esm.sh/@noble/hashes@1.3.3/sha3";
import { sha256 } from "https://esm.sh/@noble/hashes@1.3.3/sha256";
import { bytesToHex, hexToBytes } from "https://esm.sh/@noble/hashes@1.3.3/utils";
import * as secp256k1 from "https://esm.sh/@noble/secp256k1@1.7.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// ==================== SAFE TEST MODE CONFIGURATION ====================
// Production default: OFF. Enable explicitly via backend variable SAFE_TEST_MODE="true".
const SAFE_TEST_MODE = (Deno.env.get('SAFE_TEST_MODE') ?? 'false').toLowerCase() === 'true';

// Withdrawal limits in SAFE_TEST_MODE (very small amounts for testing)
const WITHDRAWAL_LIMITS: Record<string, number> = {
  ETH: 0.001,      // ~$3-4 USD
  MATIC: 5,        // ~$3-5 USD
  BNB: 0.01,       // ~$3-6 USD
  TRX: 50,         // ~$5-8 USD
  USDT: 5,         // $5 USD
  USDC: 5,         // $5 USD
};

// Minimum confirmations required before crediting deposits
const MIN_CONFIRMATIONS: Record<string, number> = {
  ethereum: 12,
  polygon: 128,
  bsc: 15,
  tron: 19,
};

// ==================== RATE LIMITING ====================
const rateLimitMap = new Map<string, { count: number; resetTime: number }>();
const RATE_LIMIT_WINDOW = 60000; // 1 minute
const RATE_LIMIT_MAX_WALLET = 10;  // 10 wallet creations per minute
const RATE_LIMIT_MAX_BALANCE = 60; // 60 balance queries per minute
const RATE_LIMIT_MAX_SEND = 5;     // 5 sends per minute

function checkRateLimit(key: string, action: string): boolean {
  const now = Date.now();
  const fullKey = `${key}:${action}`;
  const entry = rateLimitMap.get(fullKey);
  
  const maxAllowed = action === 'create_wallet' ? RATE_LIMIT_MAX_WALLET :
                     action === 'send' ? RATE_LIMIT_MAX_SEND :
                     RATE_LIMIT_MAX_BALANCE;
  
  if (!entry || now > entry.resetTime) {
    rateLimitMap.set(fullKey, { count: 1, resetTime: now + RATE_LIMIT_WINDOW });
    return true;
  }
  
  if (entry.count >= maxAllowed) {
    return false;
  }
  
  entry.count++;
  return true;
}

// ==================== ENVIRONMENT VALIDATION ====================
function validateEnvironment(): { valid: boolean; missing: string[]; warnings: string[] } {
  const required = ['SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY'];
  const recommended = ['ALCHEMY_ETH_RPC', 'ALCHEMY_POLYGON_RPC', 'ALCHEMY_BSC_RPC', 'TRONGRID_API_KEY', 'ALCHEMY_API_KEY'];
  const missing: string[] = [];
  const warnings: string[] = [];
  
  for (const key of required) {
    if (!Deno.env.get(key)) {
      missing.push(key);
    }
  }
  
  for (const key of recommended) {
    if (!Deno.env.get(key)) {
      warnings.push(`${key} not configured`);
    }
  }
  
  return { valid: missing.length === 0, missing, warnings };
}

// ==================== CHAIN CONFIGURATIONS ====================
const CHAIN_CONFIG: Record<string, { 
  path: string; 
  rpcEnvKey: string;
  nativeCurrency: string;
  decimals: number;
  chainId: number;
}> = {
  ethereum: { path: "m/44'/60'/0'/0/0", rpcEnvKey: 'ALCHEMY_ETH_RPC', nativeCurrency: 'ETH', decimals: 18, chainId: 1 },
  polygon: { path: "m/44'/60'/0'/0/0", rpcEnvKey: 'ALCHEMY_POLYGON_RPC', nativeCurrency: 'MATIC', decimals: 18, chainId: 137 },
  bsc: { path: "m/44'/60'/0'/0/0", rpcEnvKey: 'ALCHEMY_BSC_RPC', nativeCurrency: 'BNB', decimals: 18, chainId: 56 },
  tron: { path: "m/44'/195'/0'/0/0", rpcEnvKey: 'TRONGRID_API_KEY', nativeCurrency: 'TRX', decimals: 6, chainId: 0 },
};

// Token contract addresses (mainnet only)
const TOKEN_CONTRACTS: Record<string, Record<string, { address: string; decimals: number }>> = {
  ethereum: {
    USDT: { address: '0xdAC17F958D2ee523a2206206994597C13D831ec7', decimals: 6 },
    USDC: { address: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48', decimals: 6 },
  },
  polygon: {
    USDT: { address: '0xc2132D05D31c914a87C6611C10748AEb04B58e8F', decimals: 6 },
    USDC: { address: '0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174', decimals: 6 },
  },
  bsc: {
    USDT: { address: '0x55d398326f99059fF775485246999027B3197955', decimals: 18 },
    USDC: { address: '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d', decimals: 18 },
  },
  tron: {
    USDT: { address: 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t', decimals: 6 },
    USDC: { address: 'TEkxiTehnzSmSe2XqrBj4w32RUN966rdz8', decimals: 6 },
  },
};

// ==================== BASE58 ENCODING FOR TRON ====================
const BASE58_ALPHABET = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';

function base58Encode(bytes: Uint8Array): string {
  const digits = [0];
  for (const byte of bytes) {
    let carry = byte;
    for (let j = 0; j < digits.length; j++) {
      carry += digits[j] * 256;
      digits[j] = carry % 58;
      carry = Math.floor(carry / 58);
    }
    while (carry > 0) {
      digits.push(carry % 58);
      carry = Math.floor(carry / 58);
    }
  }
  for (const byte of bytes) {
    if (byte === 0) digits.push(0);
    else break;
  }
  return digits.reverse().map(d => BASE58_ALPHABET[d]).join('');
}

function base58CheckEncode(payload: Uint8Array): string {
  const checksum = sha256(sha256(payload)).slice(0, 4);
  const combined = new Uint8Array(payload.length + 4);
  combined.set(payload);
  combined.set(checksum, payload.length);
  return base58Encode(combined);
}

// ==================== ADDRESS DERIVATION ====================
function deriveEthAddress(publicKey: Uint8Array): string {
  let uncompressedKey: Uint8Array;
  if (publicKey.length === 33) {
    const point = secp256k1.Point.fromHex(bytesToHex(publicKey));
    uncompressedKey = point.toRawBytes(false).slice(1);
  } else if (publicKey.length === 65) {
    uncompressedKey = publicKey.slice(1);
  } else {
    uncompressedKey = publicKey;
  }
  const hash = keccak_256(uncompressedKey);
  return '0x' + bytesToHex(hash.slice(-20));
}

function deriveTrxAddress(publicKey: Uint8Array): string {
  let uncompressedKey: Uint8Array;
  if (publicKey.length === 33) {
    const point = secp256k1.Point.fromHex(bytesToHex(publicKey));
    uncompressedKey = point.toRawBytes(false).slice(1);
  } else if (publicKey.length === 65) {
    uncompressedKey = publicKey.slice(1);
  } else {
    uncompressedKey = publicKey;
  }
  const hash = keccak_256(uncompressedKey);
  const addressBytes = hash.slice(-20);
  const payload = new Uint8Array(21);
  payload[0] = 0x41;
  payload.set(addressBytes, 1);
  return base58CheckEncode(payload);
}

// ==================== WALLET GENERATION ====================
async function generateWallet(mnemonic: string, chain: string): Promise<{ address: string; privateKey: string }> {
  const config = CHAIN_CONFIG[chain];
  if (!config) throw new Error(`Unsupported chain: ${chain}`);

  const seed = await bip39.mnemonicToSeed(mnemonic);
  const hdKey = HDKey.fromMasterSeed(seed);
  const derived = hdKey.derive(config.path);
  
  if (!derived.privateKey) throw new Error('Failed to derive private key');
  
  const privateKey = bytesToHex(derived.privateKey);
  const publicKey = derived.publicKey!;
  
  let address: string;
  if (chain === 'tron') {
    address = deriveTrxAddress(publicKey);
  } else {
    address = deriveEthAddress(publicKey);
  }
  
  return { address, privateKey };
}

// Get or create mnemonic for user (NEVER exposed to frontend)
async function getOrCreateMnemonic(supabase: any, userId: string): Promise<string> {
  const { data: existing } = await supabase
    .from('user_wallet_secrets')
    .select('mnemonic_encrypted')
    .eq('user_id', userId)
    .maybeSingle();

  if (existing?.mnemonic_encrypted) {
    return existing.mnemonic_encrypted;
  }

  const mnemonic = bip39.generateMnemonic();
  
  await supabase.from('user_wallet_secrets').insert({
    user_id: userId,
    mnemonic_encrypted: mnemonic,
  });

  return mnemonic;
}

// ==================== ON-CHAIN BALANCE QUERIES (SOURCE OF TRUTH) ====================
async function getEvmBalance(address: string, chain: string): Promise<string> {
  const config = CHAIN_CONFIG[chain];
  const rpcUrl = Deno.env.get(config.rpcEnvKey);
  
  if (!rpcUrl) {
    console.warn(`[Alchemy] RPC not configured for ${chain}`);
    return '0';
  }

  try {
    const response = await fetch(rpcUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jsonrpc: '2.0',
        id: 1,
        method: 'eth_getBalance',
        params: [address, 'latest']
      })
    });

    const data = await response.json();
    if (data.error) {
      console.error('[Alchemy] RPC error:', data.error.message);
      return '0';
    }

    const weiBalance = BigInt(data.result || '0x0');
    const balance = Number(weiBalance) / Math.pow(10, config.decimals);
    return balance.toString();
  } catch (error) {
    console.error(`[Alchemy] Error getting ${chain} balance`);
    return '0';
  }
}

async function getTronBalance(address: string): Promise<string> {
  const apiKey = Deno.env.get('TRONGRID_API_KEY');
  
  try {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (apiKey) headers['TRON-PRO-API-KEY'] = apiKey;

    const response = await fetch(`https://api.trongrid.io/v1/accounts/${address}`, { headers });
    const data = await response.json();
    
    if (!data.data || data.data.length === 0) return '0';
    
    const balance = (data.data[0].balance || 0) / 1e6;
    return balance.toString();
  } catch (error) {
    console.error('[Alchemy] Error getting TRX balance');
    return '0';
  }
}

async function getTokenBalance(address: string, chain: string, symbol: string): Promise<string> {
  const tokenInfo = TOKEN_CONTRACTS[chain]?.[symbol];
  if (!tokenInfo) return '0';

  if (chain === 'tron') {
    return getTronTokenBalance(address, symbol);
  }

  const config = CHAIN_CONFIG[chain];
  const rpcUrl = Deno.env.get(config.rpcEnvKey);
  if (!rpcUrl) return '0';

  try {
    const balanceOfSelector = '0x70a08231';
    const paddedAddress = address.slice(2).padStart(64, '0');
    const callData = balanceOfSelector + paddedAddress;

    const response = await fetch(rpcUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jsonrpc: '2.0',
        id: 1,
        method: 'eth_call',
        params: [{ to: tokenInfo.address, data: callData }, 'latest']
      })
    });

    const data = await response.json();
    if (data.error) return '0';

    const rawBalance = BigInt(data.result || '0x0');
    const balance = Number(rawBalance) / Math.pow(10, tokenInfo.decimals);
    return balance.toString();
  } catch (error) {
    console.error(`[Alchemy] Error getting ${symbol} balance`);
    return '0';
  }
}

async function getTronTokenBalance(address: string, symbol: string): Promise<string> {
  const tokenInfo = TOKEN_CONTRACTS.tron[symbol];
  if (!tokenInfo) return '0';

  const apiKey = Deno.env.get('TRONGRID_API_KEY');
  
  try {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (apiKey) headers['TRON-PRO-API-KEY'] = apiKey;

    const response = await fetch(`https://api.trongrid.io/v1/accounts/${address}`, { headers });
    const data = await response.json();
    
    if (!data.data || data.data.length === 0) return '0';
    
    const trc20 = data.data[0].trc20 || [];
    const tokenBalance = trc20.find((t: Record<string, string>) => 
      Object.keys(t)[0] === tokenInfo.address
    );
    
    if (!tokenBalance) return '0';
    
    const rawBalance = BigInt(Object.values(tokenBalance)[0] as string);
    const balance = Number(rawBalance) / Math.pow(10, tokenInfo.decimals);
    return balance.toString();
  } catch (error) {
    console.error(`[Alchemy] Error getting TRC20 ${symbol} balance`);
    return '0';
  }
}

// ==================== GAS & NONCE ====================
async function getGasPrice(chain: string): Promise<bigint> {
  const config = CHAIN_CONFIG[chain];
  const rpcUrl = Deno.env.get(config.rpcEnvKey);
  if (!rpcUrl) throw new Error(`RPC not configured for ${chain}`);

  const response = await fetch(rpcUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      jsonrpc: '2.0',
      id: 1,
      method: 'eth_gasPrice',
      params: []
    })
  });

  const data = await response.json();
  if (data.error) throw new Error(data.error.message);
  
  return BigInt(data.result);
}

async function getNonce(address: string, chain: string): Promise<bigint> {
  const config = CHAIN_CONFIG[chain];
  const rpcUrl = Deno.env.get(config.rpcEnvKey);
  if (!rpcUrl) throw new Error(`RPC not configured for ${chain}`);

  const response = await fetch(rpcUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      jsonrpc: '2.0',
      id: 1,
      method: 'eth_getTransactionCount',
      params: [address, 'latest']
    })
  });

  const data = await response.json();
  if (data.error) throw new Error(data.error.message);
  
  return BigInt(data.result);
}

// ==================== RLP ENCODING ====================
function rlpEncode(input: (Uint8Array | bigint | number | string)[]): Uint8Array {
  const encoded: Uint8Array[] = [];
  
  for (const item of input) {
    if (item instanceof Uint8Array) {
      if (item.length === 1 && item[0] < 128) {
        encoded.push(item);
      } else if (item.length < 56) {
        encoded.push(new Uint8Array([128 + item.length, ...item]));
      } else {
        const lenBytes = toBigEndian(BigInt(item.length));
        encoded.push(new Uint8Array([183 + lenBytes.length, ...lenBytes, ...item]));
      }
    } else if (typeof item === 'bigint' || typeof item === 'number') {
      const val = BigInt(item);
      if (val === 0n) {
        encoded.push(new Uint8Array([128]));
      } else {
        const bytes = toBigEndian(val);
        if (bytes.length === 1 && bytes[0] < 128) {
          encoded.push(bytes);
        } else {
          encoded.push(new Uint8Array([128 + bytes.length, ...bytes]));
        }
      }
    } else if (typeof item === 'string') {
      const bytes = hexToBytes(item.startsWith('0x') ? item.slice(2) : item);
      if (bytes.length === 0) {
        encoded.push(new Uint8Array([128]));
      } else if (bytes.length === 1 && bytes[0] < 128) {
        encoded.push(bytes);
      } else if (bytes.length < 56) {
        encoded.push(new Uint8Array([128 + bytes.length, ...bytes]));
      } else {
        const lenBytes = toBigEndian(BigInt(bytes.length));
        encoded.push(new Uint8Array([183 + lenBytes.length, ...lenBytes, ...bytes]));
      }
    }
  }
  
  const totalLength = encoded.reduce((sum, arr) => sum + arr.length, 0);
  let result: Uint8Array;
  
  if (totalLength < 56) {
    result = new Uint8Array(1 + totalLength);
    result[0] = 192 + totalLength;
    let offset = 1;
    for (const arr of encoded) {
      result.set(arr, offset);
      offset += arr.length;
    }
  } else {
    const lenBytes = toBigEndian(BigInt(totalLength));
    result = new Uint8Array(1 + lenBytes.length + totalLength);
    result[0] = 247 + lenBytes.length;
    result.set(lenBytes, 1);
    let offset = 1 + lenBytes.length;
    for (const arr of encoded) {
      result.set(arr, offset);
      offset += arr.length;
    }
  }
  
  return result;
}

function toBigEndian(value: bigint): Uint8Array {
  if (value === 0n) return new Uint8Array([]);
  const hex = value.toString(16).padStart(Math.ceil(value.toString(16).length / 2) * 2, '0');
  return hexToBytes(hex);
}

// ==================== ALCHEMY NOTIFY WEBHOOK REGISTRATION ====================
async function registerAlchemyWebhook(address: string, chain: string): Promise<{ success: boolean; webhookId?: string; error?: string }> {
  const alchemyApiKey = Deno.env.get('ALCHEMY_API_KEY');
  if (!alchemyApiKey) {
    return { success: false, error: 'ALCHEMY_API_KEY not configured' };
  }

  const networkMap: Record<string, string> = {
    ethereum: 'ETH_MAINNET',
    polygon: 'MATIC_MAINNET',
    bsc: 'BSC_MAINNET',
  };

  const network = networkMap[chain];
  if (!network) {
    console.log(`[Alchemy] Webhook registration not supported for ${chain}`);
    return { success: false, error: `Webhooks not supported for ${chain}` };
  }

  const supabaseUrl = Deno.env.get('SUPABASE_URL');
  const webhookUrl = `${supabaseUrl}/functions/v1/alchemy-webhook`;

  try {
    const response = await fetch('https://dashboard.alchemy.com/api/create-webhook', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Alchemy-Token': alchemyApiKey,
      },
      body: JSON.stringify({
        network,
        webhook_type: 'ADDRESS_ACTIVITY',
        webhook_url: webhookUrl,
        addresses: [address],
      })
    });

    const data = await response.json();
    
    if (data.error) {
      console.error('[Alchemy] Webhook registration error:', data.error);
      return { success: false, error: data.error };
    }

    console.log(`[Alchemy] Registered webhook for ${address} on ${chain}`);
    return { success: true, webhookId: data.data?.id };
  } catch (error) {
    console.error('[Alchemy] Webhook registration failed');
    return { success: false, error: 'Webhook registration failed' };
  }
}

// ==================== TRANSACTION SENDING (SERVER-SIDE ONLY) ====================
async function sendEvmTransaction(
  supabase: any,
  userId: string,
  chain: string,
  toAddress: string,
  amount: string,
  symbol: string
): Promise<{ success: boolean; txHash?: string; error?: string }> {
  try {
    const config = CHAIN_CONFIG[chain];
    const rpcUrl = Deno.env.get(config.rpcEnvKey);
    if (!rpcUrl) throw new Error(`RPC not configured for ${chain}`);

    // SAFE_TEST_MODE: Enforce withdrawal limits
    if (SAFE_TEST_MODE) {
      const limit = WITHDRAWAL_LIMITS[symbol] || 0.001;
      const numAmount = parseFloat(amount);
      if (numAmount > limit) {
        return { 
          success: false, 
          error: `SAFE_TEST_MODE: Maximum withdrawal is ${limit} ${symbol}. Requested: ${numAmount}` 
        };
      }
    }

    // Get mnemonic and derive private key (server-side only)
    const mnemonic = await getOrCreateMnemonic(supabase, userId);
    const wallet = await generateWallet(mnemonic, chain);
    
    // Get gas price and nonce
    const gasPrice = await getGasPrice(chain);
    const nonce = await getNonce(wallet.address, chain);
    
    const isNativeTransfer = symbol === config.nativeCurrency;
    const tokenInfo = TOKEN_CONTRACTS[chain]?.[symbol];
    
    let to: string;
    let value: bigint;
    let data: string;
    let gasLimit: bigint;
    
    if (isNativeTransfer) {
      to = toAddress;
      value = BigInt(Math.floor(parseFloat(amount) * Math.pow(10, config.decimals)));
      data = '0x';
      gasLimit = 21000n;
    } else {
      if (!tokenInfo) throw new Error(`Token ${symbol} not supported on ${chain}`);
      
      to = tokenInfo.address;
      value = 0n;
      
      // ERC20 transfer(address,uint256)
      const transferSelector = '0xa9059cbb';
      const paddedTo = toAddress.slice(2).padStart(64, '0');
      const tokenAmount = BigInt(Math.floor(parseFloat(amount) * Math.pow(10, tokenInfo.decimals)));
      const paddedAmount = tokenAmount.toString(16).padStart(64, '0');
      data = transferSelector + paddedTo + paddedAmount;
      gasLimit = 100000n;
    }

    // Create and sign transaction (EIP-155)
    const chainId = BigInt(config.chainId);
    const signData = [nonce, gasPrice, gasLimit, hexToBytes(to.slice(2)), value, hexToBytes(data.slice(2) || ''), chainId, 0n, 0n];
    const encoded = rlpEncode(signData as any);
    const msgHash = keccak_256(encoded);
    
    const privateKeyBytes = hexToBytes(wallet.privateKey);
    const signatureResult: any = await secp256k1.sign(msgHash, privateKeyBytes, { recovered: true, der: false });
    
    let sig: Uint8Array;
    let recovery: number;
    
    if (Array.isArray(signatureResult)) {
      sig = signatureResult[0];
      recovery = signatureResult[1];
    } else if (signatureResult && typeof signatureResult === 'object' && signatureResult.length >= 64) {
      sig = new Uint8Array(signatureResult);
      recovery = 0;
    } else if (signatureResult && typeof signatureResult.toCompactRawBytes === 'function') {
      sig = signatureResult.toCompactRawBytes();
      recovery = signatureResult.recovery || 0;
    } else {
      throw new Error('Failed to sign transaction');
    }
    
    const r = sig.slice(0, 32);
    const s = sig.slice(32, 64);
    const v = BigInt(recovery + 35 + Number(chainId) * 2);
    
    const signedTx = rlpEncode([nonce, gasPrice, gasLimit, hexToBytes(to.slice(2)), value, hexToBytes(data.slice(2) || ''), v, r, s] as any);
    
    // Broadcast transaction
    const response = await fetch(rpcUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jsonrpc: '2.0',
        id: 1,
        method: 'eth_sendRawTransaction',
        params: ['0x' + bytesToHex(signedTx)]
      })
    });

    const result = await response.json();
    
    if (result.error) {
      console.error('[Alchemy] Transaction broadcast error');
      return { success: false, error: result.error.message };
    }

    const txHash = result.result;
    console.log(`[Alchemy] Transaction broadcast: ${txHash?.substring(0, 20)}...`);
    
    return { success: true, txHash };
  } catch (error) {
    console.error('[Alchemy] Send error');
    return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
  }
}

async function sendTronTransaction(
  supabase: any,
  userId: string,
  toAddress: string,
  amount: string,
  symbol: string
): Promise<{ success: boolean; txHash?: string; error?: string }> {
  try {
    const apiKey = Deno.env.get('TRONGRID_API_KEY');
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (apiKey) headers['TRON-PRO-API-KEY'] = apiKey;

    // SAFE_TEST_MODE: Enforce withdrawal limits
    if (SAFE_TEST_MODE) {
      const limit = WITHDRAWAL_LIMITS[symbol] || 5;
      const numAmount = parseFloat(amount);
      if (numAmount > limit) {
        return { 
          success: false, 
          error: `SAFE_TEST_MODE: Maximum withdrawal is ${limit} ${symbol}. Requested: ${numAmount}` 
        };
      }
    }

    const mnemonic = await getOrCreateMnemonic(supabase, userId);
    const wallet = await generateWallet(mnemonic, 'tron');
    
    const isNativeTransfer = symbol === 'TRX';
    let txData: any;
    
    if (isNativeTransfer) {
      const sunAmount = Math.floor(parseFloat(amount) * 1e6);
      
      const createResponse = await fetch('https://api.trongrid.io/wallet/createtransaction', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          to_address: toAddress,
          owner_address: wallet.address,
          amount: sunAmount
        })
      });
      
      txData = await createResponse.json();
    } else {
      const tokenInfo = TOKEN_CONTRACTS.tron[symbol];
      if (!tokenInfo) throw new Error(`Token ${symbol} not supported on TRON`);
      
      const tokenAmount = Math.floor(parseFloat(amount) * Math.pow(10, tokenInfo.decimals));
      
      const createResponse = await fetch('https://api.trongrid.io/wallet/triggersmartcontract', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          owner_address: wallet.address,
          contract_address: tokenInfo.address,
          function_selector: 'transfer(address,uint256)',
          parameter: toAddress.slice(2).padStart(64, '0') + tokenAmount.toString(16).padStart(64, '0'),
          fee_limit: 100000000,
          call_value: 0
        })
      });
      
      const response = await createResponse.json();
      txData = response.transaction;
    }
    
    if (!txData || txData.Error) {
      return { success: false, error: txData?.Error || 'Failed to create transaction' };
    }

    // Sign transaction (server-side only)
    const txID = txData.txID;
    const txIDBytes = hexToBytes(txID);
    const privateKeyBytes = hexToBytes(wallet.privateKey);
    const signature = await secp256k1.sign(txIDBytes, privateKeyBytes, { der: false });
    
    txData.signature = [bytesToHex(signature)];

    // Broadcast
    const broadcastResponse = await fetch('https://api.trongrid.io/wallet/broadcasttransaction', {
      method: 'POST',
      headers,
      body: JSON.stringify(txData)
    });
    
    const result = await broadcastResponse.json();
    
    if (!result.result) {
      return { success: false, error: result.message || 'Broadcast failed' };
    }

    console.log(`[Alchemy] TRON transaction broadcast: ${txID?.substring(0, 20)}...`);
    return { success: true, txHash: txID };
  } catch (error) {
    console.error('[Alchemy] TRON send error');
    return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
  }
}

// ==================== MAIN HANDLER ====================
serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const envCheck = validateEnvironment();
  if (!envCheck.valid) {
    return new Response(JSON.stringify({
      success: false,
      error: `Missing required environment variables: ${envCheck.missing.join(', ')}`
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { action, userId, chain, symbol, toAddress, amount } = await req.json();
    
    // Rate limiting
    const rateLimitKey = userId || req.headers.get('x-forwarded-for') || 'anonymous';
    if (!checkRateLimit(rateLimitKey, action)) {
      return new Response(JSON.stringify({
        success: false,
        error: 'Rate limit exceeded. Please try again later.'
      }), {
        status: 429,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log(`[Alchemy] Action: ${action}, User: ${userId?.substring(0, 8)}..., Chain: ${chain}`);

    switch (action) {
      case 'create_wallet': {
        if (!userId || !chain || !symbol) {
          throw new Error('Missing required fields: userId, chain, symbol');
        }

        if (!CHAIN_CONFIG[chain]) {
          throw new Error(`Unsupported chain: ${chain}. Supported: ethereum, polygon, bsc, tron`);
        }

        const mnemonic = await getOrCreateMnemonic(supabaseClient, userId);
        const wallet = await generateWallet(mnemonic, chain);

        const { data: existingWallet } = await supabaseClient
          .from('wallet_addresses')
          .select('*')
          .eq('user_id', userId)
          .eq('chain', chain)
          .eq('symbol', symbol)
          .maybeSingle();

        if (!existingWallet) {
          await supabaseClient.from('wallet_addresses').insert({
            user_id: userId,
            chain,
            symbol,
            address: wallet.address,
            is_primary: true
          });
          
          // Register webhook for deposits (non-blocking)
          if (chain !== 'tron') {
            registerAlchemyWebhook(wallet.address, chain).catch(() => {});
          }
          
          console.log(`[Alchemy] Created wallet: ${wallet.address.substring(0, 10)}...`);
        }

        return new Response(JSON.stringify({
          success: true,
          address: existingWallet?.address || wallet.address,
          chain,
          symbol
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      case 'get_balance': {
        if (!userId || !chain || !symbol) {
          throw new Error('Missing required fields');
        }

        const { data: wallet } = await supabaseClient
          .from('wallet_addresses')
          .select('address')
          .eq('user_id', userId)
          .eq('chain', chain)
          .eq('symbol', symbol)
          .maybeSingle();

        if (!wallet) {
          return new Response(JSON.stringify({
            success: true,
            balance: '0',
            address: null
          }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
          });
        }

        // ALWAYS fetch from blockchain (source of truth)
        let balance: string;
        const nativeCurrency = CHAIN_CONFIG[chain]?.nativeCurrency;

        if (chain === 'tron') {
          balance = symbol === 'TRX' 
            ? await getTronBalance(wallet.address)
            : await getTronTokenBalance(wallet.address, symbol);
        } else {
          balance = symbol === nativeCurrency
            ? await getEvmBalance(wallet.address, chain)
            : await getTokenBalance(wallet.address, chain, symbol);
        }

        return new Response(JSON.stringify({
          success: true,
          balance,
          address: wallet.address,
          source: 'blockchain' // Indicates this is real on-chain data
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      case 'send': {
        if (!userId || !chain || !symbol || !toAddress || !amount) {
          throw new Error('Missing required fields for send');
        }

        const numAmount = parseFloat(amount);
        if (isNaN(numAmount) || numAmount <= 0) {
          throw new Error('Invalid amount');
        }

        // SAFE_TEST_MODE limit check
        if (SAFE_TEST_MODE) {
          const limit = WITHDRAWAL_LIMITS[symbol] || 0.001;
          if (numAmount > limit) {
            throw new Error(`SAFE_TEST_MODE active: Maximum withdrawal is ${limit} ${symbol}`);
          }
        }

        // Validate address format
        if (chain === 'tron') {
          if (!/^T[A-Za-z1-9]{33}$/.test(toAddress)) {
            throw new Error('Invalid TRON address format');
          }
        } else {
          if (!/^0x[a-fA-F0-9]{40}$/.test(toAddress)) {
            throw new Error('Invalid EVM address format');
          }
        }

        // Check CONFIRMED on-chain balance
        const { data: wallet } = await supabaseClient
          .from('wallet_addresses')
          .select('address')
          .eq('user_id', userId)
          .eq('chain', chain)
          .eq('symbol', symbol)
          .maybeSingle();

        if (!wallet) {
          throw new Error('Wallet not found');
        }

        let balance: string;
        const nativeCurrency = CHAIN_CONFIG[chain]?.nativeCurrency;

        if (chain === 'tron') {
          balance = symbol === 'TRX' 
            ? await getTronBalance(wallet.address)
            : await getTronTokenBalance(wallet.address, symbol);
        } else {
          balance = symbol === nativeCurrency
            ? await getEvmBalance(wallet.address, chain)
            : await getTokenBalance(wallet.address, chain, symbol);
        }

        if (parseFloat(balance) < numAmount) {
          throw new Error(`Insufficient confirmed balance. Available: ${balance} ${symbol}`);
        }

        // Generate idempotency key to prevent duplicate transactions
        const idempotencyKey = `${userId}-${chain}-${symbol}-${toAddress}-${amount}-${Date.now()}`;

        // Record pending transaction BEFORE sending
        const { data: txRecord, error: txError } = await supabaseClient
          .from('transactions')
          .insert({
            user_id: userId,
            type: 'send',
            from_currency: symbol,
            amount: numAmount,
            recipient_address: toAddress,
            status: 'pending',
            idempotency_key: idempotencyKey
          })
          .select()
          .single();

        if (txError) {
          console.error('[Alchemy] Failed to record transaction');
          throw new Error('Failed to initiate transaction');
        }

        // Send transaction (signed server-side)
        let result;
        if (chain === 'tron') {
          result = await sendTronTransaction(supabaseClient, userId, toAddress, amount, symbol);
        } else {
          result = await sendEvmTransaction(supabaseClient, userId, chain, toAddress, amount, symbol);
        }

        // Update transaction with result
        await supabaseClient
          .from('transactions')
          .update({
            status: result.success ? 'pending' : 'failed',
            tx_hash: result.txHash,
            last_error: result.error
          })
          .eq('id', txRecord.id);

        if (!result.success) {
          return new Response(JSON.stringify({
            success: false,
            error: result.error
          }), {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
          });
        }

        return new Response(JSON.stringify({
          success: true,
          txHash: result.txHash,
          chain,
          symbol,
          amount,
          toAddress,
          status: 'pending',
          message: 'Transaction broadcast. Awaiting confirmation.'
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      case 'register_webhook': {
        if (!userId || !chain) {
          throw new Error('Missing required fields');
        }

        const { data: wallet } = await supabaseClient
          .from('wallet_addresses')
          .select('address')
          .eq('user_id', userId)
          .eq('chain', chain)
          .maybeSingle();

        if (!wallet) {
          throw new Error('Wallet not found');
        }

        const result = await registerAlchemyWebhook(wallet.address, chain);

        return new Response(JSON.stringify({
          success: result.success,
          webhookId: result.webhookId,
          error: result.error
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      case 'get_config': {
        return new Response(JSON.stringify({
          success: true,
          safeTestMode: SAFE_TEST_MODE,
          withdrawalLimits: WITHDRAWAL_LIMITS,
          minConfirmations: MIN_CONFIRMATIONS,
          supportedChains: Object.keys(CHAIN_CONFIG),
          warnings: envCheck.warnings
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      case 'sanity_test': {
        if (!userId) {
          throw new Error('Missing userId for sanity test');
        }

        const testChain = chain || 'ethereum';
        const testSymbol = symbol || 'ETH';

        const mnemonic = await getOrCreateMnemonic(supabaseClient, userId);
        const wallet = await generateWallet(mnemonic, testChain);

        let balance = '0';
        if (testChain === 'tron') {
          balance = await getTronBalance(wallet.address);
        } else {
          balance = await getEvmBalance(wallet.address, testChain);
        }

        return new Response(JSON.stringify({
          success: true,
          test: 'sanity_check',
          wallet: {
            address: wallet.address,
            chain: testChain,
            symbol: testSymbol
          },
          balance,
          safeTestMode: SAFE_TEST_MODE,
          rpcConfigured: !!Deno.env.get(CHAIN_CONFIG[testChain]?.rpcEnvKey)
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      default:
        throw new Error(`Unknown action: ${action}`);
    }
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('[Alchemy] Error:', errorMessage);
    return new Response(JSON.stringify({
      success: false,
      error: errorMessage
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
